<?php
declare(strict_types=1);

/** @var string $route */

$route  = '/' . trim($route ?? '/', '/');
if ($route === '/') $route = '/';
$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

try {
    switch ($method . ' ' . $route) {
        // ---- Public ----
        case 'GET /':
        case 'GET /login':
            AuthMiddleware::guestOnly();
            (new AuthController())->showLogin();
            break;

        case 'POST /login':
            (new AuthController())->login();
            break;

        case 'GET /logout':
            (new AuthController())->logout();
            break;

        // ---- Protected ----
        case 'GET /dashboard':
            AuthMiddleware::requireLogin();
            (new DashboardController())->index();
            break;

        // ---- Clients ----
        case 'GET /clients':
            (new ClientController())->index();
            break;
        case 'GET /clients/create':
            (new ClientController())->create();
            break;
        case 'POST /clients':
            (new ClientController())->store();
            break;

        // ---- Groups ----
        case 'GET /groups':
            (new GroupController())->index();
            break;
        case 'GET /groups/create':
            (new GroupController())->create();
            break;
        case 'POST /groups':
            (new GroupController())->store();
            break;

        // ---- Loans ----
        case 'GET /loans':
            (new LoanController())->index();
            break;
        case 'GET /loans/create':
            (new LoanController())->create();
            break;
        case 'POST /loans':
            (new LoanController())->store();
            break;

        // ---- Payments / Collections ----
        case 'GET /collections/payments':
        case 'GET /payments':
            (new PaymentController())->index();
            break;
        case 'GET /collections/daily':
        case 'GET /payments/daily':
            (new PaymentController())->daily();
            break;
        case 'GET /collections/history':
        case 'GET /payments/history':
            (new PaymentController())->history();
            break;
        case 'GET /payments/create':
            (new PaymentController())->create();
            break;
        case 'POST /payments':
            (new PaymentController())->store();
            break;
        case 'GET /payments/loan-info':
            (new PaymentController())->loanInfo();
            break;

        // ---- Reports ----
        case 'GET /reports/daily': (new ReportController())->daily(); break;
        case 'GET /reports/daily/export': (new ReportController())->dailyExport(); break;
        case 'GET /reports/group': (new ReportController())->group(); break;
        case 'GET /reports/group/export': (new ReportController())->groupExport(); break;
        case 'GET /reports/client': (new ReportController())->client(); break;
        case 'GET /reports/client/export': (new ReportController())->clientExport(); break;
        case 'GET /reports/outstanding': (new ReportController())->outstanding(); break;
        case 'GET /reports/outstanding/export': (new ReportController())->outstandingExport(); break;

        // ---- User Management ----
        case 'GET /users':
        case 'GET /users/list':
            (new UserController())->index();
            break;
        case 'GET /users/create':
            (new UserController())->create();
            break;
        case 'POST /users':
            (new UserController())->store();
            break;
        case 'GET /users/password':
            (new UserController())->passwordForm();
            break;
        case 'POST /users/password':
            (new UserController())->passwordUpdate();
            break;
        case 'GET /users/roles':
            (new RoleController())->index();
            break;

        // ---- Settings ----
        case 'GET /settings/business': (new SettingsController())->business(); break;
        case 'POST /settings/business': (new SettingsController())->businessSave(); break;
        case 'GET /settings/preferences': (new SettingsController())->preferences(); break;
        case 'POST /settings/preferences': (new SettingsController())->preferencesSave(); break;
        case 'GET /settings/audit': (new SettingsController())->audit(); break;

        // ---- Backup & Restore ----
        case 'GET /settings/backup': (new BackupController())->index(); break;
        case 'POST /settings/backup/create': (new BackupController())->create(); break;
        case 'POST /settings/backup/save': (new BackupController())->saveOnly(); break;
        case 'GET /settings/backup/download': (new BackupController())->download(); break;
        case 'POST /settings/backup/delete': (new BackupController())->delete(); break;
        case 'POST /settings/backup/restore': (new BackupController())->restore(); break;
        case 'POST /settings/backup/upload': (new BackupController())->upload(); break;

        // ---- Dynamic Routes ----
        default:
            // Payments
            if ($method === 'GET' && preg_match('#^/payments/(\d+)$#', $route, $m)) {
                (new PaymentController())->show((int)$m[1]); return;
            }
            if ($method === 'GET' && preg_match('#^/payments/(\d+)/void$#', $route, $m)) {
                (new PaymentController())->voidForm((int)$m[1]); return;
            }
            if ($method === 'POST' && $route === '/payments/void') {
                (new PaymentController())->void(); return;
            }

            // Loans
            if ($method === 'GET' && preg_match('#^/loans/(\d+)$#', $route, $m)) {
                (new LoanController())->show((int)$m[1]); return;
            }
            if ($method === 'GET' && preg_match('#^/loans/(\d+)/edit$#', $route, $m)) {
                (new LoanController())->edit((int)$m[1]); return;
            }
            if ($method === 'POST' && preg_match('#^/loans/(\d+)/update$#', $route, $m)) {
                (new LoanController())->update((int)$m[1]); return;
            }
            if ($method === 'GET' && preg_match('#^/loans/(\d+)/cancel$#', $route, $m)) {
                (new LoanController())->cancelForm((int)$m[1]); return;
            }
            if ($method === 'POST' && $route === '/loans/cancel') {
                (new LoanController())->cancel(); return;
            }
            if ($method === 'GET' && preg_match('#^/loans/(\d+)/payoff$#', $route, $m)) {
                (new LoanController())->payoffForm((int)$m[1]); return;
            }
            if ($method === 'POST' && $route === '/loans/payoff') {
                (new LoanController())->payoff(); return;
            }

            // Groups
            if ($method === 'GET' && preg_match('#^/groups/(\d+)$#', $route, $m)) {
                (new GroupController())->show((int)$m[1]); return;
            }
            if ($method === 'GET' && preg_match('#^/groups/(\d+)/edit$#', $route, $m)) {
                (new GroupController())->edit((int)$m[1]); return;
            }
            if ($method === 'POST' && preg_match('#^/groups/(\d+)/update$#', $route, $m)) {
                (new GroupController())->update((int)$m[1]); return;
            }

            // Clients
            if ($method === 'GET' && preg_match('#^/clients/(\d+)$#', $route, $m)) {
                (new ClientController())->show((int)$m[1]); return;
            }
            if ($method === 'GET' && preg_match('#^/clients/(\d+)/edit$#', $route, $m)) {
                (new ClientController())->edit((int)$m[1]); return;
            }
            if ($method === 'POST' && preg_match('#^/clients/(\d+)/update$#', $route, $m)) {
                (new ClientController())->update((int)$m[1]); return;
            }
            if ($method === 'POST' && preg_match('#^/clients/(\d+)/deactivate$#', $route, $m)) {
                (new ClientController())->deactivate((int)$m[1]); return;
            }

            // Users
            if ($method === 'GET' && preg_match('#^/users/(\d+)$#', $route, $m)) {
                (new UserController())->show((int)$m[1]); return;
            }
            if ($method === 'GET' && preg_match('#^/users/(\d+)/edit$#', $route, $m)) {
                (new UserController())->edit((int)$m[1]); return;
            }
            if ($method === 'POST' && preg_match('#^/users/(\d+)/update$#', $route, $m)) {
                (new UserController())->update((int)$m[1]); return;
            }

            // 404
            http_response_code(404);
            view('errors/404', [], 'app');
            break;
    }
} catch (Throwable $e) {
    if (APP_DEBUG) {
        http_response_code(500);
        header('Content-Type: text/plain');
        echo "ROUTING ERROR\n\nRoute: $method $route\nError: " . $e->getMessage() . "\nFile: " . $e->getFile() . "\nLine: " . $e->getLine() . "\n\nTrace:\n" . $e->getTraceAsString();
    } else {
        http_response_code(500);
        echo "An error occurred.";
    }
    exit;
}