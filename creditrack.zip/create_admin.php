<?php
declare(strict_types=1);
require __DIR__ . '/config/config.php';
require __DIR__ . '/config/database.php';

// ==========================================
// SET YOUR DESIRED ADMIN CREDENTIALS HERE
// ==========================================
$fullName = 'System Administrator';
$username = 'admin';
$email    = 'admin@creditrack.local';
$password = 'password'; // Change this to something secure!
// ==========================================

try {
    $pdo = Database::pdo();
    
    // 1. Get the admin role ID
    $stmt = $pdo->prepare("SELECT id FROM roles WHERE name = 'admin' LIMIT 1");
    $stmt->execute();
    $roleId = $stmt->fetchColumn();

    if (!$roleId) {
        die("Error: Admin role not found. Did you run database/migrate.php first?");
    }

    // 2. Hash the password securely
    $hash = password_hash($password, PASSWORD_BCRYPT);

    // 3. Check if admin already exists
    $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
    $stmt->execute([$username, $email]);
    $existingUser = $stmt->fetch();

    if ($existingUser) {
        // Update existing admin password and ensure it's active
        $stmt = $pdo->prepare("UPDATE users SET password_hash = ?, role_id = ?, is_active = 1, failed_attempts = 0, locked_until = NULL WHERE id = ?");
        $stmt->execute([$hash, $roleId, $existingUser['id']]);
        echo "<h2 style='color:green'>✅ Admin account updated successfully!</h2>";
    } else {
        // Create new admin
        $stmt = $pdo->prepare("INSERT INTO users (role_id, full_name, username, email, password_hash, is_active) VALUES (?, ?, ?, ?, ?, 1)");
        $stmt->execute([$roleId, $fullName, $username, $email, $hash]);
        echo "<h2 style='color:green'>✅ Admin account created successfully!</h2>";
    }

    echo "<p><strong>Username:</strong> " . htmlspecialchars($username) . "</p>";
    echo "<p><strong>Password:</strong> " . htmlspecialchars($password) . "</p>";
    echo "<p style='color:red;'><strong>⚠️ IMPORTANT:</strong> Delete this file (<code>create_admin.php</code>) immediately after use!</p>";
    echo "<p><a href='" . APP_URL . "/'>Go to Login Page</a></p>";

} catch (Throwable $e) {
    echo "<h2 style='color:red'>Database Error</h2>";
    echo "<pre>" . htmlspecialchars($e->getMessage()) . "</pre>";
}