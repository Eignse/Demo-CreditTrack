<?php
declare(strict_types=1);

/**
 * Load .env into $_ENV and define constants.
 * No external dependency — simple parser.
 */
function loadEnv(string $path): void
{
    if (!is_file($path)) {
        throw new RuntimeException('.env file missing at ' . $path);
    }
    $lines = file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        $line = trim($line);
        if ($line === '' || str_starts_with($line, '#')) continue;
        if (!str_contains($line, '=')) continue;
        [$key, $value] = explode('=', $line, 2);
        $key   = trim($key);
        $value = trim($value, " \t\n\r\0\x0B\"'");
        $_ENV[$key] = $value;
        putenv("$key=$value");
    }
}

function env(string $key, $default = null)
{
    $v = $_ENV[$key] ?? getenv($key);
    if ($v === false || $v === null) return $default;
    return match (strtolower((string)$v)) {
        'true'  => true,
        'false' => false,
        'null'  => null,
        default => $v,
    };
}

loadEnv(dirname(__DIR__) . '/.env');

date_default_timezone_set('Asia/Manila');

define('APP_NAME', env('APP_NAME', 'CrediTrack'));
define('APP_ENV',  env('APP_ENV', 'local'));
define('APP_URL',  rtrim((string)env('APP_URL', 'http://localhost/creditrack'), '/'));
define('APP_DEBUG', (bool)env('APP_DEBUG', false));
define('BASE_PATH', dirname(__DIR__));

// Error display
if (APP_DEBUG) {
    ini_set('display_errors', '1');
    error_reporting(E_ALL);
} else {
    ini_set('display_errors', '0');
    error_reporting(E_ALL & ~E_DEPRECATED & ~E_NOTICE);
    ini_set('log_errors', '1');
    ini_set('error_log', BASE_PATH . '/storage/logs/php-errors.log');
}