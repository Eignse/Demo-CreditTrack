<?php
declare(strict_types=1);

/**
 * Single PDO instance (lazy).
 */
final class Database
{
    private static ?PDO $pdo = null;

    public static function pdo(): PDO
    {
        if (self::$pdo instanceof PDO) return self::$pdo;

        $dsn = sprintf(
            'mysql:host=%s;port=%s;dbname=%s;charset=utf8mb4',
            env('DB_HOST', '127.0.0.1'),
            env('DB_PORT', '3306'),
            env('DB_NAME', 'creditrack_db')
        );

        try {
            self::$pdo = new PDO($dsn, (string)env('DB_USER', 'root'), (string)env('DB_PASS', ''), [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
            ]);
        } catch (PDOException $e) {
            if (APP_DEBUG) {
                throw new RuntimeException('DB connection failed: ' . $e->getMessage());
            }
            http_response_code(500);
            exit('Service temporarily unavailable.');
        }
        return self::$pdo;
    }
}