INSERT INTO roles (name, label, description) VALUES
    ('admin', 'Administrator', 'Full system access'),
    ('staff', 'Staff', 'Access to clients and collections')
ON DUPLICATE KEY UPDATE label = VALUES(label);

INSERT INTO permissions (name, label) VALUES
    ('dashboard.view',       'View dashboard'),
    ('clients.view',         'View clients'),
    ('clients.manage',       'Create/edit clients'),
    ('collections.view',     'View collections'),
    ('collections.manage',   'Create/edit payments'),
    ('reports.view',         'View reports'),
    ('users.view',           'View users'),
    ('users.manage',         'Create/edit users'),
    ('settings.view',        'View settings'),
    ('settings.manage',      'Modify settings'),
    ('audit.view',           'View audit logs'),
    ('backup.manage',        'Backup / restore')
ON DUPLICATE KEY UPDATE label = VALUES(label);

-- Admin: all permissions
INSERT INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id FROM roles r CROSS JOIN permissions p
WHERE r.name = 'admin'
ON DUPLICATE KEY UPDATE role_id = role_id;

-- Staff: read-only + collections
INSERT INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id FROM roles r JOIN permissions p
    ON p.name IN ('dashboard.view','clients.view','clients.manage',
                  'collections.view','collections.manage','reports.view')
WHERE r.name = 'staff'
ON DUPLICATE KEY UPDATE role_id = role_id;