SET NAMES utf8mb4;

-- ---------- GROUPS ----------
CREATE TABLE IF NOT EXISTS `groups` (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    code VARCHAR(30) NOT NULL UNIQUE,
    name VARCHAR(150) NOT NULL,
    leader_client_id INT UNSIGNED NULL,
    assigned_user_id INT UNSIGNED NULL,
    meeting_day VARCHAR(20) NULL,
    notes TEXT NULL,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    created_by INT UNSIGNED NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (assigned_user_id) REFERENCES users(id) ON DELETE SET NULL,
    FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_groups_active (is_active),
    INDEX idx_groups_assigned (assigned_user_id)
) ENGINE=InnoDB;

-- ---------- CLIENTS ----------
CREATE TABLE IF NOT EXISTS clients (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    client_code VARCHAR(30) NOT NULL UNIQUE,
    full_name VARCHAR(150) NOT NULL,
    nickname VARCHAR(80) NULL,
    phone VARCHAR(30) NOT NULL,
    alt_phone VARCHAR(30) NULL,
    email VARCHAR(150) NULL,
    address VARCHAR(255) NOT NULL,
    date_of_birth DATE NULL,
    occupation VARCHAR(100) NULL,
    id_type VARCHAR(50) NULL,
    id_number VARCHAR(80) NULL,
    photo_path VARCHAR(255) NULL,
    notes TEXT NULL,
    group_id INT UNSIGNED NULL,
    assigned_user_id INT UNSIGNED NULL,
    status ENUM('active','inactive','blacklisted') NOT NULL DEFAULT 'active',
    created_by INT UNSIGNED NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (group_id) REFERENCES `groups`(id) ON DELETE SET NULL,
    FOREIGN KEY (assigned_user_id) REFERENCES users(id) ON DELETE SET NULL,
    FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_clients_status (status),
    INDEX idx_clients_group (group_id),
    INDEX idx_clients_assigned (assigned_user_id),
    INDEX idx_clients_phone (phone),
    INDEX idx_clients_name (full_name)
) ENGINE=InnoDB;

-- ---------- LEADER FK (idempotent) ----------
-- Check if the FK already exists; if not, add it.
SET @fk_exists = (
    SELECT COUNT(*) FROM information_schema.TABLE_CONSTRAINTS
    WHERE CONSTRAINT_SCHEMA = DATABASE()
      AND TABLE_NAME = 'groups'
      AND CONSTRAINT_NAME = 'fk_groups_leader'
);
SET @sql = IF(@fk_exists = 0,
    'ALTER TABLE `groups` ADD CONSTRAINT fk_groups_leader FOREIGN KEY (leader_client_id) REFERENCES clients(id) ON DELETE SET NULL',
    'SELECT 1'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- ---------- NEW PERMISSIONS ----------
INSERT INTO permissions (name, label) VALUES
    ('groups.view',    'View groups'),
    ('groups.manage',  'Create/edit groups'),
    ('loans.view',     'View loan accounts'),
    ('loans.manage',   'Create/edit loan accounts')
ON DUPLICATE KEY UPDATE label = VALUES(label);

INSERT INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id FROM roles r CROSS JOIN permissions p
WHERE r.name = 'admin'
  AND p.name IN ('groups.view','groups.manage','loans.view','loans.manage')
ON DUPLICATE KEY UPDATE role_id = role_id;

INSERT INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id FROM roles r CROSS JOIN permissions p
WHERE r.name = 'staff'
  AND p.name IN ('groups.view','groups.manage','loans.view','loans.manage')
ON DUPLICATE KEY UPDATE role_id = role_id;

INSERT INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id FROM roles r CROSS JOIN permissions p
WHERE r.name = 'staff' AND p.name = 'clients.manage'
ON DUPLICATE KEY UPDATE role_id = role_id;