-- database/migrations/006_void_and_payoff_schema.sql
-- Idempotent migration: safe to run multiple times.

SET NAMES utf8mb4;

-- ============================================
-- 1. payments columns
-- ============================================
SET @sql = (SELECT IF(
    (SELECT COUNT(*) FROM information_schema.COLUMNS 
     WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'payments' AND COLUMN_NAME = 'voided_at') = 0,
    'ALTER TABLE payments ADD COLUMN voided_at DATETIME NULL AFTER received_by',
    'SELECT 1'
));
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql = (SELECT IF(
    (SELECT COUNT(*) FROM information_schema.COLUMNS 
     WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'payments' AND COLUMN_NAME = 'void_reason') = 0,
    'ALTER TABLE payments ADD COLUMN void_reason VARCHAR(255) NULL AFTER voided_at',
    'SELECT 1'
));
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql = (SELECT IF(
    (SELECT COUNT(*) FROM information_schema.COLUMNS 
     WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'payments' AND COLUMN_NAME = 'voided_by') = 0,
    'ALTER TABLE payments ADD COLUMN voided_by INT UNSIGNED NULL AFTER void_reason',
    'SELECT 1'
));
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- ============================================
-- 2. loan_accounts columns
-- ============================================
SET @sql = (SELECT IF(
    (SELECT COUNT(*) FROM information_schema.COLUMNS 
     WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'loan_accounts' AND COLUMN_NAME = 'early_payoff_at') = 0,
    'ALTER TABLE loan_accounts ADD COLUMN early_payoff_at DATETIME NULL AFTER status',
    'SELECT 1'
));
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql = (SELECT IF(
    (SELECT COUNT(*) FROM information_schema.COLUMNS 
     WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'loan_accounts' AND COLUMN_NAME = 'cancelled_at') = 0,
    'ALTER TABLE loan_accounts ADD COLUMN cancelled_at DATETIME NULL AFTER early_payoff_at',
    'SELECT 1'
));
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql = (SELECT IF(
    (SELECT COUNT(*) FROM information_schema.COLUMNS 
     WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'loan_accounts' AND COLUMN_NAME = 'cancel_reason') = 0,
    'ALTER TABLE loan_accounts ADD COLUMN cancel_reason VARCHAR(255) NULL AFTER cancelled_at',
    'SELECT 1'
));
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- ============================================
-- 3. payments FK
-- ============================================
SET @fk_exists = (
    SELECT COUNT(*) FROM information_schema.TABLE_CONSTRAINTS
    WHERE CONSTRAINT_SCHEMA = DATABASE()
      AND TABLE_NAME = 'payments'
      AND CONSTRAINT_NAME = 'fk_payments_voided_by'
);
SET @sql = IF(@fk_exists = 0,
    'ALTER TABLE payments ADD CONSTRAINT fk_payments_voided_by FOREIGN KEY (voided_by) REFERENCES users(id) ON DELETE SET NULL',
    'SELECT 1'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- ============================================
-- 4. payments index
-- ============================================
SET @idx_exists = (
    SELECT COUNT(*) FROM information_schema.STATISTICS
    WHERE TABLE_SCHEMA = DATABASE()
      AND TABLE_NAME = 'payments'
      AND INDEX_NAME = 'idx_payments_voided'
);
SET @sql = IF(@idx_exists = 0,
    'CREATE INDEX idx_payments_voided ON payments (voided_at)',
    'SELECT 1'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;