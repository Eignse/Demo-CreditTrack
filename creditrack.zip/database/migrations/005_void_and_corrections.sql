SET NAMES utf8mb4;

-- Permissions are safe to re-run (ON DUPLICATE KEY UPDATE)
INSERT INTO permissions (name, label) VALUES
    ('payments.void', 'Void payments'),
    ('loans.cancel',  'Cancel loans'),
    ('loans.payoff',  'Process early payoff')
ON DUPLICATE KEY UPDATE label = VALUES(label);

INSERT INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id FROM roles r CROSS JOIN permissions p
WHERE r.name = 'admin'
  AND p.name IN ('payments.void','loans.cancel','loans.payoff')
ON DUPLICATE KEY UPDATE role_id = role_id;

INSERT INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id FROM roles r CROSS JOIN permissions p
WHERE r.name = 'staff'
  AND p.name IN ('payments.void','loans.payoff')
ON DUPLICATE KEY UPDATE role_id = role_id;