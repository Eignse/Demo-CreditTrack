SET NAMES utf8mb4;

-- ---------- PAYMENTS ----------
CREATE TABLE IF NOT EXISTS payments (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    receipt_no VARCHAR(30) NOT NULL UNIQUE,
    loan_id INT UNSIGNED NOT NULL,
    client_id INT UNSIGNED NOT NULL,
    amount DECIMAL(12,2) NOT NULL,
    payment_date DATE NOT NULL,
    payment_method ENUM('cash','bank','gcash','other') NOT NULL DEFAULT 'cash',
    reference_no VARCHAR(80) NULL,
    notes TEXT NULL,
    received_by INT UNSIGNED NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (loan_id) REFERENCES loan_accounts(id) ON DELETE RESTRICT,
    FOREIGN KEY (client_id) REFERENCES clients(id) ON DELETE RESTRICT,
    FOREIGN KEY (received_by) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_payments_loan (loan_id),
    INDEX idx_payments_client (client_id),
    INDEX idx_payments_date (payment_date),
    INDEX idx_payments_received_by (received_by)
) ENGINE=InnoDB;

-- ---------- PAYMENT ALLOCATIONS (which installment got paid) ----------
CREATE TABLE IF NOT EXISTS payment_allocations (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    payment_id INT UNSIGNED NOT NULL,
    schedule_id INT UNSIGNED NOT NULL,
    amount_applied DECIMAL(12,2) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (payment_id) REFERENCES payments(id) ON DELETE CASCADE,
    FOREIGN KEY (schedule_id) REFERENCES loan_schedules(id) ON DELETE RESTRICT,
    INDEX idx_alloc_payment (payment_id),
    INDEX idx_alloc_schedule (schedule_id)
) ENGINE=InnoDB;

-- ---------- NEW PERMISSIONS ----------
INSERT INTO permissions (name, label) VALUES
    ('payments.view',   'View payments'),
    ('payments.manage', 'Record payments')
ON DUPLICATE KEY UPDATE label = VALUES(label);

INSERT INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id FROM roles r CROSS JOIN permissions p
WHERE r.name = 'admin'
  AND p.name IN ('payments.view','payments.manage')
ON DUPLICATE KEY UPDATE role_id = role_id;

INSERT INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id FROM roles r CROSS JOIN permissions p
WHERE r.name = 'staff'
  AND p.name IN ('payments.view','payments.manage')
ON DUPLICATE KEY UPDATE role_id = role_id;