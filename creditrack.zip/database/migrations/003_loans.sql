SET NAMES utf8mb4;

CREATE TABLE IF NOT EXISTS loan_accounts (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    loan_code VARCHAR(30) NOT NULL UNIQUE,
    client_id INT UNSIGNED NOT NULL,
    principal DECIMAL(12,2) NOT NULL,
    interest_rate DECIMAL(5,2) NOT NULL,
    interest_method ENUM('flat','diminishing') NOT NULL DEFAULT 'flat',
    term_months INT UNSIGNED NOT NULL,
    frequency ENUM('daily','weekly','semi_monthly','monthly') NOT NULL DEFAULT 'monthly',
    start_date DATE NOT NULL,
    first_due_date DATE NOT NULL,
    maturity_date DATE NOT NULL,
    total_interest DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    total_payable DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    amount_paid DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    balance DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    status ENUM('active','completed','written_off','cancelled') NOT NULL DEFAULT 'active',
    notes TEXT NULL,
    created_by INT UNSIGNED NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (client_id) REFERENCES clients(id) ON DELETE RESTRICT,
    FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_loans_client (client_id),
    INDEX idx_loans_status (status),
    INDEX idx_loans_due (maturity_date)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS loan_schedules (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    loan_id INT UNSIGNED NOT NULL,
    installment_no INT UNSIGNED NOT NULL,
    due_date DATE NOT NULL,
    principal_due DECIMAL(12,2) NOT NULL,
    interest_due DECIMAL(12,2) NOT NULL,
    total_due DECIMAL(12,2) NOT NULL,
    amount_paid DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    balance_after DECIMAL(12,2) NOT NULL,
    status ENUM('pending','partial','paid','overdue') NOT NULL DEFAULT 'pending',
    paid_at DATETIME NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (loan_id) REFERENCES loan_accounts(id) ON DELETE CASCADE,
    INDEX idx_sched_loan (loan_id),
    INDEX idx_sched_due (due_date),
    INDEX idx_sched_status (status),
    UNIQUE KEY uq_loan_installment (loan_id, installment_no)
) ENGINE=InnoDB;