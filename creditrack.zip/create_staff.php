<?php
declare(strict_types=1);
require __DIR__ . '/config/config.php';
require __DIR__ . '/config/database.php';

$pdo = Database::pdo();

// ==========================================
// STAFF ACCOUNT CREDENTIALS
// ==========================================
$fullName = 'Staff Member';
$username = 'staff';
$email    = 'staff@creditrack.local';
$password = 'password'; // Password to log in
// ==========================================

// Get staff role ID
$stmt = $pdo->prepare("SELECT id FROM roles WHERE name = 'staff' LIMIT 1");
$stmt->execute();
$roleId = $stmt->fetchColumn();

if (!$roleId) {
    die("Error: Staff role not found. Did you run the migrations?");
}

// Check if staff user already exists
$stmt = $pdo->prepare("SELECT id FROM users WHERE username = ?");
$stmt->execute([$username]);
if ($stmt->fetch()) {
    die("Staff account already exists.");
}

// Create the staff
$hash = password_hash($password, PASSWORD_BCRYPT);

$stmt = $pdo->prepare("
    INSERT INTO users (role_id, full_name, username, email, password_hash, is_active) 
    VALUES (?, ?, ?, ?, ?, 1)
");
$stmt->execute([$roleId, $fullName, $username, $email, $hash]);

echo "<h2 style='color:green'>✅ Staff Account Created!</h2>";
echo "<p><strong>Username:</strong> $username</p>";
echo "<p><strong>Password:</strong> $password</p>";
echo "<p><a href='" . APP_URL . "/'>Go to Login Page</a></p>";
echo "<p style='color:red;'><strong>IMPORTANT: Delete this file (create_staff.php) immediately!</strong></p>";