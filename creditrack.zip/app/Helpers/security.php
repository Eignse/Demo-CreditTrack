<?php
declare(strict_types=1);

/** Start session securely. */
function startSecureSession(): void
{
    if (session_status() === PHP_SESSION_ACTIVE) return;

    session_name((string)env('SESSION_NAME', 'creditrack_session'));
    session_set_cookie_params([
        'lifetime' => (int)env('SESSION_LIFETIME', 7200),
        'path'     => '/',
        'secure'   => (APP_ENV === 'production'),
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_start();

    if (!isset($_SESSION['_created'])) {
        session_regenerate_id(true);
        $_SESSION['_created'] = time();
    }
    // Idle timeout
    $lifetime = (int)env('SESSION_LIFETIME', 7200);
    if (isset($_SESSION['_last']) && (time() - $_SESSION['_last']) > $lifetime) {
        session_unset();
        session_destroy();
        session_start();
        session_regenerate_id(true);
    }
    $_SESSION['_last'] = time();
}

/** CSRF token. */
function csrfToken(): string
{
    if (empty($_SESSION['_csrf'])) {
        $_SESSION['_csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['_csrf'];
}

/** CSRF hidden field. */
function csrfField(): string
{
    return '<input type="hidden" name="_csrf" value="' . e(csrfToken()) . '">';
}

/** Verify CSRF on POST. */
function verifyCsrf(): void
{
    $token = $_POST['_csrf'] ?? '';
    if (!is_string($token) || !hash_equals($_SESSION['_csrf'] ?? '', $token)) {
        http_response_code(419);
        exit('Invalid CSRF token. Please refresh and try again.');
    }
}