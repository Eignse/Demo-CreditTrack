<?php
declare(strict_types=1);

function e(?string $value): string
{
    return htmlspecialchars((string)$value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function redirect(string $path): never
{
    header('Location: ' . APP_URL . '/' . ltrim($path, '/'));
    exit;
}

function url(string $path = ''): string
{
    return APP_URL . '/' . ltrim($path, '/');
}

function asset(string $path): string
{
    return url('public/assets/' . ltrim($path, '/'));
}

function input(string $key, $default = null)
{
    return isset($_POST[$key]) && is_string($_POST[$key]) ? trim($_POST[$key]) : $default;
}

function flash(string $key, ?string $value = null): ?string
{
    if ($value !== null) {
        $_SESSION['_flash'][$key] = $value;
        return null;
    }
    if (isset($_SESSION['_flash'][$key])) {
        $v = $_SESSION['_flash'][$key];
        unset($_SESSION['_flash'][$key]);
        return $v;
    }
    return null;
}

/** Render a view with layout. */
function view(string $view, array $data = [], string $layout = 'app'): void
{
    $view = strtolower($view);
    $viewFile = BASE_PATH . '/app/Views/' . $view . '.php';
    
    // If the view file doesn't exist, auto-generate a placeholder
    if (!is_file($viewFile)) {
        $dir = dirname($viewFile);
        
        // Create directory if it doesn't exist
        if (!is_dir($dir)) {
            mkdir($dir, 0777, true);
        }
        
        // Generate placeholder content
        $placeholder = "<?php require __DIR__ . '/../partials/placeholder.php'; ?>";
        file_put_contents($viewFile, $placeholder);
    }
    
    extract($data, EXTR_SKIP);
    $layoutFile = BASE_PATH . '/app/Views/layouts/' . strtolower($layout) . '.php';
    
    if (is_file($layoutFile)) {
        ob_start();
        require $viewFile;
        $content = ob_get_clean();
        require $layoutFile;
    } else {
        require $viewFile;
    }
}