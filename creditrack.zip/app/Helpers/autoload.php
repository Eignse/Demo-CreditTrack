<?php
declare(strict_types=1);

/**
 * Multi-folder autoloader.
 * Loads any class from Models, Services, Controllers, Middleware, or Helpers.
 * Also loads the Database class from the config folder.
 */
spl_autoload_register(function (string $class): void {
    // 1. Special case for Database (lives in the config folder)
    if ($class === 'Database') {
        $file = BASE_PATH . '/config/database.php';
        if (is_file($file)) {
            require_once $file;
            return;
        }
    }

    // 2. Check app folders
    $folders = ['Models', 'Services', 'Controllers', 'Middleware', 'Helpers'];
    foreach ($folders as $dir) {
        $file = BASE_PATH . '/app/' . $dir . '/' . $class . '.php';
        if (is_file($file)) {
            require_once $file;
            return;
        }
    }
});