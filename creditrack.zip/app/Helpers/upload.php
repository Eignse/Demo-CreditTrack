<?php
declare(strict_types=1);

/**
 * Handle a photo upload safely.
 * Returns the relative path stored in the DB, or null if no upload.
 */
function handlePhotoUpload(string $field, ?string $existingPath = null): ?string
{
    if (!isset($_FILES[$field]) || $_FILES[$field]['error'] === UPLOAD_ERR_NO_FILE) {
        return null;
    }
    $file = $_FILES[$field];
    if ($file['error'] !== UPLOAD_ERR_OK) {
        throw new RuntimeException('Upload error code: ' . $file['error']);
    }
    if ($file['size'] > 3 * 1024 * 1024) {
        throw new RuntimeException('Photo must be under 3 MB.');
    }
    $allowed = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];
    $mime = mime_content_type($file['tmp_name']);
    if (!isset($allowed[$mime])) {
        throw new RuntimeException('Only JPG, PNG, or WebP allowed.');
    }
    $ext = $allowed[$mime];
    $name = bin2hex(random_bytes(8)) . '.' . $ext;
    $dir = BASE_PATH . '/storage/uploads/clients';
    if (!is_dir($dir)) mkdir($dir, 0777, true);
    $dest = $dir . '/' . $name;
    if (!move_uploaded_file($file['tmp_name'], $dest)) {
        throw new RuntimeException('Failed to save uploaded photo.');
    }
    return 'storage/uploads/clients/' . $name;
}