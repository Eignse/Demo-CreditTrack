<?php
declare(strict_types=1);

final class User
{
    public static function all(array $filters, int $page = 1, int $perPage = 15): array
    {
        $pdo = Database::pdo();
        $where = ["1=1"];
        $params = [];

        if (!empty($filters['q'])) {
            $where[] = "(u.full_name LIKE ? OR u.username LIKE ? OR u.email LIKE ?)";
            $like = '%' . $filters['q'] . '%';
            $params[] = $like; $params[] = $like; $params[] = $like;
        }
        if (!empty($filters['role']) && in_array($filters['role'], ['admin','staff'], true)) {
            $where[] = "r.name = ?";
            $params[] = $filters['role'];
        }
        if (!empty($filters['status']) && in_array($filters['status'], ['active','inactive'], true)) {
            $where[] = "u.is_active = ?";
            $params[] = $filters['status'] === 'active' ? 1 : 0;
        }

        $whereSql = implode(' AND ', $where);

        $countStmt = $pdo->prepare("
            SELECT COUNT(*) FROM users u JOIN roles r ON r.id = u.role_id WHERE $whereSql
        ");
        $countStmt->execute($params);
        $total = (int)$countStmt->fetchColumn();

        $offset = max(0, ($page - 1) * $perPage);
        $sql = "
            SELECT u.*, r.name AS role_name, r.label AS role_label
            FROM users u
            JOIN roles r ON r.id = u.role_id
            WHERE $whereSql
            ORDER BY u.created_at DESC
            LIMIT $perPage OFFSET $offset
        ";
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        return ['rows' => $stmt->fetchAll(), 'total' => $total, 'page' => $page, 'per_page' => $perPage];
    }

    public static function find(int $id): ?array
    {
        $stmt = Database::pdo()->prepare("
            SELECT u.*, r.name AS role_name, r.label AS role_label
            FROM users u JOIN roles r ON r.id = u.role_id
            WHERE u.id = ? LIMIT 1
        ");
        $stmt->execute([$id]);
        return $stmt->fetch() ?: null;
    }

    public static function usernameExists(string $username, ?int $excludeId = null): bool
    {
        $sql = "SELECT id FROM users WHERE username = ?";
        $params = [$username];
        if ($excludeId) {
            $sql .= " AND id != ?";
            $params[] = $excludeId;
        }
        $stmt = Database::pdo()->prepare($sql);
        $stmt->execute($params);
        return (bool)$stmt->fetch();
    }

    public static function emailExists(string $email, ?int $excludeId = null): bool
    {
        $sql = "SELECT id FROM users WHERE email = ?";
        $params = [$email];
        if ($excludeId) {
            $sql .= " AND id != ?";
            $params[] = $excludeId;
        }
        $stmt = Database::pdo()->prepare($sql);
        $stmt->execute($params);
        return (bool)$stmt->fetch();
    }

    public static function create(array $data): int
    {
        $pdo = Database::pdo();
        $stmt = $pdo->prepare("
            INSERT INTO users (role_id, full_name, username, email, password_hash, is_active)
            VALUES ((SELECT id FROM roles WHERE name = ?), ?, ?, ?, ?, ?)
        ");
        $stmt->execute([
            $data['role'],
            $data['full_name'],
            $data['username'],
            $data['email'],
            password_hash($data['password'], PASSWORD_BCRYPT),
            $data['is_active'] ? 1 : 0,
        ]);
        return (int)$pdo->lastInsertId();
    }

    public static function update(int $id, array $data): void
    {
        $pdo = Database::pdo();
        $sql = "
            UPDATE users SET
                role_id = (SELECT id FROM roles WHERE name = ?),
                full_name = ?, email = ?, is_active = ?
        ";
        $params = [$data['role'], $data['full_name'], $data['email'], $data['is_active'] ? 1 : 0];

        if (!empty($data['password'])) {
            $sql .= ", password_hash = ?";
            $params[] = password_hash($data['password'], PASSWORD_BCRYPT);
        }

        $sql .= " WHERE id = ?";
        $params[] = $id;

        $pdo->prepare($sql)->execute($params);
    }

    public static function changePassword(int $id, string $newPassword): void
    {
        Database::pdo()->prepare("
            UPDATE users SET password_hash = ? WHERE id = ?
        ")->execute([password_hash($newPassword, PASSWORD_BCRYPT), $id]);
    }

    public static function verifyPassword(int $id, string $password): bool
    {
        $stmt = Database::pdo()->prepare("SELECT password_hash FROM users WHERE id = ?");
        $stmt->execute([$id]);
        $hash = $stmt->fetchColumn();
        return $hash && password_verify($password, $hash);
    }

    public static function adminCount(): int
    {
        return (int)Database::pdo()->query("
            SELECT COUNT(*) FROM users
            WHERE role_id = (SELECT id FROM roles WHERE name = 'admin')
              AND is_active = 1
        ")->fetchColumn();
    }

    public static function activeList(): array
    {
        return Database::pdo()->query("
            SELECT u.id, u.full_name, r.name AS role
            FROM users u JOIN roles r ON r.id = u.role_id
            WHERE u.is_active = 1
            ORDER BY u.full_name
        ")->fetchAll();
    }

    public static function staffList(): array
    {
        return Database::pdo()->query("
            SELECT u.id, u.full_name
            FROM users u JOIN roles r ON r.id = u.role_id
            WHERE u.is_active = 1 AND r.name = 'staff'
            ORDER BY u.full_name
        ")->fetchAll();
    }
}