<?php
declare(strict_types=1);

final class Loan
{
    public static function generateCode(): string
    {
        $year = date('Y');
        $stmt = Database::pdo()->prepare("SELECT loan_code FROM loan_accounts WHERE loan_code LIKE ? ORDER BY loan_code DESC LIMIT 1");
        $stmt->execute(["LN-{$year}-%"]);
        $last = $stmt->fetchColumn();
        $next = 1;
        if ($last && preg_match('/-(\d+)$/', $last, $m)) {
            $next = ((int)$m[1]) + 1;
        }
        return sprintf('LN-%s-%04d', $year, $next);
    }

    public static function all(array $filters, int $viewerId, bool $isAdmin, int $page = 1, int $perPage = 15): array
    {
        $pdo = Database::pdo();
        $where = ["1=1"];
        $params = [];

        if (!empty($filters['q'])) {
            $where[] = "(l.loan_code LIKE ? OR c.full_name LIKE ? OR c.client_code LIKE ?)";
            $like = '%' . $filters['q'] . '%';
            $params[] = $like; $params[] = $like; $params[] = $like;
        }
        if (!empty($filters['status']) && in_array($filters['status'], ['active','completed','written_off','cancelled'], true)) {
            $where[] = "l.status = ?";
            $params[] = $filters['status'];
        }
        if (!$isAdmin) {
            $where[] = "c.assigned_user_id = ?";
            $params[] = $viewerId;
        }

        $whereSql = implode(' AND ', $where);
        $countStmt = $pdo->prepare("SELECT COUNT(*) FROM loan_accounts l JOIN clients c ON c.id = l.client_id WHERE $whereSql");
        $countStmt->execute($params);
        $total = (int)$countStmt->fetchColumn();

        $offset = max(0, ($page - 1) * $perPage);
        $sql = "
            SELECT l.*, c.full_name AS client_name, c.client_code,
                   (SELECT COUNT(*) FROM loan_schedules s WHERE s.loan_id = l.id AND s.status IN ('pending','partial','overdue')) AS open_installments
            FROM loan_accounts l
            JOIN clients c ON c.id = l.client_id
            WHERE $whereSql
            ORDER BY l.created_at DESC
            LIMIT $perPage OFFSET $offset
        ";
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        return ['rows' => $stmt->fetchAll(), 'total' => $total, 'page' => $page, 'per_page' => $perPage];
    }

    public static function find(int $id): ?array
    {
        $stmt = Database::pdo()->prepare("
            SELECT l.*, c.full_name AS client_name, c.client_code, c.phone, c.assigned_user_id
            FROM loan_accounts l
            JOIN clients c ON c.id = l.client_id
            WHERE l.id = ? LIMIT 1
        ");
        $stmt->execute([$id]);
        return $stmt->fetch() ?: null;
    }

    public static function schedules(int $loanId): array
    {
        $stmt = Database::pdo()->prepare("SELECT * FROM loan_schedules WHERE loan_id = ? ORDER BY installment_no");
        $stmt->execute([$loanId]);
        return $stmt->fetchAll();
    }

    public static function forClient(int $clientId): array
    {
        $stmt = Database::pdo()->prepare("SELECT * FROM loan_accounts WHERE client_id = ? ORDER BY created_at DESC");
        $stmt->execute([$clientId]);
        return $stmt->fetchAll();
    }

    public static function create(array $data, int $userId): int
    {
        $pdo = Database::pdo();
        $pdo->beginTransaction();
        try {
            $calc = $data['interest_method'] === 'diminishing'
                ? LoanCalculator::generateDiminishing((float)$data['principal'], (float)$data['interest_rate'], (int)$data['term_months'], $data['frequency'], $data['first_due_date'])
                : LoanCalculator::generate((float)$data['principal'], (float)$data['interest_rate'], (int)$data['term_months'], $data['frequency'], $data['first_due_date']);

            $stmt = $pdo->prepare("
                INSERT INTO loan_accounts
                    (loan_code, client_id, principal, interest_rate, interest_method, term_months,
                     frequency, start_date, first_due_date, maturity_date, total_interest, total_payable, amount_paid, balance, status, notes, created_by)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?, 'active', ?, ?)
            ");
            $stmt->execute([
                $data['loan_code'], (int)$data['client_id'], (float)$data['principal'], (float)$data['interest_rate'], $data['interest_method'], (int)$data['term_months'],
                $data['frequency'], $data['start_date'], $data['first_due_date'], $calc['maturity_date'], $calc['total_interest'], $calc['total_payable'], $calc['total_payable'], $data['notes'] ?? null, $userId,
            ]);
            $loanId = (int)$pdo->lastInsertId();

            $insert = $pdo->prepare("
                INSERT INTO loan_schedules (loan_id, installment_no, due_date, principal_due, interest_due, total_due, amount_paid, balance_after, status)
                VALUES (?, ?, ?, ?, ?, ?, 0, ?, 'pending')
            ");
            foreach ($calc['schedules'] as $row) {
                $insert->execute([$loanId, $row['installment_no'], $row['due_date'], $row['principal_due'], $row['interest_due'], $row['total_due'], $row['balance_after']]);
            }

            $pdo->commit();
            return $loanId;
        } catch (Throwable $e) {
            $pdo->rollBack();
            throw $e;
        }
    }

    /**
     * Update an existing loan and regenerate its amortization schedule.
     * Assumes no payments have been recorded (enforced by the controller).
     */
    public static function update(int $id, array $data): void
    {
        $pdo = Database::pdo();
        $pdo->beginTransaction();
        try {
            $calc = $data['interest_method'] === 'diminishing'
                ? LoanCalculator::generateDiminishing((float)$data['principal'], (float)$data['interest_rate'], (int)$data['term_months'], $data['frequency'], $data['first_due_date'])
                : LoanCalculator::generate((float)$data['principal'], (float)$data['interest_rate'], (int)$data['term_months'], $data['frequency'], $data['first_due_date']);

            $pdo->prepare("
                UPDATE loan_accounts 
                SET principal = ?, interest_rate = ?, interest_method = ?, term_months = ?,
                    frequency = ?, start_date = ?, first_due_date = ?, maturity_date = ?,
                    total_interest = ?, total_payable = ?, balance = ?
                WHERE id = ?
            ")->execute([
                $data['principal'], $data['interest_rate'], $data['interest_method'], $data['term_months'],
                $data['frequency'], $data['start_date'], $data['first_due_date'], $calc['maturity_date'],
                $calc['total_interest'], $calc['total_payable'], $calc['total_payable'], $id
            ]);

            $pdo->prepare("DELETE FROM loan_schedules WHERE loan_id = ?")->execute([$id]);

            $insert = $pdo->prepare("
                INSERT INTO loan_schedules (loan_id, installment_no, due_date, principal_due, interest_due, total_due, amount_paid, balance_after, status)
                VALUES (?, ?, ?, ?, ?, ?, 0, ?, 'pending')
            ");
            foreach ($calc['schedules'] as $row) {
                $insert->execute([$id, $row['installment_no'], $row['due_date'], $row['principal_due'], $row['interest_due'], $row['total_due'], $row['balance_after']]);
            }
            $pdo->commit();
        } catch (Throwable $e) {
            $pdo->rollBack();
            throw $e;
        }
    }

    public static function canAccess(int $loanId, int $viewerId, bool $isAdmin): bool
    {
        if ($isAdmin) return true;
        $loan = self::find($loanId);
        return $loan && (int)$loan['assigned_user_id'] === $viewerId;
    }

    public static function countActive(int $viewerId, bool $isAdmin): int
    {
        $pdo = Database::pdo();
        if ($isAdmin) return (int)$pdo->query("SELECT COUNT(*) FROM loan_accounts WHERE status='active'")->fetchColumn();
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM loan_accounts l JOIN clients c ON c.id = l.client_id WHERE l.status='active' AND c.assigned_user_id = ?");
        $stmt->execute([$viewerId]);
        return (int)$stmt->fetchColumn();
    }

    public static function totalOutstanding(int $viewerId, bool $isAdmin): float
    {
        $pdo = Database::pdo();
        if ($isAdmin) return (float)$pdo->query("SELECT COALESCE(SUM(balance),0) FROM loan_accounts WHERE status='active'")->fetchColumn();
        $stmt = $pdo->prepare("SELECT COALESCE(SUM(l.balance),0) FROM loan_accounts l JOIN clients c ON c.id = l.client_id WHERE l.status='active' AND c.assigned_user_id = ?");
        $stmt->execute([$viewerId]);
        return (float)$stmt->fetchColumn();
    }
}