<?php
declare(strict_types=1);

final class Payment
{
    public static function find(int $id): ?array
    {
        $stmt = Database::pdo()->prepare("
            SELECT p.*, l.loan_code, c.full_name AS client_name, c.client_code, c.phone,
                   u.full_name AS received_by_name, v.full_name AS voided_by_name
            FROM payments p
            JOIN loan_accounts l ON l.id = p.loan_id
            JOIN clients c ON c.id = p.client_id
            LEFT JOIN users u ON u.id = p.received_by
            LEFT JOIN users v ON v.id = p.voided_by
            WHERE p.id = ? LIMIT 1
        ");
        $stmt->execute([$id]);
        return $stmt->fetch() ?: null;
    }

    public static function allocations(int $paymentId): array
    {
        $stmt = Database::pdo()->prepare("
            SELECT pa.amount_applied, s.installment_no, s.due_date, s.total_due
            FROM payment_allocations pa
            JOIN loan_schedules s ON s.id = pa.schedule_id
            WHERE pa.payment_id = ?
            ORDER BY s.installment_no
        ");
        $stmt->execute([$paymentId]);
        return $stmt->fetchAll();
    }

    public static function forLoan(int $loanId): array
    {
        $stmt = Database::pdo()->prepare("
            SELECT p.*, u.full_name AS received_by_name
            FROM payments p
            LEFT JOIN users u ON u.id = p.received_by
            WHERE p.loan_id = ? AND p.voided_at IS NULL
            ORDER BY p.payment_date DESC, p.id DESC
        ");
        $stmt->execute([$loanId]);
        return $stmt->fetchAll();
    }

    public static function forClient(int $clientId): array
    {
        $stmt = Database::pdo()->prepare("
            SELECT p.*, l.loan_code, u.full_name AS received_by_name
            FROM payments p
            JOIN loan_accounts l ON l.id = p.loan_id
            LEFT JOIN users u ON u.id = p.received_by
            WHERE p.client_id = ? AND p.voided_at IS NULL
            ORDER BY p.payment_date DESC, p.id DESC
        ");
        $stmt->execute([$clientId]);
        return $stmt->fetchAll();
    }

    public static function list(array $filters, int $viewerId, bool $isAdmin, int $page = 1, int $perPage = 20): array
    {
        $pdo = Database::pdo();
        $where = ["p.voided_at IS NULL"];
        $params = [];

        if (!empty($filters['q'])) {
            $where[] = "(p.receipt_no LIKE ? OR l.loan_code LIKE ? OR c.full_name LIKE ? OR c.client_code LIKE ?)";
            $like = '%' . $filters['q'] . '%';
            array_push($params, $like, $like, $like, $like);
        }
        if (!empty($filters['date_from'])) {
            $where[] = "p.payment_date >= ?";
            $params[] = $filters['date_from'];
        }
        if (!empty($filters['date_to'])) {
            $where[] = "p.payment_date <= ?";
            $params[] = $filters['date_to'];
        }
        if (!empty($filters['method']) && in_array($filters['method'], ['cash','bank','gcash','other'], true)) {
            $where[] = "p.payment_method = ?";
            $params[] = $filters['method'];
        }
        if (!$isAdmin) {
            $where[] = "c.assigned_user_id = ?";
            $params[] = $viewerId;
        }

        $whereSql = implode(' AND ', $where);

        $countStmt = $pdo->prepare("SELECT COUNT(*) FROM payments p JOIN loan_accounts l ON l.id = p.loan_id JOIN clients c ON c.id = p.client_id WHERE $whereSql");
        $countStmt->execute($params);
        $total = (int)$countStmt->fetchColumn();

        $offset = max(0, ($page - 1) * $perPage);
        $sql = "
            SELECT p.*, l.loan_code, c.full_name AS client_name, c.client_code, u.full_name AS received_by_name
            FROM payments p
            JOIN loan_accounts l ON l.id = p.loan_id
            JOIN clients c ON c.id = p.client_id
            LEFT JOIN users u ON u.id = p.received_by
            WHERE $whereSql
            ORDER BY p.payment_date DESC, p.id DESC
            LIMIT $perPage OFFSET $offset
        ";
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        return ['rows' => $stmt->fetchAll(), 'total' => $total, 'page' => $page, 'per_page' => $perPage];
    }

    public static function todayTotals(int $viewerId, bool $isAdmin): array
    {
        $pdo = Database::pdo();
        $sql = "
            SELECT COUNT(*) AS cnt, COALESCE(SUM(p.amount), 0) AS total
            FROM payments p
            JOIN clients c ON c.id = p.client_id
            WHERE p.payment_date = CURDATE() AND p.voided_at IS NULL
        ";
        if (!$isAdmin) {
            $sql .= " AND c.assigned_user_id = ?";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$viewerId]);
            return $stmt->fetch();
        }
        return $pdo->query($sql)->fetch();
    }

    public static function canAccess(int $paymentId, int $viewerId, bool $isAdmin): bool
    {
        if ($isAdmin) return true;
        $stmt = Database::pdo()->prepare("SELECT c.assigned_user_id FROM payments p JOIN clients c ON c.id = p.client_id WHERE p.id = ?");
        $stmt->execute([$paymentId]);
        return (int)$stmt->fetchColumn() === $viewerId;
    }
}