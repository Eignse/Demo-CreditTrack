<?php
declare(strict_types=1);

final class Client
{
    public static function generateCode(): string
    {
        $year = date('Y');
        $pdo = Database::pdo();
        $stmt = $pdo->prepare("
            SELECT client_code FROM clients
            WHERE client_code LIKE ?
            ORDER BY client_code DESC LIMIT 1
        ");
        $stmt->execute(["CL-{$year}-%"]);
        $last = $stmt->fetchColumn();
        $next = 1;
        if ($last && preg_match('/-(\d+)$/', $last, $m)) {
            $next = ((int)$m[1]) + 1;
        }
        return sprintf('CL-%s-%04d', $year, $next);
    }

    public static function all(array $filters, int $viewerId, bool $isAdmin, int $page = 1, int $perPage = 15): array
    {
        $pdo = Database::pdo();
        $where = ["1=1"];
        $params = [];

        if (!empty($filters['q'])) {
            $where[] = "(c.full_name LIKE ? OR c.client_code LIKE ? OR c.phone LIKE ?)";
            $like = '%' . $filters['q'] . '%';
            $params[] = $like; $params[] = $like; $params[] = $like;
        }
        if (!empty($filters['status']) && in_array($filters['status'], ['active','inactive','blacklisted'], true)) {
            $where[] = "c.status = ?";
            $params[] = $filters['status'];
        }
        if (!empty($filters['group_id'])) {
            $where[] = "c.group_id = ?";
            $params[] = (int)$filters['group_id'];
        }
        if (!$isAdmin) {
            $where[] = "c.assigned_user_id = ?";
            $params[] = $viewerId;
        }

        $whereSql = implode(' AND ', $where);

        $countStmt = $pdo->prepare("SELECT COUNT(*) FROM clients c WHERE $whereSql");
        $countStmt->execute($params);
        $total = (int)$countStmt->fetchColumn();

        $offset = max(0, ($page - 1) * $perPage);
        $sql = "
            SELECT c.*, g.name AS group_name, u.full_name AS assigned_name
            FROM clients c
            LEFT JOIN `groups` g ON g.id = c.group_id
            LEFT JOIN users u ON u.id = c.assigned_user_id
            WHERE $whereSql
            ORDER BY c.created_at DESC
            LIMIT $perPage OFFSET $offset
        ";
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        return ['rows' => $stmt->fetchAll(), 'total' => $total, 'page' => $page, 'per_page' => $perPage];
    }

    public static function find(int $id): ?array
    {
        $stmt = Database::pdo()->prepare("
            SELECT c.*, g.name AS group_name, u.full_name AS assigned_name
            FROM clients c
            LEFT JOIN `groups` g ON g.id = c.group_id
            LEFT JOIN users u ON u.id = c.assigned_user_id
            WHERE c.id = ? LIMIT 1
        ");
        $stmt->execute([$id]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public static function create(array $data, int $userId): int
    {
        $pdo = Database::pdo();
        $stmt = $pdo->prepare("
            INSERT INTO clients
                (client_code, full_name, nickname, phone, alt_phone, email, address,
                 date_of_birth, occupation, id_type, id_number, photo_path, notes,
                 group_id, assigned_user_id, status, created_by)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([
            $data['client_code'], $data['full_name'], $data['nickname'],
            $data['phone'], $data['alt_phone'], $data['email'], $data['address'],
            $data['date_of_birth'] ?: null, $data['occupation'],
            $data['id_type'], $data['id_number'], $data['photo_path'],
            $data['notes'], $data['group_id'] ?: null, $data['assigned_user_id'] ?: null,
            $data['status'], $userId,
        ]);
        return (int)$pdo->lastInsertId();
    }

    public static function update(int $id, array $data): void
    {
        $stmt = Database::pdo()->prepare("
            UPDATE clients SET
                full_name = ?, nickname = ?, phone = ?, alt_phone = ?, email = ?,
                address = ?, date_of_birth = ?, occupation = ?, id_type = ?, id_number = ?,
                photo_path = COALESCE(?, photo_path), notes = ?,
                group_id = ?, assigned_user_id = ?, status = ?
            WHERE id = ?
        ");
        $stmt->execute([
            $data['full_name'], $data['nickname'], $data['phone'], $data['alt_phone'],
            $data['email'], $data['address'], $data['date_of_birth'] ?: null,
            $data['occupation'], $data['id_type'], $data['id_number'],
            $data['photo_path'], $data['notes'],
            $data['group_id'] ?: null, $data['assigned_user_id'] ?: null,
            $data['status'], $id,
        ]);
    }

    public static function canAccess(int $clientId, int $viewerId, bool $isAdmin): bool
    {
        if ($isAdmin) return true;
        $stmt = Database::pdo()->prepare("SELECT assigned_user_id FROM clients WHERE id = ?");
        $stmt->execute([$clientId]);
        return (int)$stmt->fetchColumn() === $viewerId;
    }

    public static function countActive(int $viewerId, bool $isAdmin): int
    {
        $pdo = Database::pdo();
        if ($isAdmin) {
            return (int)$pdo->query("SELECT COUNT(*) FROM clients WHERE status='active'")->fetchColumn();
        }
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM clients WHERE status='active' AND assigned_user_id = ?");
        $stmt->execute([$viewerId]);
        return (int)$stmt->fetchColumn();
    }
}