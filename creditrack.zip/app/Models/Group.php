<?php
declare(strict_types=1);

final class Group
{
    public static function generateCode(): string
    {
        $year = date('Y');
        $stmt = Database::pdo()->prepare("SELECT code FROM `groups` WHERE code LIKE ? ORDER BY code DESC LIMIT 1");
        $stmt->execute(["GR-{$year}-%"]);
        $last = $stmt->fetchColumn();
        $next = 1;
        if ($last && preg_match('/-(\d+)$/', $last, $m)) {
            $next = ((int)$m[1]) + 1;
        }
        return sprintf('GR-%s-%03d', $year, $next);
    }

    public static function all(array $filters, int $viewerId, bool $isAdmin, int $page = 1, int $perPage = 15): array
    {
        $pdo = Database::pdo();
        $where = ["1=1"];
        $params = [];

        if (!empty($filters['q'])) {
            $where[] = "(g.name LIKE ? OR g.code LIKE ?)";
            $like = '%' . $filters['q'] . '%';
            $params[] = $like; $params[] = $like;
        }
        if (!$isAdmin) {
            $where[] = "g.assigned_user_id = ?";
            $params[] = $viewerId;
        }

        $whereSql = implode(' AND ', $where);
        $countStmt = $pdo->prepare("SELECT COUNT(*) FROM `groups` g WHERE $whereSql");
        $countStmt->execute($params);
        $total = (int)$countStmt->fetchColumn();

        $offset = max(0, ($page - 1) * $perPage);
        $sql = "
            SELECT g.*, u.full_name AS assigned_name,
                   lc.full_name AS leader_name,
                   (SELECT COUNT(*) FROM clients WHERE group_id = g.id) AS member_count
            FROM `groups` g
            LEFT JOIN users u ON u.id = g.assigned_user_id
            LEFT JOIN clients lc ON lc.id = g.leader_client_id
            WHERE $whereSql
            ORDER BY g.created_at DESC
            LIMIT $perPage OFFSET $offset
        ";
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        return ['rows' => $stmt->fetchAll(), 'total' => $total, 'page' => $page, 'per_page' => $perPage];
    }

    public static function simpleList(int $viewerId, bool $isAdmin): array
    {
        $pdo = Database::pdo();
        if ($isAdmin) {
            return $pdo->query("SELECT id, name FROM `groups` WHERE is_active=1 ORDER BY name")->fetchAll();
        }
        $stmt = $pdo->prepare("SELECT id, name FROM `groups` WHERE is_active=1 AND assigned_user_id = ? ORDER BY name");
        $stmt->execute([$viewerId]);
        return $stmt->fetchAll();
    }

    public static function find(int $id): ?array
    {
        $stmt = Database::pdo()->prepare("
            SELECT g.*, u.full_name AS assigned_name, lc.full_name AS leader_name
            FROM `groups` g
            LEFT JOIN users u ON u.id = g.assigned_user_id
            LEFT JOIN clients lc ON lc.id = g.leader_client_id
            WHERE g.id = ? LIMIT 1
        ");
        $stmt->execute([$id]);
        return $stmt->fetch() ?: null;
    }

    public static function create(array $data, int $userId): int
    {
        $pdo = Database::pdo();
        $stmt = $pdo->prepare("
            INSERT INTO `groups` (code, name, leader_client_id, assigned_user_id, meeting_day, notes, is_active, created_by)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([
            $data['code'], $data['name'],
            $data['leader_client_id'] ?: null, $data['assigned_user_id'] ?: null,
            $data['meeting_day'], $data['notes'], $data['is_active'] ? 1 : 0, $userId,
        ]);
        return (int)$pdo->lastInsertId();
    }

    public static function update(int $id, array $data): void
    {
        $stmt = Database::pdo()->prepare("
            UPDATE `groups` SET
                name = ?, leader_client_id = ?, assigned_user_id = ?, meeting_day = ?,
                notes = ?, is_active = ?
            WHERE id = ?
        ");
        $stmt->execute([
            $data['name'], $data['leader_client_id'] ?: null, $data['assigned_user_id'] ?: null,
            $data['meeting_day'], $data['notes'], $data['is_active'] ? 1 : 0, $id,
        ]);
    }

    public static function members(int $groupId): array
    {
        $stmt = Database::pdo()->prepare("SELECT id, client_code, full_name, phone, status FROM clients WHERE group_id = ? ORDER BY full_name");
        $stmt->execute([$groupId]);
        return $stmt->fetchAll();
    }

    /** Fetch all clients to populate the leader dropdown */
    public static function allClientsForDropdown(): array
    {
        return Database::pdo()->query("SELECT id, full_name, client_code FROM clients WHERE status = 'active' ORDER BY full_name")->fetchAll();
    }

    public static function canAccess(int $groupId, int $viewerId, bool $isAdmin): bool
    {
        if ($isAdmin) return true;
        $stmt = Database::pdo()->prepare("SELECT assigned_user_id FROM `groups` WHERE id = ?");
        $stmt->execute([$groupId]);
        return (int)$stmt->fetchColumn() === $viewerId;
    }
}