<?php /** @var array $result @var array $filters @var array $groups @var bool $isAdmin */ ?>
<div class="page-header">
    <h2>Clients</h2>
    <?php if (Acl::can('clients.manage')): ?>
        <a href="<?= e(url('clients/create')) ?>" class="btn btn-primary">
            <i data-lucide="plus"></i> New Client
        </a>
    <?php endif; ?>
</div>

<form method="GET" class="panel mb-3">
    <div class="panel-body">
        <div class="row g-2 align-items-end">
            <div class="col-md-4">
                <label class="form-label small">Search</label>
                <input type="text" name="q" class="form-control" placeholder="Name, code, phone…" value="<?= e($filters['q']) ?>">
            </div>
            <div class="col-md-3">
                <label class="form-label small">Status</label>
                <select name="status" class="form-select">
                    <option value="">All</option>
                    <option value="active" <?= $filters['status']==='active'?'selected':'' ?>>Active</option>
                    <option value="inactive" <?= $filters['status']==='inactive'?'selected':'' ?>>Inactive</option>
                    <option value="blacklisted" <?= $filters['status']==='blacklisted'?'selected':'' ?>>Blacklisted</option>
                </select>
            </div>
            <div class="col-md-3">
                <label class="form-label small">Group</label>
                <select name="group_id" class="form-select">
                    <option value="">All groups</option>
                    <?php foreach ($groups as $g): ?>
                        <option value="<?= (int)$g['id'] ?>" <?= (string)$filters['group_id']===(string)$g['id']?'selected':'' ?>>
                            <?= e($g['name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-2 d-grid">
                <button class="btn btn-primary">Filter</button>
            </div>
        </div>
    </div>
</form>

<div class="panel">
    <div class="panel-body p-0">
        <?php if (empty($result['rows'])): ?>
            <div class="p-4 text-center text-muted">No clients found.</div>
        <?php else: ?>
            <table class="table table-hover mb-0 align-middle">
                <thead class="table-light">
                    <tr>
                        <th>Code</th>
                        <th>Name</th>
                        <th>Phone</th>
                        <th>Group</th>
                        <th>Collector</th>
                        <th>Status</th>
                        <th class="text-end">Actions</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($result['rows'] as $c): ?>
                    <tr>
                        <td><code><?= e($c['client_code']) ?></code></td>
                        <td>
                            <a href="<?= e(url('clients/'.$c['id'])) ?>" class="fw-semibold text-decoration-none">
                                <?= e($c['full_name']) ?>
                            </a>
                            <?php if ($c['nickname']): ?>
                                <div class="small text-muted">"<?= e($c['nickname']) ?>"</div>
                            <?php endif; ?>
                        </td>
                        <td><?= e($c['phone']) ?></td>
                        <td><?= e($c['group_name'] ?: '—') ?></td>
                        <td><?= e($c['assigned_name'] ?: '—') ?></td>
                        <td>
                            <?php
                            $badge = match($c['status']) {
                                'active' => 'success',
                                'inactive' => 'secondary',
                                'blacklisted' => 'danger',
                                default => 'secondary',
                            };
                            ?>
                            <span class="badge bg-<?= $badge ?>"><?= e(ucfirst($c['status'])) ?></span>
                        </td>
                        <td class="text-end">
                            <a href="<?= e(url('clients/'.$c['id'])) ?>" class="btn btn-sm btn-outline-secondary">View</a>
                            <?php if (Acl::can('clients.manage')): ?>
                                <a href="<?= e(url('clients/'.$c['id'].'/edit')) ?>" class="btn btn-sm btn-outline-primary">Edit</a>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
    <?php
    $totalPages = (int)ceil($result['total'] / $result['per_page']);
    if ($totalPages > 1):
    ?>
    <div class="panel-body d-flex justify-content-between align-items-center border-top">
        <div class="small text-muted">
            Page <?= (int)$result['page'] ?> of <?= $totalPages ?> — <?= (int)$result['total'] ?> total
        </div>
        <nav>
            <ul class="pagination mb-0">
                <?php for ($p = 1; $p <= $totalPages; $p++): ?>
                    <li class="page-item <?= $p === (int)$result['page'] ? 'active' : '' ?>">
                        <a class="page-link" href="?<?= http_build_query(array_merge($filters, ['page'=>$p])) ?>"><?= $p ?></a>
                    </li>
                <?php endfor; ?>
            </ul>
        </nav>
    </div>
    <?php endif; ?>
</div>