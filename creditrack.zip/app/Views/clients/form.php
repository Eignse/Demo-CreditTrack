<?php /** @var ?array $client @var string $nextCode @var array $groups @var array $staff */ ?>
<div class="page-header">
    <h2><?= e($title) ?></h2>
    <a href="<?= e(url('clients')) ?>" class="btn btn-outline-secondary">Cancel</a>
</div>

<form method="POST" enctype="multipart/form-data"
      action="<?= e($client ? url('clients/'.$client['id'].'/update') : url('clients')) ?>"
      class="panel">
    <?= csrfField() ?>
    <div class="panel-body">
        <h6 class="mb-3 text-muted small text-uppercase">Basic Information</h6>
        <div class="row g-3 mb-4">
            <div class="col-md-3">
                <label class="form-label">Client Code</label>
                <input type="text" class="form-control" value="<?= e($nextCode) ?>" readonly>
            </div>
            <div class="col-md-5">
                <label class="form-label">Full Name <span class="text-danger">*</span></label>
                <input type="text" name="full_name" class="form-control" required value="<?= e($client['full_name'] ?? '') ?>">
            </div>
            <div class="col-md-4">
                <label class="form-label">Nickname</label>
                <input type="text" name="nickname" class="form-control" value="<?= e($client['nickname'] ?? '') ?>">
            </div>
            <div class="col-md-6">
                <label class="form-label">Phone <span class="text-danger">*</span></label>
                <input type="text" name="phone" class="form-control" required value="<?= e($client['phone'] ?? '') ?>">
            </div>
            <div class="col-md-6">
                <label class="form-label">Alternate Phone</label>
                <input type="text" name="alt_phone" class="form-control" value="<?= e($client['alt_phone'] ?? '') ?>">
            </div>
            <div class="col-md-6">
                <label class="form-label">Email</label>
                <input type="email" name="email" class="form-control" value="<?= e($client['email'] ?? '') ?>">
            </div>
            <div class="col-md-6">
                <label class="form-label">Date of Birth</label>
                <input type="date" name="date_of_birth" class="form-control" value="<?= e($client['date_of_birth'] ?? '') ?>">
            </div>
            <div class="col-12">
                <label class="form-label">Address <span class="text-danger">*</span></label>
                <input type="text" name="address" class="form-control" required value="<?= e($client['address'] ?? '') ?>">
            </div>
        </div>

        <h6 class="mb-3 text-muted small text-uppercase">Identification & Occupation</h6>
        <div class="row g-3 mb-4">
            <div class="col-md-4">
                <label class="form-label">ID Type</label>
                <input type="text" name="id_type" class="form-control" placeholder="e.g. Driver's License" value="<?= e($client['id_type'] ?? '') ?>">
            </div>
            <div class="col-md-4">
                <label class="form-label">ID Number</label>
                <input type="text" name="id_number" class="form-control" value="<?= e($client['id_number'] ?? '') ?>">
            </div>
            <div class="col-md-4">
                <label class="form-label">Occupation</label>
                <input type="text" name="occupation" class="form-control" value="<?= e($client['occupation'] ?? '') ?>">
            </div>
            <div class="col-md-4">
                <label class="form-label">Photo</label>
                <input type="file" name="photo" class="form-control" accept="image/*">
                <?php if (!empty($client['photo_path'])): ?>
                    <small class="text-muted">Current: <?= e(basename($client['photo_path'])) ?></small>
                <?php endif; ?>
            </div>
        </div>

        <h6 class="mb-3 text-muted small text-uppercase">Assignment</h6>
        <div class="row g-3 mb-4">
            <div class="col-md-4">
                <label class="form-label">Group</label>
                <select name="group_id" class="form-select">
                    <option value="">— None —</option>
                    <?php foreach ($groups as $g): ?>
                        <option value="<?= (int)$g['id'] ?>" <?= (string)($client['group_id'] ?? '')===(string)$g['id']?'selected':'' ?>>
                            <?= e($g['name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-4">
                <label class="form-label">Assigned Collector</label>
                <select name="assigned_user_id" class="form-select">
                    <option value="">— None —</option>
                    <?php foreach ($staff as $s): ?>
                        <option value="<?= (int)$s['id'] ?>" <?= (string)($client['assigned_user_id'] ?? '')===(string)$s['id']?'selected':'' ?>>
                            <?= e($s['full_name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-4">
                <label class="form-label">Status</label>
                <select name="status" class="form-select">
                    <?php foreach (['active','inactive','blacklisted'] as $st): ?>
                        <option value="<?= $st ?>" <?= ($client['status'] ?? 'active')===$st?'selected':'' ?>>
                            <?= ucfirst($st) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>

        <div class="mb-2">
            <label class="form-label">Notes</label>
            <textarea name="notes" rows="3" class="form-control"><?= e($client['notes'] ?? '') ?></textarea>
        </div>
    </div>
    <div class="panel-body border-top d-flex justify-content-end gap-2">
        <a href="<?= e(url('clients')) ?>" class="btn btn-outline-secondary">Cancel</a>
        <button type="submit" class="btn btn-primary">Save Client</button>
    </div>
</form>