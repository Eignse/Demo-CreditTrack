<?php /** @var array $client */ ?>
<div class="page-header">
    <div>
        <h2><?= e($client['full_name']) ?></h2>
        <div class="text-muted small">
            <code><?= e($client['client_code']) ?></code>
            <?php if ($client['nickname']): ?> · "<?= e($client['nickname']) ?>"<?php endif; ?>
        </div>
    </div>
    <div class="d-flex gap-2">
        <a href="<?= e(url('clients')) ?>" class="btn btn-outline-secondary">Back</a>
        <?php if (Acl::can('clients.manage')): ?>
            <a href="<?= e(url('clients/'.$client['id'].'/edit')) ?>" class="btn btn-primary">Edit</a>
        <?php endif; ?>
    </div>
</div>

<div class="row g-3">
    <div class="col-lg-8">
        <div class="panel">
            <div class="panel-header"><h5>Details</h5></div>
            <div class="panel-body">
                <dl class="row mb-0">
                    <dt class="col-sm-3 text-muted">Phone</dt><dd class="col-sm-9"><?= e($client['phone']) ?></dd>
                    <dt class="col-sm-3 text-muted">Alt. Phone</dt><dd class="col-sm-9"><?= e($client['alt_phone'] ?: '—') ?></dd>
                    <dt class="col-sm-3 text-muted">Email</dt><dd class="col-sm-9"><?= e($client['email'] ?: '—') ?></dd>
                    <dt class="col-sm-3 text-muted">Address</dt><dd class="col-sm-9"><?= e($client['address']) ?></dd>
                    <dt class="col-sm-3 text-muted">Birthdate</dt><dd class="col-sm-9"><?= e($client['date_of_birth'] ?: '—') ?></dd>
                    <dt class="col-sm-3 text-muted">Occupation</dt><dd class="col-sm-9"><?= e($client['occupation'] ?: '—') ?></dd>
                    <dt class="col-sm-3 text-muted">ID</dt>
                    <dd class="col-sm-9"><?= e(($client['id_type'] ?: '—') . ' ' . ($client['id_number'] ?: '')) ?></dd>
                    <dt class="col-sm-3 text-muted">Group</dt><dd class="col-sm-9"><?= e($client['group_name'] ?: '—') ?></dd>
                    <dt class="col-sm-3 text-muted">Collector</dt><dd class="col-sm-9"><?= e($client['assigned_name'] ?: '—') ?></dd>
                    <dt class="col-sm-3 text-muted">Status</dt>
                    <dd class="col-sm-9">
                        <?php $badge = match($client['status']) {
                            'active'=>'success','inactive'=>'secondary','blacklisted'=>'danger', default=>'secondary'
                        }; ?>
                        <span class="badge bg-<?= $badge ?>"><?= e(ucfirst($client['status'])) ?></span>
                    </dd>
                    <?php if ($client['notes']): ?>
                        <dt class="col-sm-3 text-muted">Notes</dt>
                        <dd class="col-sm-9"><?= nl2br(e($client['notes'])) ?></dd>
                    <?php endif; ?>
                </dl>
            </div>
        </div>

        <div class="panel mt-3">
            <div class="panel-header d-flex justify-content-between align-items-center">
                <h5>Loan Accounts</h5>
                <?php if (Acl::can('loans.manage')): ?>
                    <a href="<?= e(url('loans/create?client_id='.$client['id'])) ?>" class="btn btn-sm btn-primary">
                        <i data-lucide="plus"></i> New Loan
                    </a>
                <?php endif; ?>
            </div>
            <div class="panel-body p-0">
                <?php
                $loans = Loan::forClient((int)$client['id']);
                if (empty($loans)):
                ?>
                    <div class="p-4 text-muted small text-center">No loans yet.</div>
                <?php else: ?>
                    <table class="table table-sm mb-0">
                        <thead class="table-light">
                            <tr><th>Code</th><th>Principal</th><th>Balance</th><th>Status</th><th></th></tr>
                        </thead>
                        <tbody>
                        <?php foreach ($loans as $l): ?>
                            <tr>
                                <td><code><?= e($l['loan_code']) ?></code></td>
                                <td>₱<?= number_format((float)$l['principal'], 2) ?></td>
                                <td>₱<?= number_format((float)$l['balance'], 2) ?></td>
                                <td>
                                    <?php $b = match($l['status']) {
                                        'active'=>'success','completed'=>'primary',
                                        'written_off'=>'danger','cancelled'=>'secondary', default=>'secondary'
                                    }; ?>
                                    <span class="badge bg-<?= $b ?>"><?= e(ucfirst(str_replace('_',' ', $l['status']))) ?></span>
                                </td>
                                <td class="text-end">
                                    <a href="<?= e(url('loans/'.$l['id'])) ?>" class="btn btn-sm btn-outline-secondary">View</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>

        <div class="panel mt-3">
            <div class="panel-header"><h5>Payment Timeline</h5></div>
            <div class="panel-body p-0">
                <?php $payments = Payment::forClient((int)$client['id']); ?>
                <?php if (empty($payments)): ?>
                    <div class="p-4 text-muted small text-center">No payments recorded yet.</div>
                <?php else: ?>
                    <table class="table table-sm mb-0">
                        <thead class="table-light">
                            <tr><th>Date</th><th>Receipt #</th><th>Loan</th><th>Amount</th><th>Method</th><th></th></tr>
                        </thead>
                        <tbody>
                        <?php foreach ($payments as $p): ?>
                            <tr>
                                <td><?= e($p['payment_date']) ?></td>
                                <td><code><?= e($p['receipt_no']) ?></code></td>
                                <td><code><?= e($p['loan_code']) ?></code></td>
                                <td class="text-success fw-semibold">₱<?= number_format((float)$p['amount'], 2) ?></td>
                                <td><?= e(ucfirst($p['payment_method'])) ?></td>
                                <td class="text-end">
                                    <a href="<?= e(url('payments/'.$p['id'])) ?>" class="btn btn-sm btn-outline-secondary">View</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <div class="col-lg-4">
        <div class="panel">
            <div class="panel-body text-center">
                <?php if ($client['photo_path']): ?>
                    <img src="<?= e(url($client['photo_path'])) ?>" alt="" class="rounded-circle mb-3" style="width:140px;height:140px;object-fit:cover;">
                <?php else: ?>
                    <div class="rounded-circle bg-light d-inline-flex align-items-center justify-content-center mb-3"
                         style="width:140px;height:140px;font-size:48px;color:#94a3b8;">
                        <?= e(strtoupper(substr($client['full_name'], 0, 1))) ?>
                    </div>
                <?php endif; ?>
                <div class="small text-muted">Created <?= e(date('M j, Y', strtotime($client['created_at']))) ?></div>
            </div>
        </div>
    </div>
</div>