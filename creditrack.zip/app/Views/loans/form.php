<?php /** @var ?array $loan @var string $nextCode @var array $clients @var int $preselectClient */ ?>
<div class="page-header">
    <h2><?= e($title) ?></h2>
    <a href="<?= e(url('loans')) ?>" class="btn btn-outline-secondary">Cancel</a>
</div>

<form method="POST" action="<?= e(url('loans')) ?>" class="panel">
    <?= csrfField() ?>
    <div class="panel-body">
        <div class="row g-3">
            <div class="col-md-3">
                <label class="form-label">Loan Code</label>
                <input type="text" class="form-control" value="<?= e($nextCode) ?>" readonly>
            </div>
            <div class="col-md-9">
                <label class="form-label">Client <span class="text-danger">*</span></label>
                <select name="client_id" class="form-select" required>
                    <option value="">— Select client —</option>
                    <?php foreach ($clients as $c): ?>
                        <option value="<?= (int)$c['id'] ?>" <?= $preselectClient === (int)$c['id'] ? 'selected' : '' ?>>
                            <?= e($c['full_name']) ?> (<?= e($c['client_code']) ?>)
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="col-md-4">
                <label class="form-label">Principal (₱) <span class="text-danger">*</span></label>
                <input type="number" name="principal" class="form-control" step="0.01" min="0.01" required>
            </div>
            <div class="col-md-4">
                <label class="form-label">Interest Rate (% per year) <span class="text-danger">*</span></label>
                <input type="number" name="interest_rate" class="form-control" step="0.01" min="0" required>
            </div>
            <div class="col-md-4">
                <label class="form-label">Term (months) <span class="text-danger">*</span></label>
                <input type="number" name="term_months" class="form-control" min="1" required>
            </div>

            <div class="col-md-6">
                <label class="form-label">Interest Method <span class="text-danger">*</span></label>
                <select name="interest_method" class="form-select" required>
                    <option value="flat">Flat (add-on interest)</option>
                    <option value="diminishing">Diminishing balance (reducing)</option>
                </select>
            </div>
            <div class="col-md-6">
                <label class="form-label">Frequency <span class="text-danger">*</span></label>
                <select name="frequency" class="form-select" required>
                    <option value="monthly">Monthly</option>
                    <option value="semi_monthly">Semi-monthly (15 & 30)</option>
                    <option value="weekly">Weekly</option>
                    <option value="daily">Daily</option>
                </select>
            </div>

            <div class="col-md-6">
                <label class="form-label">Start Date <span class="text-danger">*</span></label>
                <input type="date" name="start_date" class="form-control" value="<?= date('Y-m-d') ?>" required>
            </div>
            <div class="col-md-6">
                <label class="form-label">First Due Date <span class="text-danger">*</span></label>
                <input type="date" name="first_due_date" class="form-control" value="<?= date('Y-m-d', strtotime('+1 month')) ?>" required>
            </div>

            <div class="col-12">
                <label class="form-label">Notes</label>
                <textarea name="notes" rows="2" class="form-control"></textarea>
            </div>
        </div>
        <div class="alert alert-info mt-3 small mb-0">
            <strong>Note:</strong> The full amortization schedule is generated automatically when you save the loan.
        </div>
    </div>
    <div class="panel-body border-top d-flex justify-content-end gap-2">
        <a href="<?= e(url('loans')) ?>" class="btn btn-outline-secondary">Cancel</a>
        <button type="submit" class="btn btn-primary">Create Loan</button>
    </div>
</form>