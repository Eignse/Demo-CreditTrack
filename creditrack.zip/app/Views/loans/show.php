<?php /** @var array $loan @var array $schedules */ ?>
<div class="page-header">
    <div>
        <h2>Loan <?= e($loan['loan_code']) ?></h2>
        <div class="text-muted small">
            <a href="<?= e(url('clients/'.$loan['client_id'])) ?>" class="text-decoration-none">
                <?= e($loan['client_name']) ?>
            </a> — <?= e($loan['client_code']) ?>
        </div>
    </div>
    <div class="d-flex gap-2 flex-wrap">
        <?php if ($loan['status'] === 'active' && Acl::can('payments.manage')): ?>
            <a href="<?= e(url('payments/create?loan_id='.$loan['id'])) ?>" class="btn btn-success">
                <i data-lucide="wallet"></i> Record Payment
            </a>
            <?php if (Acl::can('loans.payoff')): ?>
                <a href="<?= e(url('loans/'.$loan['id'].'/payoff')) ?>" class="btn btn-info text-white">
                    <i data-lucide="check-circle"></i> Early Payoff
                </a>
            <?php endif; ?>
        <?php endif; ?>

        <?php if ($loan['status'] === 'active' && Acl::can('loans.manage')): ?>
            <a href="<?= e(url('loans/'.$loan['id'].'/edit')) ?>" class="btn btn-outline-primary">
                <i data-lucide="pencil"></i> Edit
            </a>
        <?php endif; ?>

        <?php if ($loan['status'] === 'active' && Acl::can('loans.cancel')): ?>
            <a href="<?= e(url('loans/'.$loan['id'].'/cancel')) ?>" class="btn btn-outline-danger">
                <i data-lucide="x-circle"></i> Cancel
            </a>
        <?php endif; ?>

        <a href="<?= e(url('loans')) ?>" class="btn btn-outline-secondary">
            <i data-lucide="arrow-left"></i> Back
        </a>
    </div>
</div>

<div class="row g-3 mb-3">
    <?php
    $cards = [
        ['Principal',       '₱'.number_format((float)$loan['principal'], 2), 'wallet', 'navy'],
        ['Total Interest',  '₱'.number_format((float)$loan['total_interest'], 2), 'trending-up', 'amber'],
        ['Total Payable',   '₱'.number_format((float)$loan['total_payable'], 2), 'scale', 'info'],
        ['Balance',         '₱'.number_format((float)$loan['balance'], 2), 'circle-dollar-sign', 'danger'],
    ];
    foreach ($cards as [$label, $val, $icon, $color]): ?>
        <div class="col-md-6 col-xl-3">
            <div class="stat-card">
                <div class="stat-icon text-<?= $color ?>"><i data-lucide="<?= $icon ?>"></i></div>
                <div>
                    <div class="stat-label"><?= e($label) ?></div>
                    <div class="stat-value"><?= e($val) ?></div>
                </div>
            </div>
        </div>
    <?php endforeach; ?>
</div>

<div class="row g-3">
    <div class="col-lg-5">
        <div class="panel">
            <div class="panel-header"><h5>Loan Details</h5></div>
            <div class="panel-body">
                <dl class="row mb-0">
                    <dt class="col-sm-5 text-muted">Interest Rate</dt><dd class="col-sm-7"><?= e($loan['interest_rate']) ?>% / yr</dd>
                    <dt class="col-sm-5 text-muted">Method</dt><dd class="col-sm-7"><?= e(ucfirst($loan['interest_method'])) ?></dd>
                    <dt class="col-sm-5 text-muted">Term</dt><dd class="col-sm-7"><?= (int)$loan['term_months'] ?> months</dd>
                    <dt class="col-sm-5 text-muted">Frequency</dt><dd class="col-sm-7"><?= e(ucfirst(str_replace('_',' ', $loan['frequency']))) ?></dd>
                    <dt class="col-sm-5 text-muted">Start Date</dt><dd class="col-sm-7"><?= e($loan['start_date']) ?></dd>
                    <dt class="col-sm-5 text-muted">First Due</dt><dd class="col-sm-7"><?= e($loan['first_due_date']) ?></dd>
                    <dt class="col-sm-5 text-muted">Maturity</dt><dd class="col-sm-7"><?= e($loan['maturity_date']) ?></dd>
                    <dt class="col-sm-5 text-muted">Status</dt>
                    <dd class="col-sm-7">
                        <?php $b = match($loan['status']) {
                            'active'=>'success','completed'=>'primary',
                            'written_off'=>'danger','cancelled'=>'secondary', default=>'secondary'
                        }; ?>
                        <span class="badge bg-<?= $b ?>"><?= e(ucfirst(str_replace('_',' ', $loan['status']))) ?></span>
                    </dd>
                </dl>
            </div>
        </div>
    </div>
    <div class="col-lg-7">
        <div class="panel">
            <div class="panel-header"><h5>Amortization Schedule (<?= count($schedules) ?> installments)</h5></div>
            <div class="panel-body p-0" style="max-height:520px;overflow-y:auto;">
                <table class="table table-sm table-hover mb-0">
                    <thead class="table-light" style="position:sticky;top:0;z-index:1;">
                        <tr>
                            <th>#</th><th>Due Date</th><th class="text-end">Principal</th>
                            <th class="text-end">Interest</th><th class="text-end">Total</th>
                            <th class="text-end">Balance</th><th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($schedules as $s): ?>
                        <tr>
                            <td><?= (int)$s['installment_no'] ?></td>
                            <td><?= e($s['due_date']) ?></td>
                            <td class="text-end">₱<?= number_format((float)$s['principal_due'], 2) ?></td>
                            <td class="text-end">₱<?= number_format((float)$s['interest_due'], 2) ?></td>
                            <td class="text-end fw-semibold">₱<?= number_format((float)$s['total_due'], 2) ?></td>
                            <td class="text-end">₱<?= number_format((float)$s['balance_after'], 2) ?></td>
                            <td>
                                <?php $b = match($s['status']) {
                                    'paid'=>'success','partial'=>'warning',
                                    'overdue'=>'danger', default=>'secondary'
                                }; ?>
                                <span class="badge bg-<?= $b ?>"><?= e(ucfirst($s['status'])) ?></span>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<div class="row g-3 mt-1">
    <div class="col-12">
        <div class="panel">
            <div class="panel-header"><h5>Payment History</h5></div>
            <div class="panel-body p-0">
                <?php
                $payments = Payment::forLoan((int)$loan['id']);
                if (empty($payments)):
                ?>
                    <div class="p-4 text-center text-muted small">No payments yet.</div>
                <?php else: ?>
                    <table class="table table-sm mb-0">
                        <thead class="table-light">
                            <tr><th>Receipt #</th><th>Date</th><th>Amount</th><th>Method</th><th>Received By</th><th></th></tr>
                        </thead>
                        <tbody>
                        <?php foreach ($payments as $p): ?>
                            <tr>
                                <td><code><?= e($p['receipt_no']) ?></code></td>
                                <td><?= e($p['payment_date']) ?></td>
                                <td class="text-success fw-semibold">₱<?= number_format((float)$p['amount'], 2) ?></td>
                                <td><?= e(ucfirst($p['payment_method'])) ?></td>
                                <td class="small"><?= e($p['received_by_name'] ?: '—') ?></td>
                                <td class="text-end">
                                    <a href="<?= e(url('payments/'.$p['id'])) ?>" class="btn btn-sm btn-outline-secondary">View</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>