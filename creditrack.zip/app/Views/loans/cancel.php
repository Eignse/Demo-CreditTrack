<?php /** @var array $loan */
$paid = (int)Database::pdo()->query("SELECT COUNT(*) FROM payments WHERE loan_id = {$loan['id']} AND voided_at IS NULL")->fetchColumn();
?>
<div class="page-header">
    <h2>Cancel Loan <?= e($loan['loan_code']) ?></h2>
    <a href="<?= e(url('loans/'.$loan['id'])) ?>" class="btn btn-outline-secondary">Cancel</a>
</div>
<div class="alert alert-warning">
    Cancelling locks out further payments.
    <?php if ($paid > 0): ?><br><strong>This loan has <?= $paid ?> recorded payment(s).</strong> Void them first, or check "Force cancel".<?php endif; ?>
</div>
<form method="POST" action="<?= e(url('loans/cancel')) ?>" class="panel">
    <?= csrfField() ?>
    <input type="hidden" name="loan_id" value="<?= (int)$loan['id'] ?>">
    <div class="panel-body">
        <label class="form-label">Reason <span class="text-danger">*</span></label>
        <textarea name="reason" class="form-control" rows="2" required></textarea>
        <?php if ($paid > 0): ?>
            <div class="form-check mt-3">
                <input class="form-check-input" type="checkbox" name="force" value="1" id="force">
                <label class="form-check-label text-danger" for="force">Force cancel</label>
            </div>
        <?php endif; ?>
    </div>
    <div class="panel-body border-top d-flex justify-content-end gap-2">
        <a href="<?= e(url('loans/'.$loan['id'])) ?>" class="btn btn-outline-secondary">Cancel</a>
        <button class="btn btn-danger" onclick="return confirm('Cancel this loan?')">Cancel Loan</button>
    </div>
</form>