<?php /** @var array $result @var array $filters */ ?>
<div class="page-header">
    <h2>Loan Accounts</h2>
    <?php if (Acl::can('loans.manage')): ?>
        <a href="<?= e(url('loans/create')) ?>" class="btn btn-primary">
            <i data-lucide="plus"></i> New Loan
        </a>
    <?php endif; ?>
</div>

<form method="GET" class="panel mb-3">
    <div class="panel-body">
        <div class="row g-2 align-items-end">
            <div class="col-md-5">
                <label class="form-label small">Search</label>
                <input type="text" name="q" class="form-control" placeholder="Loan code, client name…" value="<?= e($filters['q']) ?>">
            </div>
            <div class="col-md-4">
                <label class="form-label small">Status</label>
                <select name="status" class="form-select">
                    <option value="">All</option>
                    <option value="active" <?= $filters['status']==='active'?'selected':'' ?>>Active</option>
                    <option value="completed" <?= $filters['status']==='completed'?'selected':'' ?>>Completed</option>
                    <option value="written_off" <?= $filters['status']==='written_off'?'selected':'' ?>>Written Off</option>
                    <option value="cancelled" <?= $filters['status']==='cancelled'?'selected':'' ?>>Cancelled</option>
                </select>
            </div>
            <div class="col-md-3 d-grid">
                <button class="btn btn-primary">Filter</button>
            </div>
        </div>
    </div>
</form>

<div class="panel">
    <div class="panel-body p-0">
        <?php if (empty($result['rows'])): ?>
            <div class="p-4 text-center text-muted">No loan accounts found.</div>
        <?php else: ?>
            <table class="table table-hover mb-0 align-middle">
                <thead class="table-light">
                    <tr>
                        <th>Loan Code</th><th>Client</th><th>Principal</th>
                        <th>Total Payable</th><th>Balance</th><th>Frequency</th>
                        <th>Maturity</th><th>Status</th><th class="text-end">Actions</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($result['rows'] as $l): ?>
                    <tr>
                        <td><code><?= e($l['loan_code']) ?></code></td>
                        <td>
                            <a href="<?= e(url('clients/'.$l['client_id'])) ?>" class="text-decoration-none">
                                <?= e($l['client_name']) ?>
                            </a>
                            <div class="small text-muted"><?= e($l['client_code']) ?></div>
                        </td>
                        <td>₱<?= number_format((float)$l['principal'], 2) ?></td>
                        <td>₱<?= number_format((float)$l['total_payable'], 2) ?></td>
                        <td class="fw-semibold">₱<?= number_format((float)$l['balance'], 2) ?></td>
                        <td><span class="badge bg-light text-dark"><?= e(ucfirst(str_replace('_',' ', $l['frequency']))) ?></span></td>
                        <td class="small"><?= e($l['maturity_date']) ?></td>
                        <td>
                            <?php $b = match($l['status']) {
                                'active'=>'success','completed'=>'primary',
                                'written_off'=>'danger','cancelled'=>'secondary', default=>'secondary'
                            }; ?>
                            <span class="badge bg-<?= $b ?>"><?= e(ucfirst(str_replace('_',' ', $l['status']))) ?></span>
                        </td>
                        <td class="text-end">
                            <a href="<?= e(url('loans/'.$l['id'])) ?>" class="btn btn-sm btn-outline-secondary">View</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
    <?php
    $totalPages = (int)ceil($result['total'] / $result['per_page']);
    if ($totalPages > 1): ?>
    <div class="panel-body d-flex justify-content-between align-items-center border-top">
        <div class="small text-muted">
            Page <?= (int)$result['page'] ?> of <?= $totalPages ?> — <?= (int)$result['total'] ?> total
        </div>
        <nav><ul class="pagination mb-0">
            <?php for ($p = 1; $p <= $totalPages; $p++): ?>
                <li class="page-item <?= $p === (int)$result['page'] ? 'active' : '' ?>">
                    <a class="page-link" href="?<?= http_build_query(array_merge($filters, ['page'=>$p])) ?>"><?= $p ?></a>
                </li>
            <?php endfor; ?>
        </ul></nav>
    </div>
    <?php endif; ?>
</div>