<?php /** @var array $loan */ ?>
<div class="page-header">
    <h2>Edit Loan <?= e($loan['loan_code']) ?></h2>
    <a href="<?= e(url('loans/'.$loan['id'])) ?>" class="btn btn-outline-secondary">Cancel</a>
</div>
<div class="alert alert-info small">Editing regenerates the amortization schedule. Only possible because this loan has no payments.</div>
<form method="POST" action="<?= e(url('loans/'.$loan['id'].'/update')) ?>" class="panel">
    <?= csrfField() ?>
    <div class="panel-body"><div class="row g-3">
        <div class="col-md-4"><label class="form-label">Principal</label>
            <input type="number" name="principal" class="form-control" step="0.01" required value="<?= e($loan['principal']) ?>"></div>
        <div class="col-md-4"><label class="form-label">Interest (%/yr)</label>
            <input type="number" name="interest_rate" class="form-control" step="0.01" required value="<?= e($loan['interest_rate']) ?>"></div>
        <div class="col-md-4"><label class="form-label">Term (months)</label>
            <input type="number" name="term_months" class="form-control" required value="<?= (int)$loan['term_months'] ?>"></div>
        <div class="col-md-6"><label class="form-label">Method</label>
            <select name="interest_method" class="form-select">
                <option value="flat" <?= $loan['interest_method']==='flat'?'selected':'' ?>>Flat</option>
                <option value="diminishing" <?= $loan['interest_method']==='diminishing'?'selected':'' ?>>Diminishing</option>
            </select></div>
        <div class="col-md-6"><label class="form-label">Frequency</label>
            <select name="frequency" class="form-select">
                <?php foreach (['daily'=>'Daily','weekly'=>'Weekly','semi_monthly'=>'Semi-monthly','monthly'=>'Monthly'] as $v=>$l): ?>
                    <option value="<?= $v ?>" <?= $loan['frequency']===$v?'selected':'' ?>><?= $l ?></option>
                <?php endforeach; ?>
            </select></div>
        <div class="col-md-6"><label class="form-label">Start Date</label>
            <input type="date" name="start_date" class="form-control" required value="<?= e($loan['start_date']) ?>"></div>
        <div class="col-md-6"><label class="form-label">First Due Date</label>
            <input type="date" name="first_due_date" class="form-control" required value="<?= e($loan['first_due_date']) ?>"></div>
    </div></div>
    <div class="panel-body border-top d-flex justify-content-end gap-2">
        <a href="<?= e(url('loans/'.$loan['id'])) ?>" class="btn btn-outline-secondary">Cancel</a>
        <button class="btn btn-primary">Save &amp; Regenerate Schedule</button>
    </div>
</form>