<?php /** @var array $loan @var array $calc */ ?>
<div class="page-header">
    <h2>Early Payoff — <?= e($loan['loan_code']) ?></h2>
    <a href="<?= e(url('loans/'.$loan['id'])) ?>" class="btn btn-outline-secondary">Cancel</a>
</div>
<div class="panel mb-3"><div class="panel-body">
    <dl class="row mb-0">
        <dt class="col-sm-5 text-muted">Remaining Principal</dt><dd class="col-sm-7"><?= e(Settings::money((float)$calc['remaining_principal'])) ?></dd>
        <dt class="col-sm-5 text-muted">Pro-rated Interest (<?= (int)$calc['days_since_last'] ?>d)</dt><dd class="col-sm-7"><?= e(Settings::money((float)$calc['pro_rated_interest'])) ?></dd>
        <dt class="col-sm-5 fw-bold">Total Payoff</dt><dd class="col-sm-7 fw-bold text-success fs-5"><?= e(Settings::money((float)$calc['total_payoff'])) ?></dd>
        <dt class="col-sm-5 small text-muted">Balance on record</dt>
        <dd class="col-sm-7 small text-muted"><?= e(Settings::money((float)$calc['balance_on_record'])) ?>
            (savings of <?= e(Settings::money((float)$calc['balance_on_record'] - (float)$calc['total_payoff'])) ?>)</dd>
    </dl>
</div></div>
<form method="POST" action="<?= e(url('loans/payoff')) ?>" class="panel">
    <?= csrfField() ?>
    <input type="hidden" name="loan_id" value="<?= (int)$loan['id'] ?>">
    <div class="panel-body">
        <label class="form-label">Payment Method</label>
        <select name="payment_method" class="form-select">
            <option value="cash">Cash</option><option value="gcash">GCash</option>
            <option value="bank">Bank</option><option value="other">Other</option>
        </select>
    </div>
    <div class="panel-body border-top d-flex justify-content-end gap-2">
        <a href="<?= e(url('loans/'.$loan['id'])) ?>" class="btn btn-outline-secondary">Cancel</a>
        <button class="btn btn-success" onclick="return confirm('Confirm payoff of <?= e(Settings::money((float)$calc['total_payoff'])) ?>?')">Process Payoff</button>
    </div>
</form>