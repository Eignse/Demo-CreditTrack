<?php /** @var string $content */ ?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e(APP_NAME) ?> — <?= e($title ?? 'Dashboard') ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="<?= e(asset('css/app.css')) ?>" rel="stylesheet">
<script src="https://unpkg.com/lucide@latest"></script>
</head>
<body>
<div class="app-wrapper">
    <aside class="sidebar" id="sidebar">
        <div class="sidebar-brand">
            <span class="brand-mark">CT</span>
            <div>
                <div class="brand-name">CrediTrack</div>
                <div class="brand-sub">Lending &amp; Collections</div>
            </div>
        </div>
        <nav class="sidebar-nav">
            <?php require BASE_PATH . '/app/Views/layouts/_sidebar.php'; ?>
        </nav>
    </aside>

    <main class="main-content">
        <header class="topbar">
            <button class="btn-icon" id="sidebarToggle" aria-label="Toggle sidebar">
                <i data-lucide="menu"></i>
            </button>
            <div class="topbar-title"><?= e($title ?? 'Dashboard') ?></div>
            
            <div class="topbar-user">
                <div class="dropdown">
                    <button class="btn btn-sm d-flex align-items-center gap-2 border-0" data-bs-toggle="dropdown" aria-expanded="false">
                        <span class="user-name fw-semibold text-dark"><?= e(Auth::user()['full_name'] ?? '') ?></span>
                        <span class="badge role-badge"><?= e(ucfirst(Auth::user()['role'] ?? '')) ?></span>
                        <i data-lucide="chevron-down" style="width:16px;height:16px;"></i>
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end shadow-sm border-0">
                        <li>
                            <a class="dropdown-item d-flex align-items-center gap-2 py-2" href="<?= e(url('users/password')) ?>">
                                <i data-lucide="key" style="width:16px;height:16px;color:#6b7280;"></i> 
                                Change Password
                            </a>
                        </li>
                        <li><hr class="dropdown-divider"></li>
                        <li>
                            <a class="dropdown-item d-flex align-items-center gap-2 py-2 text-danger" href="<?= e(url('logout')) ?>">
                                <i data-lucide="log-out" style="width:16px;height:16px;"></i> 
                                Sign out
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </header>

        <?php if ($s = flash('success')): ?>
            <div class="alert alert-success alert-dismissible mx-3 mt-3">
                <?= e($s) ?><button class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>
        <?php if ($s = flash('error')): ?>
            <div class="alert alert-danger alert-dismissible mx-3 mt-3">
                <?= e($s) ?><button class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <div class="page-body"><?= $content ?></div>
    </main>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?= e(asset('js/app.js')) ?>"></script>
<script>lucide.createIcons();</script>
</body>
</html>