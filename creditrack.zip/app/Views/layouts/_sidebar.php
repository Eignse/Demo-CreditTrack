<?php
$current = '/' . trim(parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH), '/');
$current = preg_replace('#^/creditrack#i', '', $current);
$is = fn(string $p) => str_starts_with($current, $p) ? 'active' : '';
?>
<ul class="nav flex-column">
    <li class="nav-item">
        <a class="nav-link <?= $is('/dashboard') ?>" href="<?= e(url('dashboard')) ?>">
            <i data-lucide="layout-dashboard"></i><span>Dashboard</span>
        </a>
    </li>

    <li class="nav-item">
        <button class="nav-link nav-toggle <?= $is('/clients') || $is('/groups') || $is('/loans') ? 'open' : '' ?>" data-target="sub-clients">
            <i data-lucide="users"></i><span>Clients</span>
            <i data-lucide="chevron-down" class="chev"></i>
        </button>
        <ul class="subnav <?= $is('/clients') || $is('/groups') || $is('/loans') ? 'open' : '' ?>" id="sub-clients">
            <li><a class="nav-link <?= $is('/clients') && !$is('/groups') && !$is('/loans') ? 'active' : '' ?>" href="<?= e(url('clients')) ?>">Client List</a></li>
            <li><a class="nav-link <?= $is('/groups') ? 'active' : '' ?>" href="<?= e(url('groups')) ?>">Groups</a></li>
            <li><a class="nav-link <?= $is('/loans') ? 'active' : '' ?>" href="<?= e(url('loans')) ?>">Loan Accounts</a></li>
        </ul>
    </li>

    <li class="nav-item">
        <button class="nav-link nav-toggle <?= $is('/collections') ?>" data-target="sub-collections">
            <i data-lucide="wallet"></i><span>Collections</span>
            <i data-lucide="chevron-down" class="chev"></i>
        </button>
        <ul class="subnav <?= $is('/collections') ? 'open' : '' ?>" id="sub-collections">
            <li><a class="nav-link <?= $is('/collections/payments') ?>" href="<?= e(url('collections/payments')) ?>">Payments</a></li>
            <li><a class="nav-link <?= $is('/collections/daily') ?>" href="<?= e(url('collections/daily')) ?>">Daily Transactions</a></li>
            <li><a class="nav-link <?= $is('/collections/history') ?>" href="<?= e(url('collections/history')) ?>">Payment History</a></li>
        </ul>
    </li>

    <li class="nav-item">
        <button class="nav-link nav-toggle <?= $is('/reports') ?>" data-target="sub-reports">
            <i data-lucide="bar-chart-3"></i><span>Reports</span>
            <i data-lucide="chevron-down" class="chev"></i>
        </button>
        <ul class="subnav <?= $is('/reports') ? 'open' : '' ?>" id="sub-reports">
            <li><a class="nav-link <?= $is('/reports/daily') ?>" href="<?= e(url('reports/daily')) ?>">Daily Collection Report</a></li>
            <li><a class="nav-link <?= $is('/reports/group') ?>" href="<?= e(url('reports/group')) ?>">Group Collection Report</a></li>
            <li><a class="nav-link <?= $is('/reports/client') ?>" href="<?= e(url('reports/client')) ?>">Client Payment Report</a></li>
            <li><a class="nav-link <?= $is('/reports/outstanding') ?>" href="<?= e(url('reports/outstanding')) ?>">Outstanding Balance Report</a></li>
        </ul>
    </li>

    <li class="nav-item">
        <button class="nav-link nav-toggle <?= $is('/users') ?>" data-target="sub-users">
            <i data-lucide="user-cog"></i><span>User Management</span>
            <i data-lucide="chevron-down" class="chev"></i>
        </button>
        <ul class="subnav <?= $is('/users') ? 'open' : '' ?>" id="sub-users">
            <li><a class="nav-link <?= $is('/users/list') ?>" href="<?= e(url('users/list')) ?>">User List</a></li>
            <li><a class="nav-link <?= $is('/users/roles') ?>" href="<?= e(url('users/roles')) ?>">Roles and Permissions</a></li>
        </ul>
    </li>

    <li class="nav-item">
        <button class="nav-link nav-toggle <?= $is('/settings') ?>" data-target="sub-settings">
            <i data-lucide="settings"></i><span>Settings</span>
            <i data-lucide="chevron-down" class="chev"></i>
        </button>
        <ul class="subnav <?= $is('/settings') ? 'open' : '' ?>" id="sub-settings">
            <li><a class="nav-link <?= $is('/settings/business') ?>" href="<?= e(url('settings/business')) ?>">Business Information</a></li>
            <li><a class="nav-link <?= $is('/settings/preferences') ?>" href="<?= e(url('settings/preferences')) ?>">Preferences</a></li>
            <li><a class="nav-link <?= $is('/settings/audit') ?>" href="<?= e(url('settings/audit')) ?>">Audit Logs</a></li>
            <li><a class="nav-link <?= $is('/settings/backup') ?>" href="<?= e(url('settings/backup')) ?>">Backup and Restore</a></li>
        </ul>
    </li>
</ul>