<?php /** @var array $settings */ ?>
<div class="page-header">
    <h2>Preferences</h2>
</div>

<form method="POST" action="<?= e(url('settings/preferences')) ?>" class="panel">
    <?= csrfField() ?>
    <div class="panel-body">
        <div class="row g-3">
            <div class="col-md-4">
                <label class="form-label">Currency Symbol</label>
                <input type="text" name="currency_symbol" class="form-control" maxlength="5" value="<?= e($settings['currency_symbol'] ?? '₱') ?>">
            </div>
            <div class="col-md-4">
                <label class="form-label">Date Format</label>
                <select name="date_format" class="form-select">
                    <?php foreach (['Y-m-d' => '2026-11-06', 'M j, Y' => 'Nov 6, 2026', 'j M Y' => '6 Nov 2026', 'm/d/Y' => '11/06/2026'] as $fmt => $ex): ?>
                        <option value="<?= e($fmt) ?>" <?= ($settings['date_format'] ?? 'Y-m-d')===$fmt?'selected':'' ?>>
                            <?= e($ex) ?> (<?= e($fmt) ?>)
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-4">
                <label class="form-label">Items Per Page</label>
                <input type="number" name="items_per_page" class="form-control" min="5" max="100" value="<?= (int)($settings['items_per_page'] ?? 15) ?>">
            </div>
        </div>
    </div>
    <div class="panel-body border-top d-flex justify-content-end gap-2">
        <button class="btn btn-primary">Save Preferences</button>
    </div>
</form>