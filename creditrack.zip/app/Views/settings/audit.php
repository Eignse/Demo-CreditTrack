<?php /** @var array $result @var array $filters @var array $users @var array $actions */ ?>
<div class="page-header">
    <h2>Audit Logs</h2>
</div>

<form method="GET" class="panel mb-3">
    <div class="panel-body">
        <div class="row g-2 align-items-end">
            <div class="col-md-3">
                <label class="form-label small">Search</label>
                <input type="text" name="q" class="form-control" placeholder="Action or details…" value="<?= e($filters['q']) ?>">
            </div>
            <div class="col-md-2">
                <label class="form-label small">Action</label>
                <select name="action" class="form-select">
                    <option value="">All</option>
                    <?php foreach ($actions as $a): ?>
                        <option value="<?= e($a) ?>" <?= $filters['action']===$a?'selected':'' ?>><?= e($a) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-2">
                <label class="form-label small">User</label>
                <select name="user_id" class="form-select">
                    <option value="">All</option>
                    <?php foreach ($users as $u): ?>
                        <option value="<?= (int)$u['id'] ?>" <?= (string)$filters['user_id']===(string)$u['id']?'selected':'' ?>>
                            <?= e($u['full_name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-2">
                <label class="form-label small">From</label>
                <input type="date" name="date_from" class="form-control" value="<?= e($filters['date_from']) ?>">
            </div>
            <div class="col-md-2">
                <label class="form-label small">To</label>
                <input type="date" name="date_to" class="form-control" value="<?= e($filters['date_to']) ?>">
            </div>
            <div class="col-md-1 d-grid"><button class="btn btn-primary">Go</button></div>
        </div>
    </div>
</form>

<div class="panel">
    <div class="panel-body p-0">
        <?php if (empty($result['rows'])): ?>
            <div class="p-4 text-center text-muted">No activity found.</div>
        <?php else: ?>
            <table class="table table-sm table-hover mb-0 align-middle">
                <thead class="table-light">
                    <tr><th>When</th><th>User</th><th>Action</th><th>Entity</th><th>Details</th><th>IP</th></tr>
                </thead>
                <tbody>
                <?php foreach ($result['rows'] as $r): ?>
                    <tr>
                        <td class="small"><?= e(date('M j, Y H:i', strtotime($r['created_at']))) ?></td>
                        <td class="small"><?= e($r['user_name'] ?? 'System') ?></td>
                        <td><code class="small"><?= e($r['action']) ?></code></td>
                        <td class="small text-muted">
                            <?= e($r['entity_type'] ?? '—') ?>
                            <?php if ($r['entity_id']): ?>
                                #<?= (int)$r['entity_id'] ?>
                            <?php endif; ?>
                        </td>
                        <td class="small"><?= e($r['details'] ?? '') ?></td>
                        <td class="small text-muted"><?= e($r['ip_address'] ?? '') ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
    <?php
    $totalPages = (int)ceil($result['total'] / $result['per_page']);
    if ($totalPages > 1): ?>
    <div class="panel-body d-flex justify-content-between align-items-center border-top">
        <div class="small text-muted">
            Page <?= (int)$result['page'] ?> of <?= $totalPages ?> — <?= (int)$result['total'] ?> entries
        </div>
        <nav><ul class="pagination mb-0">
            <?php for ($p = 1; $p <= $totalPages; $p++): ?>
                <li class="page-item <?= $p === (int)$result['page'] ? 'active' : '' ?>">
                    <a class="page-link" href="?<?= http_build_query(array_merge($filters, ['page'=>$p])) ?>"><?= $p ?></a>
                </li>
            <?php endfor; ?>
        </ul></nav>
    </div>
    <?php endif; ?>
</div>