<?php /** @var array $backups */ ?>
<div class="page-header">
    <h2>Backup and Restore</h2>
</div>

<!-- Create Backup -->
<div class="row g-3 mb-3">
    <div class="col-md-6">
        <div class="panel h-100">
            <div class="panel-header"><h5>Create Backup</h5></div>
            <div class="panel-body">
                <p class="text-muted small">Download the entire database as a .sql file. This works on any MySQL/MariaDB host.</p>
                <div class="d-flex gap-2">
                    <form method="POST" action="<?= e(url('settings/backup/create')) ?>">
                        <?= csrfField() ?>
                        <button class="btn btn-success">
                            <i data-lucide="download"></i> Download Backup
                        </button>
                    </form>
                    <form method="POST" action="<?= e(url('settings/backup/save')) ?>">
                        <?= csrfField() ?>
                        <button class="btn btn-outline-secondary">
                            <i data-lucide="hard-drive"></i> Save on Server
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="panel h-100">
            <div class="panel-header"><h5>Restore from Upload</h5></div>
            <div class="panel-body">
                <p class="text-danger small mb-2"><strong>Warning:</strong> This will replace all current data with the uploaded backup.</p>
                <form method="POST" action="<?= e(url('settings/backup/upload')) ?>" enctype="multipart/form-data"
                      onsubmit="return confirm('This will DESTROY current data and restore from the uploaded file. Continue?');">
                    <?= csrfField() ?>
                    <div class="input-group">
                        <input type="file" name="backup_file" class="form-control" accept=".sql" required>
                        <button class="btn btn-danger">Upload &amp; Restore</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Existing Backups -->
<div class="panel">
    <div class="panel-header"><h5>Stored Backups (<?= count($backups) ?>)</h5></div>
    <div class="panel-body p-0">
        <?php if (empty($backups)): ?>
            <div class="p-4 text-center text-muted">No backups yet. Click "Save on Server" to create one.</div>
        <?php else: ?>
            <table class="table table-hover mb-0 align-middle">
                <thead class="table-light">
                    <tr><th>File</th><th>Created</th><th class="text-end">Size</th><th class="text-end">Actions</th></tr>
                </thead>
                <tbody>
                <?php foreach ($backups as $b): ?>
                    <tr>
                        <td><code><?= e($b['filename']) ?></code></td>
                        <td class="small"><?= e($b['created']) ?></td>
                        <td class="text-end small"><?= number_format($b['size'] / 1024, 1) ?> KB</td>
                        <td class="text-end">
                            <a href="<?= e(url('settings/backup/download?file=' . urlencode($b['filename']))) ?>"
                               class="btn btn-sm btn-outline-primary">
                                <i data-lucide="download" style="width:14px;height:14px;"></i> Download
                            </a>
                            <form method="POST" action="<?= e(url('settings/backup/restore')) ?>" class="d-inline"
                                  onsubmit="return confirm('Restore from <?= e($b['filename']) ?>? All current data will be replaced.');">
                                <?= csrfField() ?>
                                <input type="hidden" name="file" value="<?= e($b['filename']) ?>">
                                <button class="btn btn-sm btn-outline-warning">
                                    <i data-lucide="rotate-ccw" style="width:14px;height:14px;"></i> Restore
                                </button>
                            </form>
                            <form method="POST" action="<?= e(url('settings/backup/delete')) ?>" class="d-inline"
                                  onsubmit="return confirm('Delete this backup file?');">
                                <?= csrfField() ?>
                                <input type="hidden" name="file" value="<?= e($b['filename']) ?>">
                                <button class="btn btn-sm btn-outline-danger">
                                    <i data-lucide="trash-2" style="width:14px;height:14px;"></i>
                                </button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
</div>