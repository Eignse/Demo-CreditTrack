<?php /** @var array $settings */ 
$logo = $settings['business_logo'] ?? '';
?>
<div class="page-header">
    <h2>Business Information</h2>
</div>

<form method="POST" action="<?= e(url('settings/business')) ?>" enctype="multipart/form-data" class="panel">
    <?= csrfField() ?>
    <div class="panel-body">
        <div class="row g-3">
            <div class="col-md-8">
                <label class="form-label">Business Name <span class="text-danger">*</span></label>
                <input type="text" name="business_name" class="form-control" required value="<?= e($settings['business_name'] ?? '') ?>">
            </div>
            <div class="col-md-4">
                <label class="form-label">Phone</label>
                <input type="text" name="business_phone" class="form-control" value="<?= e($settings['business_phone'] ?? '') ?>">
            </div>
            <div class="col-12">
                <label class="form-label">Address</label>
                <input type="text" name="business_address" class="form-control" value="<?= e($settings['business_address'] ?? '') ?>">
            </div>
            <div class="col-md-6">
                <label class="form-label">Email</label>
                <input type="email" name="business_email" class="form-control" value="<?= e($settings['business_email'] ?? '') ?>">
            </div>
            <div class="col-md-6">
                <label class="form-label">Logo</label>
                <input type="file" name="business_logo" class="form-control" accept="image/*">
                <?php if ($logo): ?>
                    <small class="text-muted">Current: <?= e(basename($logo)) ?></small>
                <?php endif; ?>
            </div>
            <div class="col-12">
                <label class="form-label">Receipt Footer</label>
                <input type="text" name="receipt_footer" class="form-control" value="<?= e($settings['receipt_footer'] ?? 'Thank you for your payment.') ?>">
                <small class="text-muted">Printed at the bottom of every receipt.</small>
            </div>
        </div>
    </div>
    <div class="panel-body border-top d-flex justify-content-end gap-2">
        <button class="btn btn-primary">Save Business Information</button>
    </div>
</form>