<div class="page-header"><h2>Access denied</h2></div>
<div class="panel"><div class="panel-body placeholder-body">
    <i data-lucide="shield-alert" class="placeholder-icon"></i>
    <h4>403 — Forbidden</h4>
    <p class="text-muted">You do not have permission to access this resource.</p>
    <a href="<?= e(url('dashboard')) ?>" class="btn btn-primary">Back to dashboard</a>
</div></div>