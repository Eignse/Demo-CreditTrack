<div class="page-header"><h2>Not found</h2></div>
<div class="panel"><div class="panel-body placeholder-body">
    <i data-lucide="search-x" class="placeholder-icon"></i>
    <h4>404 — Page not found</h4>
    <a href="<?= e(url('dashboard')) ?>" class="btn btn-primary">Back to dashboard</a>
</div></div>