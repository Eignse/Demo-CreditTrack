<div class="page-header">
    <h2>Change Password</h2>
    <a href="<?= e(url('dashboard')) ?>" class="btn btn-outline-secondary">Cancel</a>
</div>

<form method="POST" action="<?= e(url('users/password')) ?>" class="panel" style="max-width:520px;">
    <?= csrfField() ?>
    <div class="panel-body">
        <div class="mb-3">
            <label class="form-label">Current Password</label>
            <input type="password" name="current_password" class="form-control" required>
        </div>
        <div class="mb-3">
            <label class="form-label">New Password</label>
            <input type="password" name="new_password" class="form-control" required minlength="8">
            <small class="text-muted">Minimum 8 characters.</small>
        </div>
        <div class="mb-3">
            <label class="form-label">Confirm New Password</label>
            <input type="password" name="confirm_password" class="form-control" required minlength="8">
        </div>
    </div>
    <div class="panel-body border-top d-flex justify-content-end gap-2">
        <a href="<?= e(url('dashboard')) ?>" class="btn btn-outline-secondary">Cancel</a>
        <button type="submit" class="btn btn-primary">Change Password</button>
    </div>
</form>