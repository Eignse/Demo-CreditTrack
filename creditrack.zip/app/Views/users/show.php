<?php /** @var array $user */ ?>
<div class="page-header">
    <div>
        <h2><?= e($user['full_name']) ?></h2>
        <div class="text-muted small"><code><?= e($user['username']) ?></code></div>
    </div>
    <div class="d-flex gap-2">
        <a href="<?= e(url('users')) ?>" class="btn btn-outline-secondary">Back</a>
        <?php if (Acl::can('users.manage')): ?>
            <a href="<?= e(url('users/'.$user['id'].'/edit')) ?>" class="btn btn-primary">Edit</a>
        <?php endif; ?>
    </div>
</div>

<div class="panel">
    <div class="panel-body">
        <dl class="row mb-0">
            <dt class="col-sm-3 text-muted">Full Name</dt><dd class="col-sm-9"><?= e($user['full_name']) ?></dd>
            <dt class="col-sm-3 text-muted">Username</dt><dd class="col-sm-9"><code><?= e($user['username']) ?></code></dd>
            <dt class="col-sm-3 text-muted">Email</dt><dd class="col-sm-9"><?= e($user['email']) ?></dd>
            <dt class="col-sm-3 text-muted">Role</dt>
            <dd class="col-sm-9">
                <span class="badge bg-<?= $user['role_name']==='admin'?'primary':'secondary' ?>">
                    <?= e($user['role_label']) ?>
                </span>
            </dd>
            <dt class="col-sm-3 text-muted">Status</dt>
            <dd class="col-sm-9">
                <?= (int)$user['is_active']===1
                    ? '<span class="badge bg-success">Active</span>'
                    : '<span class="badge bg-secondary">Inactive</span>' ?>
            </dd>
            <dt class="col-sm-3 text-muted">Last Login</dt>
            <dd class="col-sm-9"><?= e($user['last_login_at'] ? date('M j Y H:i', strtotime($user['last_login_at'])) : '—') ?></dd>
            <dt class="col-sm-3 text-muted">Created</dt>
            <dd class="col-sm-9"><?= e(date('M j Y', strtotime($user['created_at']))) ?></dd>
        </dl>
    </div>
</div>