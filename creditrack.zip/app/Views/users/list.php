<?php /** @var array $result @var array $filters */ ?>
<div class="page-header">
    <h2>User List</h2>
    <?php if (Acl::can('users.manage')): ?>
        <a href="<?= e(url('users/create')) ?>" class="btn btn-primary">
            <i data-lucide="plus"></i> New User
        </a>
    <?php endif; ?>
</div>

<form method="GET" class="panel mb-3">
    <div class="panel-body">
        <div class="row g-2 align-items-end">
            <div class="col-md-4">
                <label class="form-label small">Search</label>
                <input type="text" name="q" class="form-control" placeholder="Name, username, email…" value="<?= e($filters['q'] ?? '') ?>">
            </div>
            <div class="col-md-3">
                <label class="form-label small">Role</label>
                <select name="role" class="form-select">
                    <option value="">All Roles</option>
                    <option value="admin" <?= ($filters['role'] ?? '') === 'admin' ? 'selected' : '' ?>>Admin</option>
                    <option value="staff" <?= ($filters['role'] ?? '') === 'staff' ? 'selected' : '' ?>>Staff</option>
                </select>
            </div>
            <div class="col-md-3">
                <label class="form-label small">Status</label>
                <select name="status" class="form-select">
                    <option value="">All Status</option>
                    <option value="active" <?= ($filters['status'] ?? '') === 'active' ? 'selected' : '' ?>>Active</option>
                    <option value="inactive" <?= ($filters['status'] ?? '') === 'inactive' ? 'selected' : '' ?>>Inactive</option>
                </select>
            </div>
            <div class="col-md-2 d-grid">
                <button class="btn btn-primary">Filter</button>
            </div>
        </div>
    </div>
</form>

<div class="panel">
    <div class="panel-body p-0">
        <?php if (empty($result['rows'])): ?>
            <div class="p-4 text-center text-muted">No users found.</div>
        <?php else: ?>
            <table class="table table-hover mb-0 align-middle">
                <thead class="table-light">
                    <tr>
                        <th>Name</th>
                        <th>Username</th>
                        <th>Email</th>
                        <th>Role</th>
                        <th>Status</th>
                        <th>Last Login</th>
                        <th class="text-end">Actions</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($result['rows'] as $u): ?>
                    <tr>
                        <td>
                            <a href="<?= e(url('users/'.$u['id'])) ?>" class="fw-semibold text-decoration-none">
                                <?= e($u['full_name']) ?>
                            </a>
                        </td>
                        <td><code><?= e($u['username']) ?></code></td>
                        <td><?= e($u['email']) ?></td>
                        <td>
                            <?php $badge = ($u['role_name'] ?? '') === 'admin' ? 'primary' : 'secondary'; ?>
                            <span class="badge bg-<?= $badge ?>"><?= e(ucfirst($u['role_name'] ?? 'User')) ?></span>
                        </td>
                        <td>
                            <?php if ((int)($u['is_active'] ?? 0) === 1): ?>
                                <span class="badge bg-success">Active</span>
                            <?php else: ?>
                                <span class="badge bg-danger">Inactive</span>
                            <?php endif; ?>
                        </td>
                        <td class="small text-muted">
                            <?= !empty($u['last_login_at']) ? e(date('M j, Y H:i', strtotime($u['last_login_at']))) : 'Never' ?>
                        </td>
                        <td class="text-end">
                            <a href="<?= e(url('users/'.$u['id'])) ?>" class="btn btn-sm btn-outline-secondary">View</a>
                            <?php if (Acl::can('users.manage')): ?>
                                <a href="<?= e(url('users/'.$u['id'].'/edit')) ?>" class="btn btn-sm btn-outline-primary">Edit</a>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>

    <?php
    $totalPages = (int)ceil(($result['total'] ?? 0) / ($result['per_page'] ?? 15));
    if ($totalPages > 1): ?>
    <div class="panel-body d-flex justify-content-between align-items-center border-top">
        <div class="small text-muted">
            Page <?= (int)($result['page'] ?? 1) ?> of <?= $totalPages ?> — <?= (int)($result['total'] ?? 0) ?> total
        </div>
        <nav>
            <ul class="pagination mb-0">
                <?php for ($p = 1; $p <= $totalPages; $p++): ?>
                    <li class="page-item <?= $p === (int)($result['page'] ?? 1) ? 'active' : '' ?>">
                        <a class="page-link" href="?<?= http_build_query(array_merge($filters ?? [], ['page'=>$p])) ?>"><?= $p ?></a>
                    </li>
                <?php endfor; ?>
            </ul>
        </nav>
    </div>
    <?php endif; ?>
</div>