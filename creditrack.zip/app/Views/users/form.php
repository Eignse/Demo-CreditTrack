<?php /** @var ?array $user @var array $roles */ ?>
<div class="page-header">
    <h2><?= e($title) ?></h2>
    <a href="<?= e(url('users')) ?>" class="btn btn-outline-secondary">Cancel</a>
</div>

<form method="POST"
      action="<?= e($user ? url('users/'.$user['id'].'/update') : url('users')) ?>"
      class="panel">
    <?= csrfField() ?>
    <div class="panel-body">
        <div class="row g-3">
            <div class="col-md-6">
                <label class="form-label">Full Name <span class="text-danger">*</span></label>
                <input type="text" name="full_name" class="form-control" required value="<?= e($user['full_name'] ?? '') ?>">
            </div>
            <div class="col-md-6">
                <label class="form-label">Username <?= $user ? '(cannot be changed)' : '<span class="text-danger">*</span>' ?></label>
                <input type="text" name="username" class="form-control" value="<?= e($user['username'] ?? '') ?>"
                       <?= $user ? 'readonly' : 'required' ?>>
            </div>

            <div class="col-md-6">
                <label class="form-label">Email <span class="text-danger">*</span></label>
                <input type="email" name="email" class="form-control" required value="<?= e($user['email'] ?? '') ?>">
            </div>
            <div class="col-md-6">
                <label class="form-label">Role <span class="text-danger">*</span></label>
                <select name="role" class="form-select" required>
                    <?php foreach ($roles as $r): ?>
                        <option value="<?= e($r['name']) ?>" <?= ($user['role_name'] ?? 'staff')===$r['name']?'selected':'' ?>>
                            <?= e($r['label']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="col-md-6">
                <label class="form-label">
                    <?= $user ? 'New Password (leave blank to keep current)' : 'Password <span class="text-danger">*</span>' ?>
                </label>
                <input type="password" name="password" class="form-control" <?= $user ? '' : 'required' ?> minlength="8" autocomplete="new-password">
                <small class="text-muted">Minimum 8 characters.</small>
            </div>
            <div class="col-md-6">
                <label class="form-label">Status</label>
                <select name="is_active" class="form-select">
                    <option value="1" <?= !isset($user) || $user['is_active'] ? 'selected' : '' ?>>Active</option>
                    <option value="0" <?= isset($user) && !$user['is_active'] ? 'selected' : '' ?>>Inactive</option>
                </select>
            </div>
        </div>
    </div>
    <div class="panel-body border-top d-flex justify-content-end gap-2">
        <a href="<?= e(url('users')) ?>" class="btn btn-outline-secondary">Cancel</a>
        <button type="submit" class="btn btn-primary">Save User</button>
    </div>
</form>