<?php /** @var array $roles @var array $rolePermissions */ ?>
<div class="page-header">
    <h2>Roles and Permissions</h2>
</div>

<div class="row g-3">
    <?php foreach ($roles as $role): ?>
        <div class="col-md-6 col-lg-4">
            <div class="panel h-100">
                <div class="panel-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0"><?= e($role['label']) ?></h5>
                    <span class="badge bg-<?= $role['name'] === 'admin' ? 'primary' : 'secondary' ?>">
                        <?= e($role['name']) ?>
                    </span>
                </div>
                <div class="panel-body">
                    <p class="text-muted small mb-3"><?= e($role['description'] ?: 'No description.') ?></p>
                    
                    <h6 class="text-uppercase text-muted small fw-bold mb-2">Permissions</h6>
                    <ul class="list-unstyled mb-0">
                        <?php 
                        $perms = $rolePermissions[$role['name']] ?? [];
                        if (empty($perms)):
                        ?>
                            <li class="text-muted small">No permissions assigned.</li>
                        <?php else: ?>
                            <?php foreach ($perms as $p): ?>
                                <li class="mb-1 d-flex align-items-center gap-2">
                                    <i data-lucide="check-circle-2" style="width:14px;height:14px;color:#198754;"></i>
                                    <code class="small"><?= e($p) ?></code>
                                </li>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </div>
    <?php endforeach; ?>
</div>

<div class="alert alert-info mt-4 small">
    <strong>Note:</strong> Permissions are currently hardcoded to the <strong>Admin</strong> and <strong>Staff</strong> roles. 
    To change what a role can do, you can modify the <code>role_permissions</code> table in the database.
</div>