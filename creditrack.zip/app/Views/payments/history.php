<?php /** @var array $result @var array $filters */ ?>
<div class="page-header">
    <h2>Payment History</h2>
</div>

<form method="GET" class="panel mb-3">
    <div class="panel-body">
        <div class="row g-2 align-items-end">
            <div class="col-md-4">
                <label class="form-label small">Search</label>
                <input type="text" name="q" class="form-control" placeholder="Receipt, loan, client…" value="<?= e($filters['q']) ?>">
            </div>
            <div class="col-md-3">
                <label class="form-label small">From</label>
                <input type="date" name="date_from" class="form-control" value="<?= e($filters['date_from']) ?>">
            </div>
            <div class="col-md-3">
                <label class="form-label small">To</label>
                <input type="date" name="date_to" class="form-control" value="<?= e($filters['date_to']) ?>">
            </div>
            <div class="col-md-2 d-grid"><button class="btn btn-primary">Filter</button></div>
        </div>
    </div>
</form>

<div class="panel">
    <div class="panel-body p-0">
        <?php if (empty($result['rows'])): ?>
            <div class="p-4 text-center text-muted">No payments found.</div>
        <?php else: ?>
            <table class="table table-hover mb-0">
                <thead class="table-light">
                    <tr><th>Receipt #</th><th>Date</th><th>Client</th><th>Loan</th><th>Amount</th><th>Method</th><th class="text-end">Actions</th></tr>
                </thead>
                <tbody>
                <?php foreach ($result['rows'] as $p): ?>
                    <tr>
                        <td><code><?= e($p['receipt_no']) ?></code></td>
                        <td><?= e($p['payment_date']) ?></td>
                        <td><?= e($p['client_name']) ?></td>
                        <td><code><?= e($p['loan_code']) ?></code></td>
                        <td class="fw-semibold text-success">₱<?= number_format((float)$p['amount'], 2) ?></td>
                        <td><?= e(ucfirst($p['payment_method'])) ?></td>
                        <td class="text-end">
                            <a href="<?= e(url('payments/'.$p['id'])) ?>" class="btn btn-sm btn-outline-secondary">View</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
</div>