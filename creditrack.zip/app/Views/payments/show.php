<?php /** @var array $payment @var array $allocations */ ?>
<div class="page-header d-print-none">
    <h2>Receipt <?= e($payment['receipt_no']) ?></h2>
    <div class="d-flex gap-2">
        <?php if (!$payment['voided_at'] && Acl::can('payments.void')): ?>
            <a href="<?= e(url('payments/'.$payment['id'].'/void')) ?>" class="btn btn-outline-danger">
                <i data-lucide="x-circle"></i> Void Payment
            </a>
        <?php endif; ?>
        <a href="<?= e(url('payments')) ?>" class="btn btn-outline-secondary">Back</a>
        <button onclick="window.print()" class="btn btn-primary">
            <i data-lucide="printer"></i> Print
        </button>
    </div>
</div>

<div class="panel">
    <div class="panel-body">
        <?php if ($payment['voided_at']): ?>
            <div class="alert alert-danger text-center mb-4">
                <h2 class="mb-1">*** VOIDED ***</h2>
                <p class="mb-0">Reason: <?= e($payment['void_reason']) ?></p>
                <small>Voided by: <?= e($payment['voided_by_name'] ?? 'System') ?> on <?= e(date('M j, Y H:i', strtotime($payment['voided_at']))) ?></small>
            </div>
        <?php endif; ?>

        <!-- Receipt Header -->
        <div class="text-center mb-4">
            <?php if ($logo = Settings::get('business_logo')): ?>
                <img src="<?= e(url($logo)) ?>" alt="" style="max-height:70px;" class="mb-2">
            <?php endif; ?>
            <h3 class="mb-1"><?= e(Settings::get('business_name', APP_NAME)) ?></h3>
            <?php if ($addr = Settings::get('business_address')): ?>
                <p class="text-muted small mb-0"><?= e($addr) ?></p>
            <?php endif; ?>
            <?php if ($ph = Settings::get('business_phone')): ?>
                <p class="text-muted small mb-0"><?= e($ph) ?></p>
            <?php endif; ?>
            <hr>
            <h4>OFFICIAL RECEIPT</h4>
            <p class="mb-0"><strong><?= e($payment['receipt_no']) ?></strong></p>
        </div>

        <!-- Payment Details -->
        <div class="row mb-3">
            <div class="col-md-6">
                <table class="table table-sm table-borderless mb-0">
                    <tr><th width="40%">Client</th><td><?= e($payment['client_name']) ?> (<?= e($payment['client_code']) ?>)</td></tr>
                    <tr><th>Phone</th><td><?= e($payment['phone'] ?: '—') ?></td></tr>
                    <tr><th>Loan</th><td><code><?= e($payment['loan_code']) ?></code></td></tr>
                </table>
            </div>
            <div class="col-md-6">
                <table class="table table-sm table-borderless mb-0">
                    <tr><th width="40%">Date</th><td><?= e($payment['payment_date']) ?></td></tr>
                    <tr><th>Method</th><td><?= e(ucfirst($payment['payment_method'])) ?></td></tr>
                    <tr><th>Received By</th><td><?= e($payment['received_by_name'] ?: '—') ?></td></tr>
                    <?php if ($payment['reference_no']): ?>
                    <tr><th>Reference</th><td><?= e($payment['reference_no']) ?></td></tr>
                    <?php endif; ?>
                </table>
            </div>
        </div>

        <!-- Allocations Table -->
        <table class="table table-bordered">
            <thead class="table-light">
                <tr><th>#</th><th>Due Date</th><th class="text-end">Installment Amount</th><th class="text-end">Applied Here</th></tr>
            </thead>
            <tbody>
            <?php if (empty($allocations)): ?>
                <tr>
                    <td colspan="4" class="text-center text-muted small py-3">
                        No installment allocations (payoff or unallocated payment).
                    </td>
                </tr>
            <?php else: ?>
                <?php foreach ($allocations as $a): ?>
                    <tr>
                        <td><?= (int)$a['installment_no'] ?></td>
                        <td><?= e($a['due_date']) ?></td>
                        <td class="text-end"><?= Settings::money((float)$a['total_due']) ?></td>
                        <td class="text-end"><?= Settings::money((float)$a['amount_applied']) ?></td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
            </tbody>
            <tfoot>
                <tr>
                    <th colspan="3" class="text-end">TOTAL PAID</th>
                    <th class="text-end"><?= Settings::money((float)$payment['amount']) ?></th>
                </tr>
            </tfoot>
        </table>

        <?php if ($payment['notes']): ?>
            <p class="small text-muted"><strong>Notes:</strong> <?= e($payment['notes']) ?></p>
        <?php endif; ?>

        <!-- Receipt Footer -->
        <div class="text-center small text-muted mt-4">
            <?= e(Settings::get('receipt_footer', 'Thank you for your payment.')) ?>
        </div>
    </div>
</div>

<style>
@media print {
    .sidebar, .topbar, .d-print-none { display: none !important; }
    .main-content { margin-left: 0 !important; }
    .panel { border: none !important; box-shadow: none !important; }
    /* Keep the VOIDED banner visible in print */
    .alert { border: 2px solid #dc3545 !important; }
}
</style>