<?php /** @var array $result @var string $date */ ?>
<div class="page-header">
    <h2>Daily Transactions</h2>
    <form method="GET" class="d-flex gap-2">
        <input type="date" name="date" class="form-control" value="<?= e($date) ?>">
        <button class="btn btn-primary">Go</button>
    </form>
</div>

<div class="panel">
    <div class="panel-body p-0">
        <?php if (empty($result['rows'])): ?>
            <div class="p-4 text-center text-muted">No payments on <?= e($date) ?>.</div>
        <?php else: ?>
            <table class="table table-hover mb-0">
                <thead class="table-light">
                    <tr><th>Receipt #</th><th>Time</th><th>Client</th><th>Loan</th><th>Amount</th><th>Method</th><th class="text-end">Actions</th></tr>
                </thead>
                <tbody>
                <?php $total = 0; foreach ($result['rows'] as $p): $total += (float)$p['amount']; ?>
                    <tr>
                        <td><code><?= e($p['receipt_no']) ?></code></td>
                        <td class="small"><?= e(date('H:i', strtotime($p['created_at']))) ?></td>
                        <td><?= e($p['client_name']) ?></td>
                        <td><code><?= e($p['loan_code']) ?></code></td>
                        <td class="fw-semibold">₱<?= number_format((float)$p['amount'], 2) ?></td>
                        <td><?= e(ucfirst($p['payment_method'])) ?></td>
                        <td class="text-end">
                            <a href="<?= e(url('payments/'.$p['id'])) ?>" class="btn btn-sm btn-outline-secondary">View</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
                <tfoot>
                    <tr class="table-light">
                        <th colspan="4" class="text-end">Daily Total</th>
                        <th colspan="3">₱<?= number_format($total, 2) ?></th>
                    </tr>
                </tfoot>
            </table>
        <?php endif; ?>
    </div>
</div>