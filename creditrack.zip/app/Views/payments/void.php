<?php /** @var array $payment */ ?>
<div class="page-header">
    <h2>Void Payment <?= e($payment['receipt_no']) ?></h2>
    <a href="<?= e(url('payments/'.$payment['id'])) ?>" class="btn btn-outline-secondary">Cancel</a>
</div>
<div class="alert alert-warning">
    <strong>This reverses the payment.</strong>
    Loan balance increases by <?= e(Settings::money((float)$payment['amount'])) ?>. Receipt stays with a VOID stamp.
</div>
<form method="POST" action="<?= e(url('payments/void')) ?>" class="panel">
    <?= csrfField() ?>
    <input type="hidden" name="payment_id" value="<?= (int)$payment['id'] ?>">
    <div class="panel-body">
        <dl class="row mb-3">
            <dt class="col-sm-3 text-muted">Receipt</dt><dd class="col-sm-9"><?= e($payment['receipt_no']) ?></dd>
            <dt class="col-sm-3 text-muted">Client</dt><dd class="col-sm-9"><?= e($payment['client_name']) ?></dd>
            <dt class="col-sm-3 text-muted">Amount</dt><dd class="col-sm-9 text-danger fw-semibold"><?= e(Settings::money((float)$payment['amount'])) ?></dd>
        </dl>
        <label class="form-label">Reason <span class="text-danger">*</span></label>
        <textarea name="reason" class="form-control" rows="2" required></textarea>
    </div>
    <div class="panel-body border-top d-flex justify-content-end gap-2">
        <a href="<?= e(url('payments/'.$payment['id'])) ?>" class="btn btn-outline-secondary">Cancel</a>
        <button class="btn btn-danger" onclick="return confirm('Void this payment?')">Void Payment</button>
    </div>
</form>