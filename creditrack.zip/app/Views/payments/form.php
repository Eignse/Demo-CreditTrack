<?php /** @var array $loans @var int $preselectLoan */ ?>
<div class="page-header">
    <h2>Record Payment</h2>
    <a href="<?= e(url('payments')) ?>" class="btn btn-outline-secondary">Cancel</a>
</div>

<form method="POST" action="<?= e(url('payments')) ?>" class="panel">
    <?= csrfField() ?>
    <div class="panel-body">
        <div class="row g-3">
            <div class="col-12">
                <label class="form-label">Loan <span class="text-danger">*</span></label>
                <select name="loan_id" id="loanSelect" class="form-select" required>
                    <option value="">— Select active loan —</option>
                    <?php foreach ($loans as $l): ?>
                        <option value="<?= (int)$l['id'] ?>" <?= $preselectLoan === (int)$l['id'] ? 'selected' : '' ?>>
                            <?= e($l['loan_code']) ?> — <?= e($l['client_name']) ?> — ₱<?= number_format((float)$l['balance'], 2) ?> remaining
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="col-md-4">
                <label class="form-label">Amount (₱) <span class="text-danger">*</span></label>
                <input type="number" name="amount" id="amountInput" class="form-control" step="0.01" min="0.01" required>
                <small class="text-muted" id="balanceHint"></small>
            </div>
            <div class="col-md-4">
                <label class="form-label">Payment Date <span class="text-danger">*</span></label>
                <input type="date" name="payment_date" class="form-control" value="<?= date('Y-m-d') ?>" required>
            </div>
            <div class="col-md-4">
                <label class="form-label">Payment Method <span class="text-danger">*</span></label>
                <select name="payment_method" class="form-select" required>
                    <option value="cash">Cash</option>
                    <option value="gcash">GCash</option>
                    <option value="bank">Bank Transfer</option>
                    <option value="other">Other</option>
                </select>
            </div>

            <div class="col-md-6">
                <label class="form-label">Reference No. (optional)</label>
                <input type="text" name="reference_no" class="form-control" placeholder="e.g. GCash ref#">
            </div>
            <div class="col-md-6">
                <label class="form-label">Notes</label>
                <input type="text" name="notes" class="form-control">
            </div>
        </div>
        <div class="alert alert-info mt-3 small mb-0">
            Payment will be automatically allocated to the oldest unpaid installments.
        </div>
    </div>
    <div class="panel-body border-top d-flex justify-content-end gap-2">
        <a href="<?= e(url('payments')) ?>" class="btn btn-outline-secondary">Cancel</a>
        <button type="submit" class="btn btn-primary">Record Payment</button>
    </div>
</form>

<script>
document.addEventListener('DOMContentLoaded', () => {
    const loanSelect = document.getElementById('loanSelect');
    const amountInput = document.getElementById('amountInput');
    const balanceHint = document.getElementById('balanceHint');

    async function updateHint() {
        const id = loanSelect.value;
        if (!id) { balanceHint.textContent = ''; return; }
        try {
            const res = await fetch('<?= e(url('payments/loan-info')) ?>?loan_id=' + id);
            const data = await res.json();
            if (data.balance !== undefined) {
                balanceHint.textContent = 'Remaining balance: ₱' + data.balance.toLocaleString(undefined, {minimumFractionDigits:2});
                amountInput.max = data.balance;
            }
        } catch (e) { balanceHint.textContent = ''; }
    }
    loanSelect.addEventListener('change', updateHint);
    updateHint();
});
</script>