<?php /** @var array $demo @var array $recent @var array $groupSummary @var array $chartLabels @var array $chartData */ ?>
<div class="page-header">
    <h2>Dashboard</h2>
    <div class="text-muted small">Welcome back, <?= e(Auth::user()['full_name']) ?></div>
</div>

<div class="row g-3 mb-3">
    <?php
    $cards = [
        ['Total Clients',          $demo['total_clients'],       'users',           'navy'],
        ['Active Accounts',        $demo['active_accounts'],     'credit-card',     'amber'],
        ['Outstanding Balance',    Settings::money($demo['outstanding_balance']), 'scale', 'danger'],
        ["Today's Collection",     Settings::money($demo['todays_collection']),  'wallet', 'success'],
        ['Transactions Today',     $demo['transactions_today'],  'receipt',         'info'],
    ];
    foreach ($cards as [$label, $val, $icon, $color]): ?>
        <div class="col-md-6 col-xl-3 col-xxl-3"> <!-- Fixed col-xxl typo -->
            <div class="stat-card">
                <div class="stat-icon text-<?= $color ?>"><i data-lucide="<?= $icon ?>"></i></div>
                <div>
                    <div class="stat-label"><?= e($label) ?></div>
                    <div class="stat-value"><?= e((string)$val) ?></div>
                </div>
            </div>
        </div>
    <?php endforeach; ?>
</div>

<div class="row g-3">
    <div class="col-lg-8">
        <div class="panel">
            <div class="panel-header"><h5>Collection Trend (Last 7 Days)</h5></div>
            <div class="panel-body"><canvas id="collectionChart" height="120"></canvas></div>
        </div>
    </div>
    <div class="col-lg-4">
        <div class="panel">
            <div class="panel-header"><h5>Recent Activity</h5></div>
            <div class="panel-body">
                <?php if (empty($recent)): ?>
                    <p class="text-muted small mb-0">No activity yet.</p>
                <?php else: ?>
                    <ul class="list-unstyled small mb-0">
                    <?php foreach ($recent as $r): ?>
                        <li class="d-flex justify-content-between border-bottom py-2">
                            <span><?= e($r['user_name'] ?? 'System') ?> — <code><?= e($r['action']) ?></code></span>
                            <span class="text-muted"><?= e(date('M j H:i', strtotime($r['created_at']))) ?></span>
                        </li>
                    <?php endforeach; ?>
                    </ul>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<div class="row g-3 mt-1">
    <div class="col-12">
        <div class="panel">
            <div class="panel-header d-flex justify-content-between align-items-center">
                <h5>Group Collection Summary</h5>
                <a href="<?= e(url('groups')) ?>" class="btn btn-sm btn-outline-secondary">View All Groups</a>
            </div>
            <div class="panel-body p-0">
                <?php if (empty($groupSummary)): ?>
                    <div class="p-4 text-center text-muted small">
                        No active loans in any group yet. Assign clients to groups and create loans to see summaries here.
                    </div>
                <?php else: ?>
                    <table class="table table-sm table-hover mb-0 align-middle">
                        <thead class="table-light">
                            <tr>
                                <th>Group</th>
                                <th class="text-center">Active Loans</th>
                                <th class="text-end">Expected</th>
                                <th class="text-end">Collected</th>
                                <th class="text-end">Balance</th>
                                <th>Progress</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php foreach ($groupSummary as $g): 
                            $expected = (float)$g['expected_total'];
                            $collected = (float)$g['collected_total'];
                            $pct = $expected > 0 ? round(($collected / $expected) * 100) : 0;
                        ?>
                            <tr>
                                <td>
                                    <a href="<?= e(url('groups/'.$g['id'])) ?>" class="fw-semibold text-decoration-none">
                                        <?= e($g['name']) ?>
                                    </a>
                                    <div class="small text-muted"><?= e($g['code']) ?></div>
                                </td>
                                <td class="text-center"><span class="badge bg-secondary"><?= (int)$g['loan_count'] ?></span></td>
                                <td class="text-end"><?= e(Settings::money($expected)) ?></td>
                                <td class="text-end text-success"><?= e(Settings::money($collected)) ?></td>
                                <td class="text-end text-danger fw-semibold"><?= e(Settings::money((float)$g['balance_total'])) ?></td>
                                <td style="min-width:120px;">
                                    <div class="progress" style="height:6px;">
                                        <div class="progress-bar bg-success" role="progressbar" style="width: <?= $pct ?>%"></div>
                                    </div>
                                    <div class="small text-muted mt-1"><?= $pct ?>% collected</div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.3/dist/chart.umd.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded', () => {
    const ctx = document.getElementById('collectionChart');
    if (!ctx) return;
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: <?= json_encode($chartLabels) ?>,
            datasets: [{
                label: 'Collections',
                data: <?= json_encode($chartData) ?>,
                borderColor: '#0f2a5c',
                backgroundColor: 'rgba(15,42,92,0.08)',
                tension: 0.3,
                fill: true,
            }]
        },
        options: {
            plugins: { 
                legend: { display: false },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return '₱' + context.parsed.y.toLocaleString(undefined, {minimumFractionDigits: 2});
                        }
                    }
                }
            },
            scales: { 
                y: { 
                    beginAtZero: true,
                    ticks: {
                        callback: function(value) { return '₱' + value; }
                    }
                } 
            },
            responsive: true,
        }
    });
});
</script>