<form method="POST" action="<?= e(url('login')) ?>" autocomplete="off" novalidate>
    <?= csrfField() ?>
    <div class="mb-3">
        <label class="form-label">Username or Email</label>
        <input type="text" name="username" class="form-control" required autofocus>
    </div>
    <div class="mb-3">
        <label class="form-label">Password</label>
        <input type="password" name="password" class="form-control" required>
    </div>
    <button type="submit" class="btn btn-primary w-100">Sign in</button>
</form>