<?php 
/** @var array $data @var array $filters @var array $clients */ 
$total = $data['total'] ?? 0.00;
$count = $data['count'] ?? 0;
$rows = $data['rows'] ?? [];
$selectedClient = $filters['client_id'] ?? '';
?>
<div class="page-header">
    <h2>Client Payment Report</h2>
    <a href="<?= e(url('reports/client/export')) ?>?<?= http_build_query($filters) ?>" class="btn btn-outline-success">
        <i data-lucide="download"></i> Export CSV
    </a>
</div>

<form method="GET" class="panel mb-3">
    <div class="panel-body">
        <div class="row g-2 align-items-end">
            <div class="col-md-4">
                <label class="form-label small">Client</label>
                <select name="client_id" class="form-select">
                    <option value="">All clients</option>
                    <?php foreach ($clients as $c): ?>
                        <option value="<?= (int)$c['id'] ?>" <?= (string)$selectedClient === (string)$c['id'] ? 'selected' : '' ?>>
                            <?= e($c['full_name']) ?> (<?= e($c['client_code']) ?>)
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-3">
                <label class="form-label small">From</label>
                <input type="date" name="date_from" class="form-control" value="<?= e($filters['date_from']) ?>">
            </div>
            <div class="col-md-3">
                <label class="form-label small">To</label>
                <input type="date" name="date_to" class="form-control" value="<?= e($filters['date_to']) ?>">
            </div>
            <div class="col-md-2 d-grid"><button class="btn btn-primary">Filter</button></div>
        </div>
    </div>
</form>

<div class="row g-3 mb-3">
    <div class="col-md-6">
        <div class="stat-card">
            <div class="stat-icon text-success"><i data-lucide="wallet"></i></div>
            <div>
                <div class="stat-label">Total Payments</div>
                <div class="stat-value"><?= e(Settings::money((float)$total)) ?></div>
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="stat-card">
            <div class="stat-icon text-info"><i data-lucide="receipt"></i></div>
            <div>
                <div class="stat-label">Payment Count</div>
                <div class="stat-value"><?= (int)$count ?></div>
            </div>
        </div>
    </div>
</div>

<div class="panel">
    <div class="panel-body p-0">
        <?php if (empty($rows)): ?>
            <div class="p-4 text-center text-muted">No payments found for these filters.</div>
        <?php else: ?>
            <table class="table table-hover mb-0 align-middle">
                <thead class="table-light">
                    <tr><th>Date</th><th>Receipt</th><th>Client</th><th>Loan</th>
                        <th>Amount</th><th>Method</th><th>Collector</th></tr>
                </thead>
                <tbody>
                <?php foreach ($rows as $r): ?>
                    <tr>
                        <td><?= e($r['payment_date'] ?? '') ?></td>
                        <td><a href="<?= e(url('payments/'.$r['id'])) ?>"><code><?= e($r['receipt_no'] ?? '') ?></code></a></td>
                        <td>
                            <a href="<?= e(url('clients/'.$r['client_id'])) ?>" class="text-decoration-none"><?= e($r['client_name'] ?? '') ?></a>
                            <div class="small text-muted"><?= e($r['client_code'] ?? '') ?></div>
                        </td>
                        <td><code><?= e($r['loan_code'] ?? '') ?></code></td>
                        <td class="text-success fw-semibold"><?= e(Settings::money((float)($r['amount'] ?? 0))) ?></td>
                        <td><span class="badge bg-light text-dark"><?= e(ucfirst($r['payment_method'] ?? '')) ?></span></td>
                        <td class="small"><?= e($r['collector'] ?? '—') ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
</div>