<?php 
/** @var array $data @var array $filters @var array $groups */ 
$expected = $data['expected'] ?? 0.00;
$collected = $data['collected'] ?? 0.00;
$balance = $data['balance'] ?? 0.00;
$rows = $data['rows'] ?? [];
$selectedGroup = $filters['group_id'] ?? '';
?>
<div class="page-header">
    <h2>Group Collection Report</h2>
    <a href="<?= e(url('reports/group/export')) ?>?<?= http_build_query($filters) ?>" class="btn btn-outline-success">
        <i data-lucide="download"></i> Export CSV
    </a>
</div>

<form method="GET" class="panel mb-3">
    <div class="panel-body">
        <div class="row g-2 align-items-end">
            <div class="col-md-6">
                <label class="form-label small">Group</label>
                <select name="group_id" class="form-select">
                    <option value="">All groups</option>
                    <?php foreach ($groups as $g): ?>
                        <option value="<?= (int)$g['id'] ?>" <?= (string)$selectedGroup === (string)$g['id'] ? 'selected' : '' ?>>
                            <?= e($g['name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-2 d-grid"><button class="btn btn-primary">Filter</button></div>
        </div>
    </div>
</form>

<div class="row g-3 mb-3">
    <?php
    $cards = [
        ['Total Expected',  Settings::money((float)$expected), 'scale', 'navy'],
        ['Total Collected', Settings::money((float)$collected), 'wallet', 'success'],
        ['Total Balance',   Settings::money((float)$balance), 'circle-dollar-sign', 'danger'],
    ];
    foreach ($cards as [$label, $val, $icon, $color]): ?>
        <div class="col-md-4">
            <div class="stat-card">
                <div class="stat-icon text-<?= $color ?>"><i data-lucide="<?= $icon ?>"></i></div>
                <div>
                    <div class="stat-label"><?= e($label) ?></div>
                    <div class="stat-value"><?= e($val) ?></div>
                </div>
            </div>
        </div>
    <?php endforeach; ?>
</div>

<div class="panel">
    <div class="panel-body p-0">
        <?php if (empty($rows)): ?>
            <div class="p-4 text-center text-muted">No groups with data.</div>
        <?php else: ?>
            <table class="table table-hover mb-0 align-middle">
                <thead class="table-light">
                    <tr><th>Group</th><th>Collector</th><th class="text-center">Members</th>
                        <th class="text-center">Loans</th><th class="text-end">Expected</th>
                        <th class="text-end">Collected</th><th class="text-end">Balance</th></tr>
                </thead>
                <tbody>
                <?php foreach ($rows as $r): ?>
                    <tr>
                        <td>
                            <a href="<?= e(url('groups/'.$r['id'])) ?>" class="fw-semibold text-decoration-none"><?= e($r['name'] ?? '') ?></a>
                            <div class="small text-muted"><?= e($r['code'] ?? '') ?></div>
                        </td>
                        <td><?= e($r['collector'] ?? '—') ?></td>
                        <td class="text-center"><span class="badge bg-secondary"><?= (int)($r['member_count'] ?? 0) ?></span></td>
                        <td class="text-center"><?= (int)($r['loan_count'] ?? 0) ?></td>
                        <td class="text-end"><?= e(Settings::money((float)($r['expected'] ?? 0))) ?></td>
                        <td class="text-end text-success"><?= e(Settings::money((float)($r['collected'] ?? 0))) ?></td>
                        <td class="text-end text-danger fw-semibold"><?= e(Settings::money((float)($r['balance'] ?? 0))) ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
</div>