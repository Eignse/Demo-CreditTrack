<?php 
/** @var array $data @var array $filters @var array $collectors */ 
$totalCollected = $data['total_collected'] ?? 0.00;
$totalCount = $data['total_count'] ?? 0;
$rows = $data['rows'] ?? [];
$selectedCollector = $filters['collector_id'] ?? '';
?>
<div class="page-header">
    <h2>Daily Collection Report</h2>
    <a href="<?= e(url('reports/daily/export')) ?>?<?= http_build_query($filters) ?>" class="btn btn-outline-success">
        <i data-lucide="download"></i> Export CSV
    </a>
</div>

<form method="GET" class="panel mb-3">
    <div class="panel-body">
        <div class="row g-2 align-items-end">
            <div class="col-md-3">
                <label class="form-label small">From</label>
                <input type="date" name="date_from" class="form-control" value="<?= e($filters['date_from']) ?>">
            </div>
            <div class="col-md-3">
                <label class="form-label small">To</label>
                <input type="date" name="date_to" class="form-control" value="<?= e($filters['date_to']) ?>">
            </div>
            <div class="col-md-4">
                <label class="form-label small">Collector</label>
                <select name="collector_id" class="form-select">
                    <option value="">All collectors</option>
                    <?php foreach ($collectors as $c): ?>
                        <option value="<?= (int)$c['id'] ?>" <?= (string)$selectedCollector === (string)$c['id'] ? 'selected' : '' ?>>
                            <?= e($c['full_name']) ?> (<?= e($c['role']) ?>)
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-2 d-grid">
                <button class="btn btn-primary">Filter</button>
            </div>
        </div>
    </div>
</form>

<div class="row g-3 mb-3">
    <div class="col-md-6">
        <div class="stat-card">
            <div class="stat-icon text-success"><i data-lucide="wallet"></i></div>
            <div>
                <div class="stat-label">Total Collected</div>
                <div class="stat-value"><?= e(Settings::money((float)$totalCollected)) ?></div>
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="stat-card">
            <div class="stat-icon text-info"><i data-lucide="receipt"></i></div>
            <div>
                <div class="stat-label">Payments Recorded</div>
                <div class="stat-value"><?= (int)$totalCount ?></div>
            </div>
        </div>
    </div>
</div>

<div class="panel">
    <div class="panel-body p-0">
        <?php if (empty($rows)): ?>
            <div class="p-4 text-center text-muted">No collections in this period.</div>
        <?php else: ?>
            <table class="table table-hover mb-0">
                <thead class="table-light">
                    <tr><th>Date</th><th>Collector</th><th class="text-center">Payments</th><th class="text-end">Amount</th></tr>
                </thead>
                <tbody>
                <?php foreach ($rows as $r): ?>
                    <tr>
                        <td><?= e($r['payment_date'] ?? '') ?></td>
                        <td><?= e($r['collector_name'] ?? '') ?></td>
                        <td class="text-center"><?= (int)($r['payment_count'] ?? 0) ?></td>
                        <td class="text-end fw-semibold"><?= e(Settings::money((float)($r['total_collected'] ?? 0))) ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
</div>