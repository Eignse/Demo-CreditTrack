<?php 
/** @var array $data @var array $filters @var array $groups */ 
$total = $data['total'] ?? 0.00;
$count = $data['count'] ?? 0;
$rows = $data['rows'] ?? [];
$selectedGroup = $filters['group_id'] ?? '';
?>
<div class="page-header">
    <h2>Outstanding Balance Report</h2>
    <a href="<?= e(url('reports/outstanding/export')) ?>?<?= http_build_query($filters) ?>" class="btn btn-outline-success">
        <i data-lucide="download"></i> Export CSV
    </a>
</div>

<form method="GET" class="panel mb-3">
    <div class="panel-body">
        <div class="row g-2 align-items-end">
            <div class="col-md-6">
                <label class="form-label small">Group</label>
                <select name="group_id" class="form-select">
                    <option value="">All groups</option>
                    <?php foreach ($groups as $g): ?>
                        <option value="<?= (int)$g['id'] ?>" <?= (string)$selectedGroup === (string)$g['id'] ? 'selected' : '' ?>>
                            <?= e($g['name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-2 d-grid"><button class="btn btn-primary">Filter</button></div>
        </div>
    </div>
</form>

<div class="row g-3 mb-3">
    <div class="col-md-6">
        <div class="stat-card">
            <div class="stat-icon text-danger"><i data-lucide="circle-dollar-sign"></i></div>
            <div>
                <div class="stat-label">Total Outstanding</div>
                <div class="stat-value"><?= e(Settings::money((float)$total)) ?></div>
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="stat-card">
            <div class="stat-icon text-info"><i data-lucide="credit-card"></i></div>
            <div>
                <div class="stat-label">Active Loans</div>
                <div class="stat-value"><?= (int)$count ?></div>
            </div>
        </div>
    </div>
</div>

<div class="panel">
    <div class="panel-body p-0">
        <?php if (empty($rows)): ?>
            <div class="p-4 text-center text-muted">No active loans.</div>
        <?php else: ?>
            <table class="table table-hover mb-0 align-middle">
                <thead class="table-light">
                    <tr><th>Loan</th><th>Client</th><th>Group</th><th>Collector</th>
                        <th class="text-end">Principal</th><th class="text-end">Balance</th>
                        <th>Maturity</th><th class="text-center">Overdue</th></tr>
                </thead>
                <tbody>
                <?php foreach ($rows as $r): ?>
                    <tr>
                        <td><a href="<?= e(url('loans/'.$r['loan_id'])) ?>"><code><?= e($r['loan_code'] ?? '') ?></code></a></td>
                        <td>
                            <a href="<?= e(url('clients/'.$r['client_id'])) ?>" class="text-decoration-none"><?= e($r['client_name'] ?? '') ?></a>
                            <div class="small text-muted"><?= e($r['client_code'] ?? '') ?></div>
                        </td>
                        <td><?= e($r['group_name'] ?? '—') ?></td>
                        <td class="small"><?= e($r['collector'] ?? '—') ?></td>
                        <td class="text-end"><?= e(Settings::money((float)($r['principal'] ?? 0))) ?></td>
                        <td class="text-end text-danger fw-semibold"><?= e(Settings::money((float)($r['balance'] ?? 0))) ?></td>
                        <td class="small">
                            <?= e($r['maturity_date'] ?? '') ?><br>
                            <?php $d = (int)($r['days_until_due'] ?? 0); ?>
                            <span class="badge bg-<?= $d < 0 ? 'danger' : ($d < 7 ? 'warning' : 'secondary') ?>">
                                <?= $d < 0 ? abs($d).' days overdue' : $d.' days left' ?>
                            </span>
                        </td>
                        <td class="text-center">
                            <?php if ((int)($r['overdue_count'] ?? 0) > 0): ?>
                                <span class="badge bg-danger"><?= (int)$r['overdue_count'] ?></span>
                            <?php else: ?>
                                <span class="text-muted small">—</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
</div>