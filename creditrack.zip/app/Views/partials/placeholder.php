<?php /** @var string $title @var string $subtitle */ ?>
<div class="page-header">
    <h2><?= e($title ?? 'Module') ?></h2>
    <div class="phase-tag">Phase 2 module — not yet implemented</div>
</div>
<div class="panel">
    <div class="panel-body placeholder-body">
        <i data-lucide="tool" class="placeholder-icon"></i>
        <h4><?= e($title ?? 'Module') ?></h4>
        <p class="text-muted"><?= e($subtitle ?? '') ?></p>
        <p class="small">This module is planned for a later phase. The layout, navigation, and permissions for it are already wired up in Phase 1.</p>
    </div>
</div>