<?php /** @var ?array $group @var string $nextCode @var array $staff @var array $allClients */ ?>
<div class="page-header">
    <h2><?= e($title) ?></h2>
    <a href="<?= e(url('groups')) ?>" class="btn btn-outline-secondary">Cancel</a>
</div>

<form method="POST" action="<?= e($group ? url('groups/'.$group['id'].'/update') : url('groups')) ?>" class="panel">
    <?= csrfField() ?>
    <div class="panel-body">
        <div class="row g-3">
            <div class="col-md-3">
                <label class="form-label">Code</label>
                <input type="text" class="form-control" value="<?= e($nextCode) ?>" readonly>
            </div>
            <div class="col-md-9">
                <label class="form-label">Group Name <span class="text-danger">*</span></label>
                <input type="text" name="name" class="form-control" required value="<?= e($group['name'] ?? '') ?>">
            </div>
            
            <div class="col-md-6">
                <label class="form-label">Leader</label>
                <select name="leader_client_id" class="form-select">
                    <option value="">— None —</option>
                    <?php foreach ($allClients as $c): ?>
                        <option value="<?= (int)$c['id'] ?>" <?= (string)($group['leader_client_id'] ?? '')===(string)$c['id']?'selected':'' ?>>
                            <?= e($c['full_name']) ?> (<?= e($c['client_code']) ?>)
                        </option>
                    <?php endforeach; ?>
                </select>
                <small class="text-muted">Select any client to be the leader.</small>
            </div>
            
            <div class="col-md-6">
                <label class="form-label">Assigned Collector</label>
                <select name="assigned_user_id" class="form-select">
                    <option value="">— None —</option>
                    <?php foreach ($staff as $s): ?>
                        <option value="<?= (int)$s['id'] ?>" <?= (string)($group['assigned_user_id'] ?? '')===(string)$s['id']?'selected':'' ?>>
                            <?= e($s['full_name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div class="col-md-6">
                <label class="form-label">Meeting Day</label>
                <input type="text" name="meeting_day" class="form-control" placeholder="e.g. Every Saturday" value="<?= e($group['meeting_day'] ?? '') ?>">
            </div>
            
            <div class="col-md-6">
                <label class="form-label">Status</label>
                <select name="is_active" class="form-select">
                    <option value="1" <?= !isset($group) || $group['is_active'] ? 'selected' : '' ?>>Active</option>
                    <option value="0" <?= isset($group) && !$group['is_active'] ? 'selected' : '' ?>>Inactive</option>
                </select>
            </div>
            
            <div class="col-12">
                <label class="form-label">Notes</label>
                <textarea name="notes" rows="3" class="form-control"><?= e($group['notes'] ?? '') ?></textarea>
            </div>
        </div>
    </div>
    <div class="panel-body border-top d-flex justify-content-end gap-2">
        <a href="<?= e(url('groups')) ?>" class="btn btn-outline-secondary">Cancel</a>
        <button type="submit" class="btn btn-primary">Save Group</button>
    </div>
</form>