<?php /** @var array $group @var array $members */ ?>
<div class="page-header">
    <div>
        <h2><?= e($group['name']) ?></h2>
        <div class="text-muted small"><code><?= e($group['code']) ?></code></div>
    </div>
    <div class="d-flex gap-2">
        <a href="<?= e(url('groups')) ?>" class="btn btn-outline-secondary">Back</a>
        <?php if (Acl::can('groups.manage')): ?>
            <a href="<?= e(url('groups/'.$group['id'].'/edit')) ?>" class="btn btn-primary">Edit</a>
        <?php endif; ?>
    </div>
</div>

<div class="row g-3">
    <div class="col-lg-4">
        <div class="panel">
            <div class="panel-header"><h5>Summary</h5></div>
            <div class="panel-body">
                <dl class="row mb-0">
                    <dt class="col-sm-5 text-muted">Leader</dt><dd class="col-sm-7"><?= e($group['leader_name'] ?: '—') ?></dd>
                    <dt class="col-sm-5 text-muted">Collector</dt><dd class="col-sm-7"><?= e($group['assigned_name'] ?: '—') ?></dd>
                    <dt class="col-sm-5 text-muted">Meeting Day</dt><dd class="col-sm-7"><?= e($group['meeting_day'] ?: '—') ?></dd>
                    <dt class="col-sm-5 text-muted">Members</dt><dd class="col-sm-7"><?= count($members) ?></dd>
                </dl>
            </div>
        </div>
    </div>
    <div class="col-lg-8">
        <div class="panel">
            <div class="panel-header"><h5>Members</h5></div>
            <div class="panel-body p-0">
                <?php if (empty($members)): ?>
                    <div class="p-4 text-muted text-center">No members yet. Assign clients to this group from the client form.</div>
                <?php else: ?>
                    <table class="table table-sm mb-0">
                        <thead class="table-light"><tr><th>Code</th><th>Name</th><th>Phone</th><th>Status</th></tr></thead>
                        <tbody>
                        <?php foreach ($members as $m): ?>
                            <tr>
                                <td><code><?= e($m['client_code']) ?></code></td>
                                <td><a href="<?= e(url('clients/'.$m['id'])) ?>" class="text-decoration-none"><?= e($m['full_name']) ?></a></td>
                                <td><?= e($m['phone']) ?></td>
                                <td><span class="badge bg-secondary"><?= e(ucfirst($m['status'])) ?></span></td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>