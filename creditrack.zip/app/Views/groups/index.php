<?php /** @var array $result @var array $filters @var bool $isAdmin */ ?>
<div class="page-header">
    <h2>Groups</h2>
    <?php if (Acl::can('groups.manage')): ?>
        <a href="<?= e(url('groups/create')) ?>" class="btn btn-primary">
            <i data-lucide="plus"></i> New Group
        </a>
    <?php endif; ?>
</div>

<form method="GET" class="panel mb-3">
    <div class="panel-body">
        <div class="row g-2 align-items-end">
            <div class="col-md-8">
                <label class="form-label small">Search</label>
                <input type="text" name="q" class="form-control" placeholder="Name or code…" value="<?= e($filters['q']) ?>">
            </div>
            <div class="col-md-2 d-grid">
                <button class="btn btn-primary">Search</button>
            </div>
        </div>
    </div>
</form>

<div class="panel">
    <div class="panel-body p-0">
        <?php if (empty($result['rows'])): ?>
            <div class="p-4 text-center text-muted">No groups found.</div>
        <?php else: ?>
            <table class="table table-hover mb-0 align-middle">
                <thead class="table-light">
                    <tr>
                        <th>Code</th><th>Name</th><th>Leader</th>
                        <th>Collector</th><th>Members</th><th>Status</th><th class="text-end">Actions</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($result['rows'] as $g): ?>
                    <tr>
                        <td><code><?= e($g['code']) ?></code></td>
                        <td><a href="<?= e(url('groups/'.$g['id'])) ?>" class="fw-semibold text-decoration-none"><?= e($g['name']) ?></a></td>
                        <td><?= e($g['leader_name'] ?: '—') ?></td>
                        <td><?= e($g['assigned_name'] ?: '—') ?></td>
                        <td><span class="badge bg-secondary"><?= (int)$g['member_count'] ?></span></td>
                        <td>
                            <span class="badge bg-<?= $g['is_active'] ? 'success':'secondary' ?>">
                                <?= $g['is_active'] ? 'Active' : 'Inactive' ?>
                            </span>
                        </td>
                        <td class="text-end">
                            <a href="<?= e(url('groups/'.$g['id'])) ?>" class="btn btn-sm btn-outline-secondary">View</a>
                            <?php if (Acl::can('groups.manage')): ?>
                                <a href="<?= e(url('groups/'.$g['id'].'/edit')) ?>" class="btn btn-sm btn-outline-primary">Edit</a>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div> <!-- Close panel-body -->

    <?php
    $totalPages = (int)ceil($result['total'] / $result['per_page']);
    if ($totalPages > 1): ?>
    <div class="panel-body d-flex justify-content-between align-items-center border-top">
        <div class="small text-muted">
            Page <?= (int)$result['page'] ?> of <?= $totalPages ?> — <?= (int)$result['total'] ?> total
        </div>
        <nav>
            <ul class="pagination mb-0">
                <?php for ($p = 1; $p <= $totalPages; $p++): ?>
                    <li class="page-item <?= $p === (int)$result['page'] ? 'active' : '' ?>">
                        <a class="page-link" href="?<?= http_build_query(array_merge($filters, ['page'=>$p])) ?>"><?= $p ?></a>
                    </li>
                <?php endfor; ?>
            </ul>
        </nav>
    </div>
    <?php endif; ?>
</div>