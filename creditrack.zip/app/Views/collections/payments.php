<?php /** @var array $result @var array $filters @var array $totals */ ?>
<div class="page-header">
    <h2>Payments</h2>
    <?php if (Acl::can('payments.manage')): ?>
        <a href="<?= e(url('payments/create')) ?>" class="btn btn-primary">
            <i data-lucide="plus"></i> Record Payment
        </a>
    <?php endif; ?>
</div>

<div class="row g-3 mb-3">
    <div class="col-md-6">
        <div class="stat-card">
            <div class="stat-icon text-success"><i data-lucide="wallet"></i></div>
            <div>
                <div class="stat-label">Today's Total Collection</div>
                <div class="stat-value"><?= e(Settings::money((float)($totals['total'] ?? 0))) ?></div>
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="stat-card">
            <div class="stat-icon text-info"><i data-lucide="receipt"></i></div>
            <div>
                <div class="stat-label">Transactions Today</div>
                <div class="stat-value"><?= (int)($totals['cnt'] ?? 0) ?></div>
            </div>
        </div>
    </div>
</div>

<form method="GET" class="panel mb-3">
    <div class="panel-body">
        <div class="row g-2 align-items-end">
            <div class="col-md-3">
                <label class="form-label small">Search</label>
                <input type="text" name="q" class="form-control" placeholder="Receipt, loan, client…" value="<?= e($filters['q'] ?? '') ?>">
            </div>
            <div class="col-md-2">
                <label class="form-label small">From</label>
                <input type="date" name="date_from" class="form-control" value="<?= e($filters['date_from'] ?? '') ?>">
            </div>
            <div class="col-md-2">
                <label class="form-label small">To</label>
                <input type="date" name="date_to" class="form-control" value="<?= e($filters['date_to'] ?? '') ?>">
            </div>
            <div class="col-md-3">
                <label class="form-label small">Method</label>
                <select name="method" class="form-select">
                    <option value="">All Methods</option>
                    <?php foreach (['cash'=>'Cash','gcash'=>'GCash','bank'=>'Bank','other'=>'Other'] as $v=>$l): ?>
                        <option value="<?= $v ?>" <?= ($filters['method'] ?? '') === $v ? 'selected' : '' ?>><?= $l ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-2 d-grid">
                <button class="btn btn-primary">Filter</button>
            </div>
        </div>
    </div>
</form>

<div class="panel">
    <div class="panel-body p-0">
        <?php if (empty($result['rows'])): ?>
            <div class="p-4 text-center text-muted">No payments recorded yet.</div>
        <?php else: ?>
            <table class="table table-hover mb-0 align-middle">
                <thead class="table-light">
                    <tr>
                        <th>Receipt #</th><th>Date</th><th>Client</th><th>Loan</th>
                        <th>Amount</th><th>Method</th><th>Received By</th><th class="text-end">Actions</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($result['rows'] as $p): ?>
                    <tr>
                        <td><code><?= e($p['receipt_no']) ?></code></td>
                        <td><?= e($p['payment_date']) ?></td>
                        <td>
                            <a href="<?= e(url('clients/'.$p['client_id'])) ?>" class="text-decoration-none">
                                <?= e($p['client_name']) ?>
                            </a>
                            <div class="small text-muted"><?= e($p['client_code']) ?></div>
                        </td>
                        <td><a href="<?= e(url('loans/'.$p['loan_id'])) ?>" class="text-decoration-none"><code><?= e($p['loan_code']) ?></code></a></td>
                        <td class="fw-semibold text-success"><?= e(Settings::money((float)$p['amount'])) ?></td>
                        <td><span class="badge bg-light text-dark"><?= e(ucfirst($p['payment_method'])) ?></span></td>
                        <td class="small"><?= e($p['received_by_name'] ?: '—') ?></td>
                        <td class="text-end">
                            <a href="<?= e(url('payments/'.$p['id'])) ?>" class="btn btn-sm btn-outline-secondary">View</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
    
    <?php
    $totalPages = (int)ceil(($result['total'] ?? 0) / ($result['per_page'] ?? 20));
    if ($totalPages > 1): ?>
    <div class="panel-body d-flex justify-content-between align-items-center border-top">
        <div class="small text-muted">
            Page <?= (int)($result['page'] ?? 1) ?> of <?= $totalPages ?>
        </div>
        <nav>
            <ul class="pagination mb-0">
                <?php for ($p = 1; $p <= $totalPages; $p++): ?>
                    <li class="page-item <?= $p === (int)($result['page'] ?? 1) ? 'active' : '' ?>">
                        <a class="page-link" href="?<?= http_build_query(array_merge($filters ?? [], ['page'=>$p])) ?>"><?= $p ?></a>
                    </li>
                <?php endfor; ?>
            </ul>
        </nav>
    </div>
    <?php endif; ?>
</div>