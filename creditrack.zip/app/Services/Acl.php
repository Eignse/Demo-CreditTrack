<?php
declare(strict_types=1);

final class Acl
{
    private static array $cache = [];

    public static function can(string $permission): bool
    {
        if (!Auth::check()) return false;
        $role = $_SESSION['user']['role'];

        if (!isset(self::$cache[$role])) {
            $stmt = Database::pdo()->prepare("
                SELECT p.name
                FROM role_permissions rp
                JOIN roles r ON r.id = rp.role_id
                JOIN permissions p ON p.id = rp.permission_id
                WHERE r.name = ?
            ");
            $stmt->execute([$role]);
            self::$cache[$role] = array_column($stmt->fetchAll(), 'name');
        }
        return in_array($permission, self::$cache[$role], true);
    }

    public static function require(string $permission): void
    {
        if (!self::can($permission)) {
            http_response_code(403);
            view('errors/403', [], 'app');
            exit;
        }
    }
}