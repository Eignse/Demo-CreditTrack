<?php
declare(strict_types=1);

final class LoanService
{
    /**
     * Calculate the exact payoff amount for a loan.
     * Uses simple interest on the remaining principal since the last payment or due date.
     */
    public static function calculatePayoff(int $loanId): array
    {
        $loan = Loan::find($loanId);
        if (!$loan) throw new RuntimeException('Loan not found.');
        if ($loan['status'] !== 'active') throw new RuntimeException('Only active loans can be paid off.');

        // 1. Get the remaining principal based on schedules
        $stmt = Database::pdo()->prepare("
            SELECT SUM(principal_due - (amount_paid * (principal_due / total_due))) 
            FROM loan_schedules 
            WHERE loan_id = ? AND status != 'paid'
        ");
        $stmt->execute([$loanId]);
        $remainingPrincipal = (float)$stmt->fetchColumn();
        
        // Fallback if schedule is messed up
        if ($remainingPrincipal <= 0) {
            $remainingPrincipal = (float)$loan['balance']; 
        }

        // 2. Calculate days since the last payment or loan start
        $stmt = Database::pdo()->prepare("
            SELECT MAX(payment_date) FROM payments 
            WHERE loan_id = ? AND voided_at IS NULL
        ");
        $stmt->execute([$loanId]);
        $lastPaymentDate = $stmt->fetchColumn();
        
        $baseDate = $lastPaymentDate ?: $loan['start_date'];
        $daysSinceLast = max(0, (int)floor((time() - strtotime($baseDate)) / 86400));

        // 3. Pro-rated interest
        // Formula: (Remaining Principal * Annual Rate) / 365 * Days
        $annualRate = (float)$loan['interest_rate'] / 100;
        $proRatedInterest = ($remainingPrincipal * $annualRate) / 365 * $daysSinceLast;
        
        // Round to 2 decimals
        $remainingPrincipal = round($remainingPrincipal, 2);
        $proRatedInterest = round($proRatedInterest, 2);
        $totalPayoff = round($remainingPrincipal + $proRatedInterest, 2);

        return [
            'remaining_principal' => $remainingPrincipal,
            'days_since_last'     => $daysSinceLast,
            'pro_rated_interest'  => $proRatedInterest,
            'total_payoff'        => $totalPayoff,
            'balance_on_record'   => (float)$loan['balance'],
        ];
    }

    /**
     * Process an early payoff.
     * Marks all schedules as paid and completes the loan.
     */
    public static function processPayoff(int $loanId, float $amount, string $method, int $userId): int
    {
        $pdo = Database::pdo();
        $pdo->beginTransaction();
        
        try {
            $loan = Loan::find($loanId);
            $calc = self::calculatePayoff($loanId);

            // Create a final payment for the payoff amount
            $receiptNo = 'PY-' . date('Y') . '-' . strtoupper(bin2hex(random_bytes(3)));
            
            $pdo->prepare("
                INSERT INTO payments (receipt_no, loan_id, client_id, amount, payment_date, payment_method, notes, received_by)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ")->execute([
                $receiptNo, $loanId, $loan['client_id'], $amount, date('Y-m-d'), $method, 
                'Early Payoff', $userId
            ]);
            $paymentId = (int)$pdo->lastInsertId();

            // Mark all remaining schedules as paid
            $pdo->prepare("
                UPDATE loan_schedules 
                SET status = 'paid', 
                    amount_paid = total_due,
                    paid_at = NOW() 
                WHERE loan_id = ? AND status != 'paid'
            ")->execute([$loanId]);

            // Mark the loan as completed
            $pdo->prepare("
                UPDATE loan_accounts 
                SET status = 'completed', 
                    early_payoff_at = NOW(),
                    amount_paid = total_payable,
                    balance = 0
                WHERE id = ?
            ")->execute([$loanId]);

            $pdo->commit();
            
            Audit::log('loan.payoff', 'loan', $loanId, "Amount: ₱$amount | Receipt: $receiptNo");
            return $paymentId;

        } catch (Throwable $e) {
            $pdo->rollBack();
            throw $e;
        }
    }
}