<?php
declare(strict_types=1);

final class Auth
{
    /** Attempt login; returns true on success. */
    public static function attempt(string $username, string $password): bool
    {
        $pdo = Database::pdo();
        $stmt = $pdo->prepare("
            SELECT u.*, r.name AS role_name
            FROM users u JOIN roles r ON r.id = u.role_id
            WHERE u.username = ? OR u.email = ?
            LIMIT 1
        ");
        $stmt->execute([$username, $username]);
        $user = $stmt->fetch();

        if (!$user) return false;
        if ((int)$user['is_active'] !== 1) return false;

        // Lockout check
        if ($user['locked_until'] && strtotime($user['locked_until']) > time()) {
            return false;
        }

        if (!password_verify($password, $user['password_hash'])) {
            self::recordFailure((int)$user['id']);
            return false;
        }

        // Success — regenerate session and store identity
        session_regenerate_id(true);
        $_SESSION['user'] = [
            'id'        => (int)$user['id'],
            'username'  => $user['username'],
            'full_name' => $user['full_name'],
            'email'     => $user['email'],
            'role'      => $user['role_name'],
        ];
        $_SESSION['_created'] = time();

        $pdo->prepare("UPDATE users SET failed_attempts=0, locked_until=NULL, last_login_at=NOW() WHERE id=?")
            ->execute([$user['id']]);

        Audit::log('auth.login', 'user', (int)$user['id']);
        return true;
    }

    private static function recordFailure(int $userId): void
    {
        $max   = (int)env('LOGIN_MAX_ATTEMPTS', 5);
        $lock  = (int)env('LOGIN_LOCKOUT_SECONDS', 900);
        $pdo   = Database::pdo();
        $pdo->prepare("UPDATE users SET failed_attempts = failed_attempts + 1 WHERE id = ?")
            ->execute([$userId]);
        $stmt = $pdo->prepare("SELECT failed_attempts FROM users WHERE id = ?");
        $stmt->execute([$userId]);
        if ((int)$stmt->fetchColumn() >= $max) {
            $pdo->prepare("UPDATE users SET locked_until = DATE_ADD(NOW(), INTERVAL ? SECOND) WHERE id = ?")
                ->execute([$lock, $userId]);
        }
    }

    public static function logout(): void
    {
        if (self::check()) Audit::log('auth.logout', 'user', (int)$_SESSION['user']['id']);
        $_SESSION = [];
        if (ini_get('session.use_cookies')) {
            $p = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000, $p['path'], $p['domain'], $p['secure'], $p['httponly']);
        }
        session_destroy();
    }

    public static function check(): bool
    {
        return isset($_SESSION['user']['id']);
    }

    public static function user(): ?array
    {
        return $_SESSION['user'] ?? null;
    }

    public static function id(): ?int
    {
        return $_SESSION['user']['id'] ?? null;
    }
}