<?php
declare(strict_types=1);

final class BackupService
{
    /** Absolute path to the backups directory. */
    public static function dir(): string
    {
        $dir = BASE_PATH . '/storage/backups';
        if (!is_dir($dir)) mkdir($dir, 0777, true);
        return $dir;
    }

    /**
     * Dump the entire database to a .sql file.
     * Returns the absolute path to the created file.
     */
    public static function dump(?string $label = null): string
    {
        $pdo = Database::pdo();
        $dbName = (string)env('DB_NAME', 'creditrack_db');

        $label = $label ?? date('Ymd-His');
        $filename = 'backup-' . $label . '.sql';
        $path = self::dir() . '/' . $filename;

        $fp = fopen($path, 'w');
        if (!$fp) throw new RuntimeException('Cannot open backup file for writing.');

        fwrite($fp, "-- CrediTrack Backup\n");
        fwrite($fp, "-- Database: $dbName\n");
        fwrite($fp, "-- Created: " . date('Y-m-d H:i:s') . "\n");
        fwrite($fp, "-- By: " . (Auth::user()['username'] ?? 'system') . "\n\n");
        fwrite($fp, "SET NAMES utf8mb4;\n");
        fwrite($fp, "SET FOREIGN_KEY_CHECKS = 0;\n\n");

        // All tables in this database
        $tables = $pdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
        foreach ($tables as $table) {
            // Schema
            $create = $pdo->query("SHOW CREATE TABLE `$table`")->fetch();
            fwrite($fp, "DROP TABLE IF EXISTS `$table`;\n");
            fwrite($fp, $create['Create Table'] . ";\n\n");

            // Data
            $rows = $pdo->query("SELECT * FROM `$table`")->fetchAll();
            if ($rows) {
                foreach ($rows as $row) {
                    $cols = array_keys($row);
                    $vals = array_map(function ($v) use ($pdo) {
                        if ($v === null) return 'NULL';
                        return $pdo->quote((string)$v);
                    }, array_values($row));
                    fwrite($fp, "INSERT INTO `$table` (`" . implode('`, `', $cols) . "`) VALUES (" . implode(', ', $vals) . ");\n");
                }
                fwrite($fp, "\n");
            }
        }

        fwrite($fp, "SET FOREIGN_KEY_CHECKS = 1;\n");
        fclose($fp);

        return $path;
    }

    /**
     * Restore from a .sql file.
     * WARNING: This drops all existing tables and re-creates them from the backup.
     */
    public static function restore(string $sqlPath): void
    {
        if (!is_file($sqlPath)) throw new RuntimeException('Backup file not found.');

        $pdo = Database::pdo();
        $pdo->exec("SET FOREIGN_KEY_CHECKS = 0");
        $pdo->exec("SET NAMES utf8mb4");

        $sql = file_get_contents($sqlPath);
        if ($sql === false) throw new RuntimeException('Cannot read backup file.');

        // Split on semicolons at end-of-line; then execute
        $pdo->exec($sql);
        $pdo->exec("SET FOREIGN_KEY_CHECKS = 1");
    }

    /** List all backup files, newest first. */
    public static function list(): array
    {
        $files = glob(self::dir() . '/*.sql') ?: [];
        usort($files, fn($a, $b) => filemtime($b) - filemtime($a));

        $result = [];
        foreach ($files as $path) {
            $result[] = [
                'filename' => basename($path),
                'path'     => $path,
                'size'     => filesize($path),
                'created'  => date('Y-m-d H:i:s', filemtime($path)),
            ];
        }
        return $result;
    }

    /** Delete a backup file. */
    public static function delete(string $filename): bool
    {
        // Prevent directory traversal
        $filename = basename($filename);
        $path = self::dir() . '/' . $filename;
        if (is_file($path)) return unlink($path);
        return false;
    }

    /** Ensure the retention policy keeps only the newest N backups. */
    public static function prune(int $keep = 10): void
    {
        $files = glob(self::dir() . '/*.sql') ?: [];
        if (count($files) <= $keep) return;
        usort($files, fn($a, $b) => filemtime($b) - filemtime($a));
        $toDelete = array_slice($files, $keep);
        foreach ($toDelete as $f) @unlink($f);
    }
}