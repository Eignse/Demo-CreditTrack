<?php
declare(strict_types=1);

final class PaymentService
{
    public static function record(array $data, int $userId): array
    {
        $pdo = Database::pdo();
        $pdo->beginTransaction();

        try {
            $loan = Loan::find((int)$data['loan_id']);
            if (!$loan) throw new RuntimeException('Loan not found.');
            if ($loan['status'] !== 'active') throw new RuntimeException('Only active loans can accept payments.');

            $amount = round((float)$data['amount'], 2);
            if ($amount <= 0) throw new RuntimeException('Payment amount must be greater than zero.');

            // Safety check: compute real balance from non-voided payments only.
            // COALESCE prevents SUM() returning NULL from corrupting the check.
            $stmt = $pdo->prepare("SELECT COALESCE(SUM(amount), 0) FROM payments WHERE loan_id = ? AND voided_at IS NULL");
            $stmt->execute([$loan['id']]);
            $totalPaid = (float)$stmt->fetchColumn();
            $currentBalance = (float)$loan['total_payable'] - $totalPaid;

            if ($amount > $currentBalance + 0.001) {
                throw new RuntimeException('Payment exceeds remaining balance (₱' . number_format($currentBalance, 2) . ').');
            }

            $receiptNo = self::generateReceiptNo();

            $pdo->prepare("
                INSERT INTO payments (receipt_no, loan_id, client_id, amount, payment_date, payment_method, reference_no, notes, received_by)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            ")->execute([
                $receiptNo, $loan['id'], $loan['client_id'], $amount, $data['payment_date'], $data['payment_method'],
                $data['reference_no'] ?? null, $data['notes'] ?? null, $userId,
            ]);
            $paymentId = (int)$pdo->lastInsertId();

            $stmt = $pdo->prepare("
                SELECT * FROM loan_schedules
                WHERE loan_id = ? AND status IN ('pending','partial','overdue')
                ORDER BY installment_no ASC
                FOR UPDATE
            ");
            $stmt->execute([$loan['id']]);
            $schedules = $stmt->fetchAll();

            $remaining = $amount;
            $allocations = [];

            foreach ($schedules as $sch) {
                if ($remaining <= 0) break;
                $due = round((float)$sch['total_due'] - (float)$sch['amount_paid'], 2);
                if ($due <= 0) continue;

                $applied = round(min($remaining, $due), 2);

                $pdo->prepare("INSERT INTO payment_allocations (payment_id, schedule_id, amount_applied) VALUES (?, ?, ?)")
                    ->execute([$paymentId, $sch['id'], $applied]);

                $newPaid = round((float)$sch['amount_paid'] + $applied, 2);
                $fullyPaid = $newPaid + 0.001 >= (float)$sch['total_due'];
                $newStatus = $fullyPaid ? 'paid' : 'partial';

                $pdo->prepare("UPDATE loan_schedules SET amount_paid = ?, status = ?, paid_at = ? WHERE id = ?")
                    ->execute([$newPaid, $newStatus, $fullyPaid ? date('Y-m-d H:i:s') : null, $sch['id']]);

                $allocations[] = ['schedule_id' => $sch['id'], 'applied' => $applied];
                $remaining = round($remaining - $applied, 2);
            }

            // Allocation guard: if the payment couldn't be fully distributed to schedules,
            // something is inconsistent — abort rather than silently discard money.
            if ($remaining > 0.001) {
                throw new RuntimeException('Payment could not be fully allocated. Please check the schedule.');
            }

            $newAmountPaid = round((float)$loan['amount_paid'] + $amount, 2);
            $newBalance    = round((float)$loan['total_payable'] - $newAmountPaid, 2);
            $newStatus     = $newBalance <= 0.01 ? 'completed' : 'active';

            $pdo->prepare("UPDATE loan_accounts SET amount_paid = ?, balance = ?, status = ? WHERE id = ?")
                ->execute([$newAmountPaid, max(0, $newBalance), $newStatus, $loan['id']]);

            self::markOverdue($loan['id']);
            $pdo->commit();

            Audit::log('payment.create', 'payment', $paymentId, "Receipt {$receiptNo} — ₱" . number_format($amount, 2));
            return [
                'payment_id'  => $paymentId,
                'receipt_no'  => $receiptNo,
                'allocations' => $allocations,
                'new_balance' => max(0, $newBalance),
                'loan_status' => $newStatus,
            ];
        } catch (Throwable $e) {
            $pdo->rollBack();
            throw $e;
        }
    }

    public static function void(int $paymentId, string $reason, int $userId): void
    {
        $pdo = Database::pdo();
        $pdo->beginTransaction();

        try {
            $payment = Payment::find($paymentId);
            if (!$payment) throw new RuntimeException('Payment not found.');
            if ($payment['voided_at']) throw new RuntimeException('Payment is already voided.');

            // Guard: payoff receipts have no allocation rows to reverse. Voiding them
            // leaves schedules marked paid while the loan reopens — inconsistent state.
            if (str_starts_with($payment['receipt_no'], 'PY-')) {
                throw new RuntimeException('Payoff receipts cannot be voided. Reverse via a loan adjustment instead.');
            }

            // 1. Mark the payment as voided
            $pdo->prepare("UPDATE payments SET voided_at = NOW(), void_reason = ?, voided_by = ? WHERE id = ?")
                ->execute([$reason, $userId, $paymentId]);

            // 2. Reverse schedule allocations — clamp to 0, clear paid_at, and
            //    derive status from the clamped value so it never goes negative.
            $stmt = $pdo->prepare("SELECT schedule_id, amount_applied FROM payment_allocations WHERE payment_id = ?");
            $stmt->execute([$paymentId]);
            foreach ($stmt->fetchAll() as $alloc) {
                $pdo->prepare("
                    UPDATE loan_schedules 
                    SET amount_paid = GREATEST(0, amount_paid - ?),
                        paid_at = NULL,
                        status = CASE 
                            WHEN GREATEST(0, amount_paid - ?) <= 0 THEN 'pending' 
                            ELSE 'partial' 
                        END
                    WHERE id = ?
                ")->execute([$alloc['amount_applied'], $alloc['amount_applied'], $alloc['schedule_id']]);
            }

            // 3. Reverse loan totals — clamp amount_paid to 0 to prevent negative values
            $pdo->prepare("
                UPDATE loan_accounts 
                SET amount_paid = GREATEST(0, amount_paid - ?),
                    balance = balance + ?
                WHERE id = ?
            ")->execute([$payment['amount'], $payment['amount'], $payment['loan_id']]);

            // 4. Reactivate a completed loan if the void reopens a balance
            $loan = Loan::find($payment['loan_id']);
            if ($loan['status'] === 'completed' && $loan['balance'] > 0) {
                $pdo->prepare("UPDATE loan_accounts SET status = 'active' WHERE id = ?")->execute([$loan['id']]);
            }

            $pdo->commit();
            Audit::log('payment.void', 'payment', $paymentId, "Voided: $reason");
        } catch (Throwable $e) {
            $pdo->rollBack();
            throw $e;
        }
    }

    public static function markOverdue(?int $loanId = null): void
    {
        $sql = "UPDATE loan_schedules SET status = 'overdue' WHERE status IN ('pending', 'partial') AND due_date < CURDATE()";
        if ($loanId !== null) {
            Database::pdo()->prepare($sql . " AND loan_id = ?")->execute([$loanId]);
        } else {
            Database::pdo()->exec($sql);
        }
    }

    private static function generateReceiptNo(): string
    {
        $year = date('Y');
        $prefix = "RC-{$year}-";
        $stmt = Database::pdo()->prepare("SELECT receipt_no FROM payments WHERE receipt_no LIKE ? ORDER BY receipt_no DESC LIMIT 1");
        $stmt->execute([$prefix . '%']);
        $last = $stmt->fetchColumn();
        $next = 1;
        if ($last && preg_match('/-(\d+)$/', $last, $m)) {
            $next = ((int)$m[1]) + 1;
        }
        return sprintf('%s%05d', $prefix, $next);
    }
}