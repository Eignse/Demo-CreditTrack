<?php
declare(strict_types=1);

final class Settings
{
    private static ?array $cache = null;

    /** Load all settings into memory once per request. */
    public static function all(): array
    {
        if (self::$cache !== null) return self::$cache;

        $rows = Database::pdo()->query("SELECT setting_key, setting_value FROM system_settings")->fetchAll();
        $map = [];
        foreach ($rows as $r) {
            $map[$r['setting_key']] = $r['setting_value'];
        }
        self::$cache = $map;
        return $map;
    }

    public static function get(string $key, $default = null)
    {
        $all = self::all();
        return array_key_exists($key, $all) && $all[$key] !== null ? $all[$key] : $default;
    }

    public static function getFloat(string $key, float $default = 0): float
    {
        $v = self::get($key);
        return $v === null ? $default : (float)$v;
    }

    public static function getInt(string $key, int $default = 0): int
    {
        $v = self::get($key);
        return $v === null ? $default : (int)$v;
    }

    /** Upsert one or more settings. */
    public static function set(array $values, ?int $updatedBy = null): void
    {
        $pdo = Database::pdo();
        $stmt = $pdo->prepare("
            INSERT INTO system_settings (setting_key, setting_value, updated_by)
            VALUES (?, ?, ?)
            ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value), updated_by = VALUES(updated_by)
        ");
        foreach ($values as $key => $value) {
            $stmt->execute([$key, (string)$value, $updatedBy]);
        }
        self::$cache = null; // invalidate
    }

    /** Handy shortcut for the currency symbol. */
    public static function currency(): string
    {
        return (string)self::get('currency_symbol', '₱');
    }

    /** Format money using the app's currency symbol. */
    public static function money(float $amount): string
    {
        return self::currency() . number_format($amount, 2);
    }
}