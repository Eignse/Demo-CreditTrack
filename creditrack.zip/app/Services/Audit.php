<?php
declare(strict_types=1);

final class Audit
{
    public static function log(string $action, ?string $entityType = null, ?int $entityId = null, ?string $details = null): void
    {
        try {
            Database::pdo()->prepare("
                INSERT INTO audit_logs (user_id, action, entity_type, entity_id, details, ip_address, user_agent)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ")->execute([
                Auth::id(),
                $action,
                $entityType,
                $entityId,
                $details,
                $_SERVER['REMOTE_ADDR'] ?? null,
                substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 255),
            ]);
        } catch (Throwable $e) {
            // Never let logging break the request
            error_log('Audit log failed: ' . $e->getMessage());
        }
    }
}