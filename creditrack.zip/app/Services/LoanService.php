<?php
declare(strict_types=1);

final class LoanService
{
    /**
     * Calculate the exact payoff amount for a loan.
     *
     * Remaining principal is derived from the loan's principal-to-total-payable
     * ratio applied to what has been paid so far. Pro-rated interest accrues
     * on that remaining principal from the last non-voided payment (or the
     * loan start date if no payments exist).
     */
    public static function calculatePayoff(int $loanId): array
    {
        $loan = Loan::find($loanId);
        if (!$loan) throw new RuntimeException('Loan not found.');
        if ($loan['status'] !== 'active') throw new RuntimeException('Only active loans can be paid off.');

        // 1. Remaining principal via principal/total-payable ratio
        //    max(0.01, ...) prevents division by zero if total_payable is somehow 0
        $principalRatio = (float)$loan['principal'] / max(0.01, (float)$loan['total_payable']);
        $principalPaid  = (float)$loan['amount_paid'] * $principalRatio;
        $remainingPrincipal = max(0, (float)$loan['principal'] - $principalPaid);

        // 2. Days since last non-voided payment, or loan start if none
        $stmt = Database::pdo()->prepare("
            SELECT MAX(payment_date) FROM payments 
            WHERE loan_id = ? AND voided_at IS NULL
        ");
        $stmt->execute([$loanId]);
        $lastPaymentDate = $stmt->fetchColumn();

        $baseDate = $lastPaymentDate ?: $loan['start_date'];
        $daysSinceLast = max(0, (int)floor((time() - strtotime($baseDate)) / 86400));

        // 3. Pro-rated interest on remaining principal
        $annualRate = (float)$loan['interest_rate'] / 100;
        $proRatedInterest = ($remainingPrincipal * $annualRate) / 365 * $daysSinceLast;

        return [
            'remaining_principal' => round($remainingPrincipal, 2),
            'days_since_last'     => $daysSinceLast,
            'pro_rated_interest'  => round($proRatedInterest, 2),
            'total_payoff'        => round($remainingPrincipal + $proRatedInterest, 2),
            'balance_on_record'   => (float)$loan['balance'],
        ];
    }

    /**
     * Process an early payoff.
     * Records a payoff payment, marks all schedules paid, and completes the loan.
     */
    public static function processPayoff(int $loanId, float $amount, string $method, int $userId): int
    {
        $pdo = Database::pdo();
        $pdo->beginTransaction();

        try {
            $loan = Loan::find($loanId);
            if (!$loan) throw new RuntimeException('Loan not found.');
            if ($loan['status'] !== 'active') throw new RuntimeException('Only active loans can be paid off.');

            $receiptNo = 'PY-' . date('Y') . '-' . strtoupper(bin2hex(random_bytes(3)));

            // 1. Record the payoff payment
            $pdo->prepare("
                INSERT INTO payments (receipt_no, loan_id, client_id, amount, payment_date, payment_method, notes, received_by)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ")->execute([
                $receiptNo,
                $loanId,
                $loan['client_id'],
                $amount,
                date('Y-m-d'),
                $method,
                'Early Payoff',
                $userId,
            ]);
            $paymentId = (int)$pdo->lastInsertId();

            // 2. Mark every remaining schedule as fully paid
            $pdo->prepare("
                UPDATE loan_schedules 
                SET status = 'paid', 
                    amount_paid = total_due,
                    paid_at = NOW() 
                WHERE loan_id = ? AND status != 'paid'
            ")->execute([$loanId]);

            // 3. Complete the loan
            $pdo->prepare("
                UPDATE loan_accounts 
                SET status = 'completed', 
                    early_payoff_at = NOW(),
                    amount_paid = total_payable,
                    balance = 0
                WHERE id = ?
            ")->execute([$loanId]);

            $pdo->commit();

            Audit::log('loan.payoff', 'loan', $loanId, "Amount: ₱$amount | Receipt: $receiptNo");
            return $paymentId;

        } catch (Throwable $e) {
            $pdo->rollBack();
            throw $e;
        }
    }
}