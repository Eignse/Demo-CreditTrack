<?php
declare(strict_types=1);

final class ReportService
{
    // ------------------------------------------------------------
    // DAILY COLLECTION REPORT
    // ------------------------------------------------------------
    public static function dailyCollection(array $filters, int $viewerId, bool $isAdmin): array
    {
        $pdo = Database::pdo();
        
        $from = $filters['date_from'] ?? date('Y-m-01');
        $to   = $filters['date_to'] ?? date('Y-m-d');
        
        $where = ["p.payment_date BETWEEN ? AND ?", "p.voided_at IS NULL"];
        $params = [$from, $to];

        if (!empty($filters['collector_id'])) {
            $where[] = "p.received_by = ?";
            $params[] = (int)$filters['collector_id'];
        }
        
        if (!$isAdmin) {
            $where[] = "c.assigned_user_id = ?";
            $params[] = $viewerId;
        }

        $whereSql = implode(' AND ', $where);

        $sql = "
            SELECT p.payment_date, p.received_by,
                   COALESCE(u.full_name, 'Unknown') AS collector_name,
                   COUNT(p.id) AS payment_count,
                   COALESCE(SUM(p.amount), 0) AS total_collected
            FROM payments p
            JOIN clients c ON c.id = p.client_id
            LEFT JOIN users u ON u.id = p.received_by
            WHERE $whereSql
            GROUP BY p.payment_date, p.received_by, u.full_name
            ORDER BY p.payment_date DESC, u.full_name
        ";
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $rows = $stmt->fetchAll();

        $totalCollected = 0;
        $totalCount = 0;
        foreach ($rows as $r) {
            $totalCollected += (float)$r['total_collected'];
            $totalCount += (int)$r['payment_count'];
        }

        return [
            'rows'            => $rows,
            'total_collected' => $totalCollected,
            'total_count'     => $totalCount,
        ];
    }

    // ------------------------------------------------------------
    // GROUP COLLECTION REPORT
    // ------------------------------------------------------------
    public static function groupCollection(array $filters, int $viewerId, bool $isAdmin): array
    {
        $pdo = Database::pdo();
        $where = ["g.is_active = 1"];
        $params = [];
        
        if (!empty($filters['group_id'])) {
            $where[] = "g.id = ?";
            $params[] = (int)$filters['group_id'];
        }
        if (!$isAdmin) {
            $where[] = "g.assigned_user_id = ?";
            $params[] = $viewerId;
        }
        $whereSql = implode(' AND ', $where);

        $sql = "
            SELECT g.id, g.code, g.name,
                   COALESCE(u.full_name, '—') AS collector,
                   COUNT(DISTINCT c.id) AS member_count,
                   COUNT(DISTINCT l.id) AS loan_count,
                   COALESCE(SUM(l.total_payable), 0) AS expected,
                   COALESCE(SUM(l.amount_paid), 0)   AS collected,
                   COALESCE(SUM(l.balance), 0)       AS balance
            FROM `groups` g
            LEFT JOIN users u ON u.id = g.assigned_user_id
            LEFT JOIN clients c ON c.group_id = g.id
            LEFT JOIN loan_accounts l ON l.client_id = c.id
            WHERE $whereSql
            GROUP BY g.id, g.code, g.name, u.full_name
            HAVING member_count > 0
            ORDER BY g.name
        ";
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $rows = $stmt->fetchAll();

        return [
            'rows'      => $rows,
            'expected'  => (float)array_sum(array_column($rows, 'expected')),
            'collected' => (float)array_sum(array_column($rows, 'collected')),
            'balance'   => (float)array_sum(array_column($rows, 'balance')),
        ];
    }

    // ------------------------------------------------------------
    // CLIENT PAYMENT REPORT
    // ------------------------------------------------------------
    public static function clientPayments(array $filters, int $viewerId, bool $isAdmin): array
    {
        $pdo = Database::pdo();
        $where = ["p.voided_at IS NULL"];
        $params = [];

        if (!empty($filters['client_id'])) {
            $where[] = "p.client_id = ?";
            $params[] = (int)$filters['client_id'];
        }
        if (!empty($filters['date_from'])) {
            $where[] = "p.payment_date >= ?";
            $params[] = $filters['date_from'];
        }
        if (!empty($filters['date_to'])) {
            $where[] = "p.payment_date <= ?";
            $params[] = $filters['date_to'];
        }
        if (!$isAdmin) {
            $where[] = "c.assigned_user_id = ?";
            $params[] = $viewerId;
        }

        $whereSql = implode(' AND ', $where);

        $sql = "
            SELECT p.id, p.receipt_no, p.payment_date, p.amount, p.payment_method,
                   c.full_name AS client_name, c.client_code, c.id AS client_id,
                   l.loan_code,
                   COALESCE(u.full_name, '—') AS collector
            FROM payments p
            JOIN clients c ON c.id = p.client_id
            JOIN loan_accounts l ON l.id = p.loan_id
            LEFT JOIN users u ON u.id = p.received_by
            WHERE $whereSql
            ORDER BY p.payment_date DESC, p.id DESC
            LIMIT 500
        ";
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $rows = $stmt->fetchAll();

        return [
            'rows'  => $rows,
            'total' => (float)array_sum(array_column($rows, 'amount')),
            'count' => count($rows),
        ];
    }

    // ------------------------------------------------------------
    // OUTSTANDING BALANCE REPORT
    // ------------------------------------------------------------
    public static function outstanding(array $filters, int $viewerId, bool $isAdmin): array
    {
        $pdo = Database::pdo();
        $where = ["l.status = 'active'"];
        $params = [];

        if (!empty($filters['group_id'])) {
            $where[] = "c.group_id = ?";
            $params[] = (int)$filters['group_id'];
        }
        if (!$isAdmin) {
            $where[] = "c.assigned_user_id = ?";
            $params[] = $viewerId;
        }
        $whereSql = implode(' AND ', $where);

        $sql = "
            SELECT l.id AS loan_id, l.loan_code, l.principal, l.balance,
                   l.maturity_date, l.frequency,
                   c.full_name AS client_name, c.client_code, c.id AS client_id,
                   g.name AS group_name,
                   COALESCE(u.full_name, '—') AS collector,
                   DATEDIFF(l.maturity_date, CURDATE()) AS days_until_due,
                   (SELECT COUNT(*) FROM loan_schedules s
                    WHERE s.loan_id = l.id AND s.status = 'overdue') AS overdue_count
            FROM loan_accounts l
            JOIN clients c ON c.id = l.client_id
            LEFT JOIN `groups` g ON g.id = c.group_id
            LEFT JOIN users u ON u.id = c.assigned_user_id
            WHERE $whereSql
            ORDER BY l.balance DESC, l.maturity_date ASC
        ";
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $rows = $stmt->fetchAll();

        return [
            'rows'  => $rows,
            'total' => (float)array_sum(array_column($rows, 'balance')),
            'count' => count($rows),
        ];
    }
}