<?php
declare(strict_types=1);

final class PaymentController
{
    private function guard(string $perm = 'payments.view'): array
    {
        AuthMiddleware::requireLogin();
        Acl::require($perm);
        $u = Auth::user();
        return [(int)$u['id'], $u['role'] === 'admin'];
    }

    public function index(): void
    {
        [$uid, $isAdmin] = $this->guard();
        $filters = ['q' => trim($_GET['q'] ?? ''), 'date_from' => $_GET['date_from'] ?? '', 'date_to' => $_GET['date_to'] ?? '', 'method' => $_GET['method'] ?? ''];
        $page = max(1, (int)($_GET['page'] ?? 1));
        $result = Payment::list($filters, $uid, $isAdmin, $page);
        $totals = Payment::todayTotals($uid, $isAdmin);
        view('payments/index', ['title' => 'Payments', 'result' => $result, 'filters' => $filters, 'totals' => $totals]);
    }

    public function create(): void
    {
        [$uid, $isAdmin] = $this->guard('payments.manage');
        $preselectLoan = (int)($_GET['loan_id'] ?? 0);
        $loans = $this->availableLoans($uid, $isAdmin);
        view('payments/form', ['title' => 'Record Payment', 'loans' => $loans, 'preselectLoan' => $preselectLoan]);
    }

    public function store(): void
    {
        [$uid, $isAdmin] = $this->guard('payments.manage');
        verifyCsrf();

        $loanId = (int)input('loan_id', 0);
        $amount = (float)input('amount', 0);
        $date   = input('payment_date', date('Y-m-d'));
        $method = input('payment_method', 'cash');

        if ($loanId <= 0) { flash('error', 'Select a loan.'); redirect('payments/create'); }
        if ($amount <= 0) { flash('error', 'Amount must be greater than zero.'); redirect('payments/create?loan_id='.$loanId); }
        if (!in_array($method, ['cash','bank','gcash','other'], true)) $method = 'cash';
        if (!Loan::canAccess($loanId, $uid, $isAdmin)) { http_response_code(403); exit('Forbidden'); }

        try {
            $result = PaymentService::record([
                'loan_id' => $loanId, 'amount' => $amount, 'payment_date' => $date, 'payment_method' => $method,
                'reference_no' => input('reference_no', ''), 'notes' => input('notes', ''),
            ], $uid);
        } catch (Throwable $e) {
            flash('error', 'Payment failed: ' . $e->getMessage());
            redirect('payments/create?loan_id=' . $loanId);
        }

        flash('success', 'Payment recorded. Receipt #' . $result['receipt_no'] . '.');
        redirect('payments/' . $result['payment_id']);
    }

    public function show(int $id): void
    {
        [$uid, $isAdmin] = $this->guard();
        if (!Payment::canAccess($id, $uid, $isAdmin)) { http_response_code(403); view('errors/403', [], 'app'); return; }
        $payment = Payment::find($id);
        if (!$payment) { http_response_code(404); view('errors/404', [], 'app'); return; }
        $allocations = Payment::allocations($id);
        view('payments/show', ['title' => 'Receipt ' . $payment['receipt_no'], 'payment' => $payment, 'allocations' => $allocations]);
    }

    public function voidForm(int $id): void
    {
        [$uid, $isAdmin] = $this->guard('payments.void');
        if (!Payment::canAccess($id, $uid, $isAdmin)) { http_response_code(403); exit; }
        $payment = Payment::find($id);
        if (!$payment || $payment['voided_at']) { flash('error', 'Invalid or already voided.'); redirect('payments/'.$id); }
        view('payments/void', ['title' => 'Void Payment', 'payment' => $payment]);
    }

    public function void(): void
    {
        [$uid] = $this->guard('payments.void');
        verifyCsrf();
        $id = (int)input('payment_id', 0);
        $reason = input('reason', '');
        
        try {
            PaymentService::void($id, $reason, $uid);
            flash('success', 'Payment voided.');
        } catch (Throwable $e) {
            flash('error', 'Void failed: ' . $e->getMessage());
        }
        redirect('payments/' . $id);
    }

    public function daily(): void
    {
        [$uid, $isAdmin] = $this->guard();
        $date = $_GET['date'] ?? date('Y-m-d');
        $filters = ['date_from' => $date, 'date_to' => $date, 'q' => '', 'method' => ''];
        $page = max(1, (int)($_GET['page'] ?? 1));
        $result = Payment::list($filters, $uid, $isAdmin, $page);
        view('payments/daily', ['title' => 'Daily Transactions', 'date' => $date, 'result' => $result]);
    }

    public function history(): void
    {
        [$uid, $isAdmin] = $this->guard();
        $filters = ['q' => trim($_GET['q'] ?? ''), 'date_from' => $_GET['date_from'] ?? '', 'date_to' => $_GET['date_to'] ?? '', 'method' => ''];
        $page = max(1, (int)($_GET['page'] ?? 1));
        $result = Payment::list($filters, $uid, $isAdmin, $page);
        view('payments/history', ['title' => 'Payment History', 'result' => $result, 'filters' => $filters]);
    }

    public function loanInfo(): void
    {
        [$uid, $isAdmin] = $this->guard('payments.manage');
        header('Content-Type: application/json');
        $id = (int)($_GET['loan_id'] ?? 0);
        
        if ($id <= 0 || !Loan::canAccess($id, $uid, $isAdmin)) { http_response_code(404); echo json_encode(['error' => 'Not found']); return; }
        
        $loan = Loan::find($id);
        echo json_encode(['loan_code' => $loan['loan_code'], 'client_name' => $loan['client_name'], 'balance' => (float)$loan['balance'], 'total_payable' => (float)$loan['total_payable']]);
    }

    private function availableLoans(int $uid, bool $isAdmin): array
    {
        $pdo = Database::pdo();
        $sql = "SELECT l.id, l.loan_code, l.balance, c.full_name AS client_name, c.client_code FROM loan_accounts l JOIN clients c ON c.id = l.client_id WHERE l.status = 'active'";
        if (!$isAdmin) {
            $stmt = $pdo->prepare($sql . " AND c.assigned_user_id = ? ORDER BY l.created_at DESC");
            $stmt->execute([$uid]);
            return $stmt->fetchAll();
        }
        return $pdo->query($sql . " ORDER BY l.created_at DESC")->fetchAll();
    }
}