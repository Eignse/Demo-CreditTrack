<?php
declare(strict_types=1);

final class BackupController
{
    private function guard(): array
    {
        AuthMiddleware::requireLogin();
        Acl::require('backup.manage');
        $u = Auth::user();
        return [(int)$u['id']];
    }

    public function index(): void
    {
        $this->guard();
        $backups = BackupService::list();
        view('settings/backup', [
            'title'   => 'Backup and Restore',
            'backups' => $backups,
        ]);
    }

    /** Create a new backup and immediately download it. */
    public function create(): void
    {
        [$uid] = $this->guard();
        verifyCsrf();

        try {
            $path = BackupService::dump();
            $size = filesize($path);
            Audit::log('backup.create', 'backup', null, basename($path) . " ({$size} bytes)");
            BackupService::prune(20);

            flash('success', 'Backup created: ' . basename($path));
            header('Content-Type: application/sql');
            header('Content-Disposition: attachment; filename="' . basename($path) . '"');
            header('Content-Length: ' . $size);
            readfile($path);
            exit;
        } catch (Throwable $e) {
            flash('error', 'Backup failed: ' . $e->getMessage());
            redirect('settings/backup');
        }
    }

    /** Save a backup to server-side storage only (no download). */
    public function saveOnly(): void
    {
        [$uid] = $this->guard();
        verifyCsrf();

        try {
            $path = BackupService::dump();
            Audit::log('backup.save', 'backup', null, basename($path));
            BackupService::prune(20);
            flash('success', 'Backup saved to server: ' . basename($path));
        } catch (Throwable $e) {
            flash('error', 'Backup failed: ' . $e->getMessage());
        }
        redirect('settings/backup');
    }

    /** Download a specific backup file. */
    public function download(): void
    {
        $this->guard();
        $filename = basename($_GET['file'] ?? '');
        $path = BackupService::dir() . '/' . $filename;
        if (!is_file($path)) {
            flash('error', 'Backup file not found.');
            redirect('settings/backup');
        }
        Audit::log('backup.download', 'backup', null, $filename);
        header('Content-Type: application/sql');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('Content-Length: ' . filesize($path));
        readfile($path);
        exit;
    }

    /** Delete a specific backup file. */
    public function delete(): void
    {
        [$uid] = $this->guard();
        verifyCsrf();
        $filename = basename($_POST['file'] ?? '');
        if (BackupService::delete($filename)) {
            Audit::log('backup.delete', 'backup', null, $filename);
            flash('success', 'Backup deleted.');
        } else {
            flash('error', 'Backup file not found.');
        }
        redirect('settings/backup');
    }

    /** Restore from a previously stored backup file. */
    public function restore(): void
    {
        [$uid] = $this->guard();
        verifyCsrf();

        $filename = basename($_POST['file'] ?? '');
        $path = BackupService::dir() . '/' . $filename;

        if (!is_file($path)) {
            flash('error', 'Backup file not found.');
            redirect('settings/backup');
        }

        try {
            // Safety: create a pre-restore backup
            BackupService::dump('pre-restore-' . date('Ymd-His'));

            BackupService::restore($path);
            Audit::log('backup.restore', 'backup', null, $filename);
            flash('success', 'Database restored from ' . $filename . '. Please log in again.');
            Auth::logout();
            redirect('login');
        } catch (Throwable $e) {
            flash('error', 'Restore failed: ' . $e->getMessage());
            redirect('settings/backup');
        }
    }

    /** Upload and restore from a .sql file. */
    public function upload(): void
    {
        [$uid] = $this->guard();
        verifyCsrf();

        if (!isset($_FILES['backup_file']) || $_FILES['backup_file']['error'] !== UPLOAD_ERR_OK) {
            flash('error', 'Please select a .sql file to upload.');
            redirect('settings/backup');
        }
        $file = $_FILES['backup_file'];
        $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        if ($ext !== 'sql') {
            flash('error', 'Only .sql files are allowed.');
            redirect('settings/backup');
        }
        if ($file['size'] > 50 * 1024 * 1024) {
            flash('error', 'File too large (max 50 MB).');
            redirect('settings/backup');
        }

        try {
            // Pre-restore safety backup
            BackupService::dump('pre-restore-' . date('Ymd-His'));

            BackupService::restore($file['tmp_name']);
            Audit::log('backup.upload_restore', 'backup', null, $file['name']);
            flash('success', 'Database restored. Please log in again.');
            Auth::logout();
            redirect('login');
        } catch (Throwable $e) {
            flash('error', 'Restore failed: ' . $e->getMessage());
            redirect('settings/backup');
        }
    }
}