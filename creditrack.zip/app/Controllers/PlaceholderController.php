<?php
declare(strict_types=1);

final class PlaceholderController
{
    public function show(string $viewPath, string $permission, string $title, string $subtitle): void
    {
        Acl::require($permission);
        view($viewPath, ['title' => $title, 'subtitle' => $subtitle]);
    }

    public function notFound(): void
    {
        view('errors/404', [], 'app');
    }
}