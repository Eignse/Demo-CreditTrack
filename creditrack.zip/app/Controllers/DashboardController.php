<?php
declare(strict_types=1);

final class DashboardController
{
    public function index(): void
    {
        AuthMiddleware::requireLogin();
        $u = Auth::user();
        $isAdmin = $u['role'] === 'admin';
        $uid = (int)$u['id'];

        // Ensure any past-due pending schedules are flagged as overdue
        PaymentService::markOverdue();

        // Top stat cards
        $todayTotals = Payment::todayTotals($uid, $isAdmin);
        $demo = [
            'total_clients'      => Client::countActive($uid, $isAdmin),
            'active_accounts'    => Loan::countActive($uid, $isAdmin),
            'outstanding_balance'=> Loan::totalOutstanding($uid, $isAdmin),
            'todays_collection'  => (float)$todayTotals['total'],
            'transactions_today' => (int)$todayTotals['cnt'],
        ];

        // --- NEW: Real Collection Trend (Last 7 Days) ---
        $pdo = Database::pdo();
        $trendSql = "
            SELECT DATE(p.payment_date) as date, SUM(p.amount) as total
            FROM payments p
            JOIN clients c ON c.id = p.client_id
            WHERE p.voided_at IS NULL 
              AND p.payment_date >= DATE_SUB(CURDATE(), INTERVAL 6 DAY)
        ";
        if (!$isAdmin) {
            $trendSql .= " AND c.assigned_user_id = ?";
        }
        $trendSql .= " GROUP BY DATE(p.payment_date) ORDER BY date ASC";
        
        $stmt = $pdo->prepare($trendSql);
        if ($isAdmin) {
            $stmt->execute();
        } else {
            $stmt->execute([$uid]);
        }
        
        $rawTrend = $stmt->fetchAll();
        $trendMap = [];
        foreach ($rawTrend as $row) {
            $trendMap[$row['date']] = (float)$row['total'];
        }

        // Build the 7-day arrays (even if there are 0 collections on a day)
        $chartLabels = [];
        $chartData = [];
        for ($i = 6; $i >= 0; $i--) {
            $dateStr = date('Y-m-d', strtotime("-$i days"));
            $chartLabels[] = date('D', strtotime($dateStr)); // e.g. "Mon", "Tue"
            $chartData[] = $trendMap[$dateStr] ?? 0;
        }

        // Recent Activity
        $stmt = $pdo->prepare("
            SELECT a.action, a.created_at, u.full_name AS user_name
            FROM audit_logs a
            LEFT JOIN users u ON u.id = a.user_id
            ORDER BY a.created_at DESC LIMIT 8
        ");
        $stmt->execute();
        $recent = $stmt->fetchAll();

        // Group Collection Summary
        $groupSql = "
            SELECT g.id, g.name, g.code,
                   COALESCE(SUM(l.total_payable), 0) AS expected_total,
                   COALESCE(SUM(l.amount_paid), 0)   AS collected_total,
                   COALESCE(SUM(l.balance), 0)       AS balance_total,
                   COUNT(DISTINCT l.id) AS loan_count
            FROM `groups` g
            LEFT JOIN clients c ON c.group_id = g.id
            LEFT JOIN loan_accounts l ON l.client_id = c.id AND l.status IN ('active','completed')
            WHERE g.is_active = 1
        ";
        if (!$isAdmin) {
            $groupSql .= " AND g.assigned_user_id = ?";
        }
        $groupSql .= " GROUP BY g.id, g.name, g.code HAVING loan_count > 0 ORDER BY g.name LIMIT 10";
        
        $stmt = $pdo->prepare($groupSql);
        if ($isAdmin) {
            $stmt->execute();
        } else {
            $stmt->execute([$uid]);
        }
        $groupSummary = $stmt->fetchAll();

        view('dashboard/index', [
            'demo'         => $demo,
            'recent'       => $recent,
            'groupSummary' => $groupSummary,
            'chartLabels'  => $chartLabels, // Passed to view
            'chartData'    => $chartData,   // Passed to view
        ]);
    }
}