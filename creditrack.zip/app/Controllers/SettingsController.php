<?php
declare(strict_types=1);

final class SettingsController
{
    private function guard(string $perm = 'settings.view'): array
    {
        AuthMiddleware::requireLogin();
        Acl::require($perm);
        $u = Auth::user();
        return [(int)$u['id'], $u['role'] === 'admin'];
    }

    // ---- BUSINESS INFORMATION ----
    public function business(): void
    {
        $this->guard();
        $settings = Settings::all();
        view('settings/business', [
            'title'    => 'Business Information',
            'settings' => $settings,
        ]);
    }

    public function businessSave(): void
    {
        [$uid] = $this->guard('settings.manage');
        verifyCsrf();

        $values = [
            'business_name'    => input('business_name', ''),
            'business_address' => input('business_address', ''),
            'business_phone'   => input('business_phone', ''),
            'business_email'   => input('business_email', ''),
            'receipt_footer'   => input('receipt_footer', ''),
        ];

        // Handle logo upload
        try {
            $logo = handlePhotoUpload('business_logo');
            if ($logo !== null) $values['business_logo'] = $logo;
        } catch (Throwable $e) {
            flash('error', 'Logo upload failed: ' . $e->getMessage());
            redirect('settings/business');
        }

        Settings::set($values, $uid);
        Audit::log('settings.business_update', 'settings', null, 'Business info updated');
        flash('success', 'Business information saved.');
        redirect('settings/business');
    }

    // ---- PREFERENCES ----
    public function preferences(): void
    {
        $this->guard();
        $settings = Settings::all();
        view('settings/preferences', [
            'title'    => 'Preferences',
            'settings' => $settings,
        ]);
    }

    public function preferencesSave(): void
    {
        [$uid] = $this->guard('settings.manage');
        verifyCsrf();

        $currency  = input('currency_symbol', '₱');
        $dateFmt   = input('date_format', 'Y-m-d');
        $perPage   = (int)input('items_per_page', 15);

        if ($perPage < 5 || $perPage > 100) $perPage = 15;

        Settings::set([
            'currency_symbol' => $currency,
            'date_format'     => $dateFmt,
            'items_per_page'  => (string)$perPage,
        ], $uid);

        Audit::log('settings.preferences_update', 'settings', null, 'Preferences updated');
        flash('success', 'Preferences saved.');
        redirect('settings/preferences');
    }

    // ---- AUDIT LOG VIEWER ----
    public function audit(): void
    {
        $this->guard('audit.view');
        $filters = [
            'q'       => trim($_GET['q'] ?? ''),
            'action'  => $_GET['action'] ?? '',
            'user_id' => $_GET['user_id'] ?? '',
            'date_from' => $_GET['date_from'] ?? '',
            'date_to'   => $_GET['date_to'] ?? '',
        ];
        $page = max(1, (int)($_GET['page'] ?? 1));
        $result = $this->fetchAuditLogs($filters, $page);
        $users = User::activeList();
        $actions = $this->distinctActions();

        view('settings/audit', [
            'title'   => 'Audit Logs',
            'result'  => $result,
            'filters' => $filters,
            'users'   => $users,
            'actions' => $actions,
        ]);
    }

    private function fetchAuditLogs(array $filters, int $page, int $perPage = 30): array
    {
        $pdo = Database::pdo();
        $where = ["1=1"];
        $params = [];

        if ($filters['q'] !== '') {
            $where[] = "(a.action LIKE ? OR a.details LIKE ?)";
            $like = '%' . $filters['q'] . '%';
            $params[] = $like; $params[] = $like;
        }
        if ($filters['action'] !== '') {
            $where[] = "a.action = ?";
            $params[] = $filters['action'];
        }
        if ($filters['user_id'] !== '') {
            $where[] = "a.user_id = ?";
            $params[] = (int)$filters['user_id'];
        }
        if ($filters['date_from'] !== '') {
            $where[] = "a.created_at >= ?";
            $params[] = $filters['date_from'] . ' 00:00:00';
        }
        if ($filters['date_to'] !== '') {
            $where[] = "a.created_at <= ?";
            $params[] = $filters['date_to'] . ' 23:59:59';
        }

        $whereSql = implode(' AND ', $where);
        $countStmt = $pdo->prepare("SELECT COUNT(*) FROM audit_logs a WHERE $whereSql");
        $countStmt->execute($params);
        $total = (int)$countStmt->fetchColumn();

        $offset = max(0, ($page - 1) * $perPage);
        $sql = "
            SELECT a.*, u.full_name AS user_name
            FROM audit_logs a
            LEFT JOIN users u ON u.id = a.user_id
            WHERE $whereSql
            ORDER BY a.created_at DESC
            LIMIT $perPage OFFSET $offset
        ";
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        return ['rows' => $stmt->fetchAll(), 'total' => $total, 'page' => $page, 'per_page' => $perPage];
    }

    private function distinctActions(): array
    {
        return Database::pdo()->query("
            SELECT DISTINCT action FROM audit_logs ORDER BY action
        ")->fetchAll(PDO::FETCH_COLUMN);
    }
}