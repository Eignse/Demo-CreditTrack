<?php
declare(strict_types=1);

final class AuthController
{
    public function showLogin(): void
    {
        $error = flash('error');
        view('auth/login', ['error' => $error], 'auth');
    }

    public function login(): void
    {
        verifyCsrf();
        $username = input('username', '');
        $password = input('password', '');

        if ($username === '' || $password === '') {
            flash('error', 'Please provide both username and password.');
            redirect('login');
        }
        
        if (Auth::attempt($username, $password)) {
            flash('success', 'Welcome back, ' . Auth::user()['full_name'] . '!');
            redirect('dashboard');
        }
        
        flash('error', 'Invalid credentials or account locked. Please try again.');
        redirect('login');
    }

    public function logout(): void
    {
        Auth::logout();
        startSecureSession();
        flash('success', 'You have been signed out.');
        redirect('login');
    }
}