<?php
declare(strict_types=1);

final class UserController
{
    private function guard(string $perm = 'users.view'): array
    {
        AuthMiddleware::requireLogin();
        Acl::require($perm);
        $u = Auth::user();
        return [(int)$u['id'], $u['role'] === 'admin'];
    }

    public function index(): void
    {
        $this->guard();
        $filters = [
            'q'      => trim($_GET['q'] ?? ''),
            'role'   => $_GET['role'] ?? '',
            'status' => $_GET['status'] ?? '',
        ];
        $page = max(1, (int)($_GET['page'] ?? 1));
        $result = User::all($filters, $page);
        view('users/index', [
            'title'   => 'User List',
            'result'  => $result,
            'filters' => $filters,
        ]);
    }

    public function create(): void
    {
        $this->guard('users.manage');
        $roles = $this->roles();
        view('users/form', [
            'title' => 'New User',
            'user'  => null,
            'roles' => $roles,
        ]);
    }

    public function store(): void
    {
        $this->guard('users.manage');
        verifyCsrf();

        $data = $this->validate(null);
        $id = User::create($data);
        Audit::log('user.create', 'user', $id, $data['username']);
        flash('success', 'User created successfully.');
        redirect('users/' . $id);
    }

    public function show(int $id): void
    {
        $this->guard();
        $user = User::find($id);
        if (!$user) {
            http_response_code(404);
            view('errors/404', [], 'app');
            return;
        }
        view('users/show', ['title' => $user['full_name'], 'user' => $user]);
    }

    public function edit(int $id): void
    {
        $this->guard('users.manage');
        $user = User::find($id);
        if (!$user) {
            http_response_code(404);
            view('errors/404', [], 'app');
            return;
        }
        $roles = $this->roles();
        view('users/form', [
            'title' => 'Edit User',
            'user'  => $user,
            'roles' => $roles,
        ]);
    }

    public function update(int $id): void
    {
        [$viewerId] = $this->guard('users.manage');
        verifyCsrf();

        $existing = User::find($id);
        if (!$existing) { http_response_code(404); exit; }

        // Safety: cannot deactivate or demote yourself
        $data = $this->validate($id, $existing);

        if ($id === $viewerId) {
            if ($data['role'] !== 'admin') {
                flash('error', 'You cannot change your own role.');
                redirect('users/' . $id . '/edit');
            }
            if (!$data['is_active']) {
                flash('error', 'You cannot deactivate your own account.');
                redirect('users/' . $id . '/edit');
            }
        }

        // Safety: cannot demote/deactivate the last admin
        if ($existing['role_name'] === 'admin' && ($data['role'] !== 'admin' || !$data['is_active'])) {
            if (User::adminCount() <= 1) {
                flash('error', 'Cannot demote or deactivate the last remaining admin.');
                redirect('users/' . $id . '/edit');
            }
        }

        User::update($id, $data);
        Audit::log('user.update', 'user', $id, $data['full_name']);
        flash('success', 'User updated.');
        redirect('users/' . $id);
    }

    // ---- Self-service password change ----
    public function passwordForm(): void
    {
        AuthMiddleware::requireLogin();
        view('users/password', ['title' => 'Change Password']);
    }

    public function passwordUpdate(): void
    {
        AuthMiddleware::requireLogin();
        verifyCsrf();

        $current = input('current_password', '');
        $new     = input('new_password', '');
        $confirm = input('confirm_password', '');

        if (!$current || !$new || !$confirm) {
            flash('error', 'All fields are required.');
            redirect('users/password');
        }
        if (strlen($new) < 8) {
            flash('error', 'New password must be at least 8 characters.');
            redirect('users/password');
        }
        if ($new !== $confirm) {
            flash('error', 'New password and confirmation do not match.');
            redirect('users/password');
        }
        if (!User::verifyPassword((int)Auth::id(), $current)) {
            flash('error', 'Current password is incorrect.');
            redirect('users/password');
        }

        User::changePassword((int)Auth::id(), $new);
        Audit::log('user.password_change', 'user', (int)Auth::id());
        flash('success', 'Password changed successfully.');
        redirect('dashboard');
    }

    // ---- Helpers ----
    private function roles(): array
    {
        return Database::pdo()->query("SELECT name, label FROM roles ORDER BY id")->fetchAll();
    }

    private function validate(?int $excludeId, ?array $existing = null): array
    {
        $data = [
            'full_name' => input('full_name', ''),
            'username'  => input('username', ''),
            'email'     => input('email', ''),
            'role'      => input('role', 'staff'),
            'password'  => input('password', ''),
            'is_active' => (bool)input('is_active', $existing ? $existing['is_active'] : '1'),
        ];

        if ($data['full_name'] === '') {
            flash('error', 'Full name is required.'); redirect($_SERVER['HTTP_REFERER'] ?? 'users');
        }
        if ($data['email'] === '' || !filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
            flash('error', 'A valid email is required.'); redirect($_SERVER['HTTP_REFERER'] ?? 'users');
        }
        if (!in_array($data['role'], ['admin','staff'], true)) {
            flash('error', 'Invalid role.'); redirect($_SERVER['HTTP_REFERER'] ?? 'users');
        }

        // For create, require username + password
        if (!$existing) {
            if ($data['username'] === '') {
                flash('error', 'Username is required.'); redirect('users/create');
            }
            if (strlen($data['password']) < 8) {
                flash('error', 'Password must be at least 8 characters.'); redirect('users/create');
            }
            if (User::usernameExists($data['username'])) {
                flash('error', 'Username is already taken.'); redirect('users/create');
            }
        }

        // For update, username is not changed
        if ($existing) {
            $data['username'] = $existing['username'];
        }

        if (User::emailExists($data['email'], $excludeId)) {
            flash('error', 'Email is already in use.'); redirect($_SERVER['HTTP_REFERER'] ?? 'users');
        }

        return $data;
    }
}