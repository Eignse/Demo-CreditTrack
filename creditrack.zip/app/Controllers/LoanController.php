<?php
declare(strict_types=1);

final class LoanController
{
    private function guard(string $perm = 'loans.view'): array
    {
        AuthMiddleware::requireLogin();
        Acl::require($perm);
        $u = Auth::user();
        return [(int)$u['id'], $u['role'] === 'admin'];
    }

    public function index(): void
    {
        [$uid, $isAdmin] = $this->guard();
        $filters = ['q' => trim($_GET['q'] ?? ''), 'status' => $_GET['status'] ?? ''];
        $page = max(1, (int)($_GET['page'] ?? 1));
        $result = Loan::all($filters, $uid, $isAdmin, $page);
        view('loans/index', ['title' => 'Loan Accounts', 'result' => $result, 'filters' => $filters]);
    }

    public function create(): void
    {
        [$uid, $isAdmin] = $this->guard('loans.manage');
        $preselectClient = (int)($_GET['client_id'] ?? 0);
        $clients = $this->availableClients($uid, $isAdmin);
        view('loans/form', ['title' => 'New Loan Account', 'loan' => null, 'nextCode' => Loan::generateCode(), 'clients' => $clients, 'preselectClient' => $preselectClient]);
    }

    public function store(): void
    {
        [$uid, $isAdmin] = $this->guard('loans.manage');
        verifyCsrf();
        $data = $this->validate();
        $data['loan_code'] = Loan::generateCode();

        try {
            $id = Loan::create($data, $uid);
        } catch (Throwable $e) {
            flash('error', 'Loan creation failed: ' . $e->getMessage());
            redirect('loans/create');
        }

        Audit::log('loan.create', 'loan', $id, $data['loan_code']);
        flash('success', 'Loan created with full amortization schedule.');
        redirect('loans/' . $id);
    }

    public function show(int $id): void
    {
        [$uid, $isAdmin] = $this->guard();
        if (!Loan::canAccess($id, $uid, $isAdmin)) { http_response_code(403); view('errors/403', [], 'app'); return; }
        $loan = Loan::find($id);
        if (!$loan) { http_response_code(404); view('errors/404', [], 'app'); return; }
        $schedules = Loan::schedules($id);
        view('loans/show', ['title' => 'Loan ' . $loan['loan_code'], 'loan' => $loan, 'schedules' => $schedules]);
    }

    public function edit(int $id): void
    {
        [$uid, $isAdmin] = $this->guard('loans.manage');
        if (!Loan::canAccess($id, $uid, $isAdmin)) { http_response_code(403); exit; }
        $stmt = Database::pdo()->prepare("SELECT COUNT(*) FROM payments WHERE loan_id = ? AND voided_at IS NULL");
        $stmt->execute([$id]);
        if ((int)$stmt->fetchColumn() > 0) {
            flash('error', 'Cannot edit a loan that has recorded payments.');
            redirect('loans/' . $id);
        }
        $loan = Loan::find($id);
        view('loans/edit', ['title' => 'Edit Loan', 'loan' => $loan]);
    }

    public function update(int $id): void
    {
        [$uid, $isAdmin] = $this->guard('loans.manage');
        verifyCsrf();
        if (!Loan::canAccess($id, $uid, $isAdmin)) { http_response_code(403); exit; }
        
        $stmt = Database::pdo()->prepare("SELECT COUNT(*) FROM payments WHERE loan_id = ? AND voided_at IS NULL");
        $stmt->execute([$id]);
        if ((int)$stmt->fetchColumn() > 0) {
            flash('error', 'Cannot update a loan that has recorded payments.');
            redirect('loans/' . $id);
        }

        $data = $this->validate();
        $data['loan_code'] = Loan::find($id)['loan_code'];
        
        try {
            Loan::update($id, $data);
            flash('success', 'Loan updated and amortization schedule regenerated.');
            redirect('loans/' . $id);
        } catch (Throwable $e) {
            flash('error', 'Update failed: ' . $e->getMessage());
            redirect('loans/' . $id . '/edit');
        }
    }

    public function cancelForm(int $id): void
    {
        [$uid, $isAdmin] = $this->guard('loans.cancel');
        if (!Loan::canAccess($id, $uid, $isAdmin)) { http_response_code(403); exit; }
        $loan = Loan::find($id);
        view('loans/cancel', ['title' => 'Cancel Loan', 'loan' => $loan]);
    }

    public function cancel(): void
    {
        [$uid] = $this->guard('loans.cancel');
        verifyCsrf();
        $id = (int)input('loan_id', 0);
        $reason = input('reason', '');
        $force = (bool)input('force', false);

        $loan = Loan::find($id);
        if (!$loan) { flash('error', 'Loan not found.'); redirect('loans'); }

        $stmt = Database::pdo()->prepare("SELECT COUNT(*) FROM payments WHERE loan_id = ? AND voided_at IS NULL");
        $stmt->execute([$id]);
        $paidCount = (int)$stmt->fetchColumn();

        if ($paidCount > 0 && !$force) {
            flash('error', 'This loan has recorded payments. Check "Force cancel" to override.');
            redirect('loans/' . $id . '/cancel');
        }

        Database::pdo()->prepare("UPDATE loan_accounts SET status = 'cancelled', cancelled_at = NOW(), cancel_reason = ? WHERE id = ?")
            ->execute([$reason, $id]);

        Audit::log('loan.cancel', 'loan', $id, "Reason: $reason");
        flash('success', 'Loan cancelled successfully.');
        redirect('loans/' . $id);
    }

    public function payoffForm(int $id): void
    {
        [$uid, $isAdmin] = $this->guard('loans.payoff');
        if (!Loan::canAccess($id, $uid, $isAdmin)) { http_response_code(403); exit; }
        
        $loan = Loan::find($id);
        try {
            $calc = LoanService::calculatePayoff($id);
        } catch (Throwable $e) {
            flash('error', 'Cannot calculate payoff: ' . $e->getMessage());
            redirect('loans/' . $id);
        }
        view('loans/payoff', ['title' => 'Early Payoff', 'loan' => $loan, 'calc' => $calc]);
    }

    public function payoff(): void
    {
        [$uid] = $this->guard('loans.payoff');
        verifyCsrf();
        
        $id = (int)input('loan_id', 0);
        $method = input('payment_method', 'cash');

        try {
            $calc = LoanService::calculatePayoff($id);
            $paymentId = LoanService::processPayoff($id, $calc['total_payoff'], $method, $uid);
            flash('success', 'Loan paid off successfully. Payoff Receipt generated.');
            redirect('payments/' . $paymentId);
        } catch (Throwable $e) {
            flash('error', 'Payoff failed: ' . $e->getMessage());
            redirect('loans/' . $id . '/payoff');
        }
    }

    private function availableClients(int $uid, bool $isAdmin): array
    {
        $pdo = Database::pdo();
        if ($isAdmin) {
            return $pdo->query("SELECT id, client_code, full_name FROM clients WHERE status='active' ORDER BY full_name")->fetchAll();
        }
        $stmt = $pdo->prepare("SELECT id, client_code, full_name FROM clients WHERE status='active' AND assigned_user_id=? ORDER BY full_name");
        $stmt->execute([$uid]);
        return $stmt->fetchAll();
    }

    private function validate(bool $strict = true): array
    {
        $clientId = (int)input('client_id', 0);
        $principal = (float)input('principal', 0);
        $rate = (float)input('interest_rate', 0);
        $term = (int)input('term_months', 0);
        $method = input('interest_method', 'flat');
        $frequency = input('frequency', 'monthly');
        $startDate = input('start_date', '');
        $firstDue = input('first_due_date', '');

        if ($strict) {
            if ($clientId <= 0) { flash('error', 'Please select a client.'); redirect('loans/create'); }
            if ($principal <= 0) { flash('error', 'Principal must be greater than zero.'); redirect('loans/create'); }
            if ($rate < 0) { flash('error', 'Interest rate cannot be negative.'); redirect('loans/create'); }
            if ($term <= 0) { flash('error', 'Term must be at least 1 month.'); redirect('loans/create'); }
            if (!in_array($method, ['flat','diminishing'], true)) { flash('error', 'Invalid interest method.'); redirect('loans/create'); }
            if (!in_array($frequency, ['daily','weekly','semi_monthly','monthly'], true)) { flash('error', 'Invalid frequency.'); redirect('loans/create'); }
            if (!$startDate || !$firstDue) { flash('error', 'Dates are required.'); redirect('loans/create'); }
        }

        return [
            'client_id' => $clientId, 'principal' => $principal, 'interest_rate' => $rate, 'term_months' => $term,
            'interest_method' => $method, 'frequency' => $frequency, 'start_date' => $startDate, 'first_due_date' => $firstDue,
            'notes' => input('notes', ''),
        ];
    }
}