<?php
declare(strict_types=1);

final class ClientController
{
    private function guard(): array
    {
        AuthMiddleware::requireLogin();
        Acl::require('clients.view');
        $u = Auth::user();
        return [(int)$u['id'], $u['role'] === 'admin'];
    }

    public function index(): void
    {
        [$uid, $isAdmin] = $this->guard();
        $filters = [
            'q'        => trim($_GET['q'] ?? ''),
            'status'   => $_GET['status'] ?? '',
            'group_id' => $_GET['group_id'] ?? '',
        ];
        $page = max(1, (int)($_GET['page'] ?? 1));
        $result = Client::all($filters, $uid, $isAdmin, $page);
        $groups = Group::simpleList($uid, $isAdmin);
        view('clients/index', [
            'title'    => 'Clients',
            'result'   => $result,
            'filters'  => $filters,
            'groups'   => $groups,
            'isAdmin'  => $isAdmin,
        ]);
    }

    public function create(): void
    {
        [$uid, $isAdmin] = $this->guard();
        Acl::require('clients.manage');
        view('clients/form', [
            'title'       => 'New Client',
            'client'      => null,
            'nextCode'    => Client::generateCode(),
            'groups'      => Group::simpleList($uid, $isAdmin),
            'staff'       => User::staffList(),
        ]);
    }

    public function store(): void
    {
        [$uid, $isAdmin] = $this->guard();
        Acl::require('clients.manage');
        verifyCsrf();

        $data = $this->validate();
        $data['client_code'] = Client::generateCode();
        try {
            $data['photo_path'] = handlePhotoUpload('photo');
        } catch (Throwable $e) {
            flash('error', 'Photo upload failed: ' . $e->getMessage());
            redirect('clients/create');
        }

        $id = Client::create($data, $uid);
        Audit::log('client.create', 'client', $id, $data['full_name']);
        flash('success', 'Client created successfully.');
        redirect('clients/' . $id);
    }

    public function show(int $id): void
    {
        [$uid, $isAdmin] = $this->guard();
        if (!Client::canAccess($id, $uid, $isAdmin)) {
            http_response_code(403);
            view('errors/403', [], 'app');
            return;
        }
        $client = Client::find($id);
        if (!$client) {
            http_response_code(404);
            view('errors/404', [], 'app');
            return;
        }
        view('clients/show', ['title' => $client['full_name'], 'client' => $client]);
    }

    public function edit(int $id): void
    {
        [$uid, $isAdmin] = $this->guard();
        Acl::require('clients.manage');
        if (!Client::canAccess($id, $uid, $isAdmin)) {
            http_response_code(403);
            view('errors/403', [], 'app');
            return;
        }
        $client = Client::find($id);
        if (!$client) {
            http_response_code(404);
            view('errors/404', [], 'app');
            return;
        }
        view('clients/form', [
            'title'    => 'Edit Client',
            'client'   => $client,
            'nextCode' => $client['client_code'],
            'groups'   => Group::simpleList($uid, $isAdmin),
            'staff'    => User::staffList(),
        ]);
    }

    public function update(int $id): void
    {
        [$uid, $isAdmin] = $this->guard();
        Acl::require('clients.manage');
        verifyCsrf();
        if (!Client::canAccess($id, $uid, $isAdmin)) {
            http_response_code(403);
            view('errors/403', [], 'app');
            return;
        }

        $data = $this->validate();
        try {
            $data['photo_path'] = handlePhotoUpload('photo');
        } catch (Throwable $e) {
            flash('error', 'Photo upload failed: ' . $e->getMessage());
            redirect('clients/' . $id . '/edit');
        }

        Client::update($id, $data);
        Audit::log('client.update', 'client', $id, $data['full_name']);
        flash('success', 'Client updated.');
        redirect('clients/' . $id);
    }

    public function deactivate(int $id): void
    {
        [$uid, $isAdmin] = $this->guard();
        Acl::require('clients.manage');
        verifyCsrf();
        if (!Client::canAccess($id, $uid, $isAdmin)) {
            http_response_code(403); exit('Forbidden');
        }
        Database::pdo()->prepare("UPDATE clients SET status='inactive' WHERE id=?")->execute([$id]);
        Audit::log('client.deactivate', 'client', $id);
        flash('success', 'Client deactivated.');
        redirect('clients');
    }

    private function validate(): array
    {
        $required = ['full_name','phone','address'];
        $data = [];
        foreach ($required as $field) {
            $v = input($field, '');
            if ($v === '') {
                flash('error', ucfirst(str_replace('_',' ',$field)) . ' is required.');
                redirect($_SERVER['HTTP_REFERER'] ?? 'clients');
            }
            $data[$field] = $v;
        }
        $data['nickname']         = input('nickname', '');
        $data['alt_phone']        = input('alt_phone', '');
        $data['email']            = input('email', '');
        $data['date_of_birth']    = input('date_of_birth', '');
        $data['occupation']       = input('occupation', '');
        $data['id_type']          = input('id_type', '');
        $data['id_number']        = input('id_number', '');
        $data['notes']            = input('notes', '');
        $data['group_id']         = input('group_id', '') ?: null;
        $data['assigned_user_id'] = input('assigned_user_id', '') ?: null;
        $data['status']           = input('status', 'active');
        if (!in_array($data['status'], ['active','inactive','blacklisted'], true)) {
            $data['status'] = 'active';
        }
        return $data;
    }
}