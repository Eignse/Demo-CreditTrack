<?php
declare(strict_types=1);

final class GroupController
{
    private function guard(): array
    {
        AuthMiddleware::requireLogin();
        Acl::require('groups.view');
        $u = Auth::user();
        return [(int)$u['id'], $u['role'] === 'admin'];
    }

    public function index(): void
    {
        [$uid, $isAdmin] = $this->guard();
        $filters = ['q' => trim($_GET['q'] ?? '')];
        $page = max(1, (int)($_GET['page'] ?? 1));
        $result = Group::all($filters, $uid, $isAdmin, $page);
        view('groups/index', [
            'title'   => 'Groups',
            'result'  => $result,
            'filters' => $filters,
            'isAdmin' => $isAdmin,
        ]);
    }

    public function create(): void
    {
        [$uid, $isAdmin] = $this->guard();
        Acl::require('groups.manage');
        view('groups/form', [
            'title'    => 'New Group',
            'group'    => null,
            'nextCode' => Group::generateCode(),
            'staff'    => User::staffList(),
            'allClients' => Group::allClientsForDropdown(), // Pass all clients
        ]);
    }

    public function store(): void
    {
        [$uid, $isAdmin] = $this->guard();
        Acl::require('groups.manage');
        verifyCsrf();

        $data = $this->validate();
        $data['code'] = Group::generateCode();
        $id = Group::create($data, $uid);
        Audit::log('group.create', 'group', $id, $data['name']);
        flash('success', 'Group created.');
        redirect('groups/' . $id);
    }

    public function show(int $id): void
    {
        [$uid, $isAdmin] = $this->guard();
        if (!Group::canAccess($id, $uid, $isAdmin)) {
            http_response_code(403);
            view('errors/403', [], 'app');
            return;
        }
        $group = Group::find($id);
        if (!$group) {
            http_response_code(404);
            view('errors/404', [], 'app');
            return;
        }
        $members = Group::members($id);
        view('groups/show', ['title' => $group['name'], 'group' => $group, 'members' => $members]);
    }

    public function edit(int $id): void
    {
        [$uid, $isAdmin] = $this->guard();
        Acl::require('groups.manage');
        if (!Group::canAccess($id, $uid, $isAdmin)) {
            http_response_code(403); exit('Forbidden');
        }
        $group = Group::find($id);
        if (!$group) {
            http_response_code(404); exit('Not found');
        }
        view('groups/form', [
            'title'      => 'Edit Group',
            'group'      => $group,
            'nextCode'   => $group['code'],
            'staff'      => User::staffList(),
            'allClients' => Group::allClientsForDropdown(), // Pass all clients
        ]);
    }

    public function update(int $id): void
    {
        [$uid, $isAdmin] = $this->guard();
        Acl::require('groups.manage');
        verifyCsrf();
        if (!Group::canAccess($id, $uid, $isAdmin)) { http_response_code(403); exit; }

        $data = $this->validate();
        Group::update($id, $data);
        Audit::log('group.update', 'group', $id, $data['name']);
        flash('success', 'Group updated.');
        redirect('groups/' . $id);
    }

    private function validate(): array
    {
        $name = input('name', '');
        if ($name === '') {
            flash('error', 'Group name is required.');
            redirect($_SERVER['HTTP_REFERER'] ?? 'groups');
        }
        return [
            'name'             => $name,
            'leader_client_id' => input('leader_client_id', '') ?: null,
            'assigned_user_id' => input('assigned_user_id', '') ?: null,
            'meeting_day'      => input('meeting_day', ''),
            'notes'            => input('notes', ''),
            'is_active'        => (bool)input('is_active', '1'),
        ];
    }
}