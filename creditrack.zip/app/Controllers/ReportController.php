<?php
declare(strict_types=1);

final class ReportController
{
    private function guard(): array
    {
        AuthMiddleware::requireLogin();
        Acl::require('reports.view');
        $u = Auth::user();
        return [(int)$u['id'], $u['role'] === 'admin'];
    }

    // ---- DAILY ----
    public function daily(): void
    {
        [$uid, $isAdmin] = $this->guard();
        $filters = [
            'date_from'    => $_GET['date_from'] ?? date('Y-m-01'),
            'date_to'      => $_GET['date_to'] ?? date('Y-m-d'),
            'collector_id' => $_GET['collector_id'] ?? '',
        ];

        $data = ReportService::dailyCollection($filters, $uid, $isAdmin);
        
        // Safety net for empty data
        $data = array_merge([
            'rows' => [],
            'total_collected' => 0.00,
            'total_count' => 0,
        ], $data);

        $collectors = User::activeList();
        view('reports/daily', [
            'title'      => 'Daily Collection Report',
            'data'       => $data,
            'filters'    => $filters,
            'collectors' => $collectors,
        ]);
    }

    public function dailyExport(): void
    {
        [$uid, $isAdmin] = $this->guard();
        $filters = [
            'date_from'    => $_GET['date_from'] ?? date('Y-m-01'),
            'date_to'      => $_GET['date_to'] ?? date('Y-m-d'),
            'collector_id' => $_GET['collector_id'] ?? '',
        ];
        $data = ReportService::dailyCollection($filters, $uid, $isAdmin);
        $this->csv('daily-collection-' . date('Ymd'), ['Date','Collector','Payments','Total Collected'], array_map(fn($r) => [
            $r['payment_date'] ?? '', $r['collector_name'] ?? '', $r['payment_count'] ?? 0, $r['total_collected'] ?? 0
        ], $data['rows'] ?? []));
    }

    // ---- GROUP ----
    public function group(): void
    {
        [$uid, $isAdmin] = $this->guard();
        $filters = ['group_id' => $_GET['group_id'] ?? ''];
        $data = ReportService::groupCollection($filters, $uid, $isAdmin);
        
        $data = array_merge([
            'rows' => [],
            'expected' => 0.00,
            'collected' => 0.00,
            'balance' => 0.00,
        ], $data);

        $groups = Group::simpleList($uid, $isAdmin);
        view('reports/group', [
            'title'   => 'Group Collection Report',
            'data'    => $data,
            'filters' => $filters,
            'groups'  => $groups,
        ]);
    }

    public function groupExport(): void
    {
        [$uid, $isAdmin] = $this->guard();
        $filters = ['group_id' => $_GET['group_id'] ?? ''];
        $data = ReportService::groupCollection($filters, $uid, $isAdmin);
        $this->csv('group-collection-' . date('Ymd'), ['Group Code','Group Name','Collector','Members','Loans','Expected','Collected','Balance'], array_map(fn($r) => [
            $r['code'] ?? '', $r['name'] ?? '', $r['collector'] ?? '', $r['member_count'] ?? 0, $r['loan_count'] ?? 0, $r['expected'] ?? 0, $r['collected'] ?? 0, $r['balance'] ?? 0
        ], $data['rows'] ?? []));
    }

    // ---- CLIENT ----
    public function client(): void
    {
        [$uid, $isAdmin] = $this->guard();
        $filters = [
            'client_id' => $_GET['client_id'] ?? '',
            'date_from' => $_GET['date_from'] ?? '',
            'date_to'   => $_GET['date_to'] ?? '',
        ];
        $data = ReportService::clientPayments($filters, $uid, $isAdmin);
        
        $data = array_merge([
            'rows' => [],
            'total' => 0.00,
            'count' => 0,
        ], $data);

        $clients = $this->clientList($uid, $isAdmin);
        view('reports/client', [
            'title'   => 'Client Payment Report',
            'data'    => $data,
            'filters' => $filters,
            'clients' => $clients,
        ]);
    }

    public function clientExport(): void
    {
        [$uid, $isAdmin] = $this->guard();
        $filters = [
            'client_id' => $_GET['client_id'] ?? '',
            'date_from' => $_GET['date_from'] ?? '',
            'date_to'   => $_GET['date_to'] ?? '',
        ];
        $data = ReportService::clientPayments($filters, $uid, $isAdmin);
        $this->csv('client-payments-' . date('Ymd'), ['Date','Receipt','Client','Loan','Amount','Method','Collector'], array_map(fn($r) => [
            $r['payment_date'] ?? '', $r['receipt_no'] ?? '', $r['client_name'] ?? '', $r['loan_code'] ?? '', $r['amount'] ?? 0, $r['payment_method'] ?? '', $r['collector'] ?? ''
        ], $data['rows'] ?? []));
    }

    // ---- OUTSTANDING ----
    public function outstanding(): void
    {
        [$uid, $isAdmin] = $this->guard();
        $filters = ['group_id' => $_GET['group_id'] ?? ''];
        $data = ReportService::outstanding($filters, $uid, $isAdmin);
        
        $data = array_merge([
            'rows' => [],
            'total' => 0.00,
            'count' => 0,
        ], $data);

        $groups = Group::simpleList($uid, $isAdmin);
        view('reports/outstanding', [
            'title'   => 'Outstanding Balance Report',
            'data'    => $data,
            'filters' => $filters,
            'groups'  => $groups,
        ]);
    }

    public function outstandingExport(): void
    {
        [$uid, $isAdmin] = $this->guard();
        $filters = ['group_id' => $_GET['group_id'] ?? ''];
        $data = ReportService::outstanding($filters, $uid, $isAdmin);
        $this->csv('outstanding-balance-' . date('Ymd'), ['Loan Code','Client','Group','Collector','Principal','Balance','Maturity','Overdue'], array_map(fn($r) => [
            $r['loan_code'] ?? '', $r['client_name'] ?? '', $r['group_name'] ?? '—', $r['collector'] ?? '', $r['principal'] ?? 0, $r['balance'] ?? 0, $r['maturity_date'] ?? '', $r['overdue_count'] ?? 0
        ], $data['rows'] ?? []));
    }

    // ---- HELPERS ----
    private function clientList(int $uid, bool $isAdmin): array
    {
        $pdo = Database::pdo();
        if ($isAdmin) {
            return $pdo->query("SELECT id, full_name, client_code FROM clients ORDER BY full_name")->fetchAll();
        }
        $stmt = $pdo->prepare("SELECT id, full_name, client_code FROM clients WHERE assigned_user_id = ? ORDER BY full_name");
        $stmt->execute([$uid]);
        return $stmt->fetchAll();
    }

    private function csv(string $filename, array $headers, array $rows): never
    {
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . $filename . '.csv"');
        $out = fopen('php://output', 'w');
        fputcsv($out, $headers);
        foreach ($rows as $row) fputcsv($out, $row);
        fclose($out);
        exit;
    }
}