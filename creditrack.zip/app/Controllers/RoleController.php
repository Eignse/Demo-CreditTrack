<?php
declare(strict_types=1);

final class RoleController
{
    private function guard(): void
    {
        AuthMiddleware::requireLogin();
        Acl::require('users.view'); // Same permission as User Management
    }

    public function index(): void
    {
        $this->guard();
        
        $pdo = Database::pdo();
        
        // Fetch all roles
        $roles = $pdo->query("SELECT * FROM roles ORDER BY id ASC")->fetchAll();
        
        // Fetch all permissions grouped by role
        $stmt = $pdo->query("
            SELECT r.name AS role_name, p.name AS permission_name
            FROM role_permissions rp
            JOIN roles r ON r.id = rp.role_id
            JOIN permissions p ON p.id = rp.permission_id
        ");
        
        $rolePermissions = [];
        foreach ($stmt->fetchAll() as $row) {
            $rolePermissions[$row['role_name']][] = $row['permission_name'];
        }

        view('users/roles', [
            'title'           => 'Roles and Permissions',
            'roles'           => $roles,
            'rolePermissions' => $rolePermissions,
        ]);
    }
}