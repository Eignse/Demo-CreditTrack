<?php
declare(strict_types=1);

final class AuthMiddleware
{
    public static function requireLogin(): void
    {
        if (!Auth::check()) {
            flash('error', 'Please sign in to continue.');
            redirect('login');
        }
    }
    public static function guestOnly(): void
    {
        if (Auth::check()) {
            redirect('dashboard');
        }
    }
}