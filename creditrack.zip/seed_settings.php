<?php
declare(strict_types=1);
require __DIR__ . '/config/config.php';
require __DIR__ . '/config/database.php';
require __DIR__ . '/app/Helpers/autoload.php';

$defaults = [
    'business_name'    => 'CrediTrack Lending',
    'business_address' => '',
    'business_phone'   => '',
    'business_email'   => '',
    'business_logo'    => '',
    'currency_symbol'  => '₱',
    'date_format'      => 'Y-m-d',
    'items_per_page'   => '15',
    'receipt_footer'   => 'Thank you for your payment.',
];

try {
    Settings::set($defaults, null);
    echo "<h2 style='color:green'>✅ Default settings seeded.</h2>";
    echo "<p>You can now <a href='settings/business'>configure business info</a>.</p>";
    echo "<p style='color:red;'><strong>Delete seed_settings.php now!</strong></p>";
} catch (Throwable $e) {
    echo "<h2 style='color:red'>Error</h2><pre>" . htmlspecialchars($e->getMessage()) . "</pre>";
}