<?php
declare(strict_types=1);

// 1. Load Config & Constants
require __DIR__ . '/config/config.php';

// 2. Load Database immediately (so Acl, Auth, etc., can find it)
require __DIR__ . '/config/database.php';

// 3. Register the Autoloader (for Models, Services, Controllers)
require __DIR__ . '/app/Helpers/autoload.php';

// 4. Load environment helpers
require __DIR__ . '/app/Helpers/functions.php';
require __DIR__ . '/app/Helpers/security.php';
require __DIR__ . '/app/Helpers/upload.php';

// 5. Start the secure session
startSecureSession();

// 6. Get the URI and strip the base folder path
$requestUri = $_SERVER['REQUEST_URI'] ?? '/';
$uri        = parse_url($requestUri, PHP_URL_PATH) ?: '/';
$basePath   = rtrim((string)parse_url(APP_URL, PHP_URL_PATH), '/');

if ($basePath !== '' && stripos($uri, $basePath) === 0) {
    $uri = substr($uri, strlen($basePath));
}

$uri = preg_replace('#^/index\.php#i', '', $uri) ?: '/';
$route = '/' . trim($uri, '/');
if ($route === '/') $route = '/';

// 7. Hand off to the Router
require __DIR__ . '/routes/web.php';