document.addEventListener('DOMContentLoaded', () => {
    // Sidebar collapse/expand
    const toggle = document.getElementById('sidebarToggle');
    if (toggle) {
        toggle.addEventListener('click', () => {
            if (window.innerWidth < 768) {
                document.body.classList.toggle('sidebar-open');
            } else {
                document.body.classList.toggle('sidebar-collapsed');
                localStorage.setItem('ct_sidebar_collapsed',
                    document.body.classList.contains('sidebar-collapsed') ? '1' : '0');
            }
        });
        if (window.innerWidth >= 768 && localStorage.getItem('ct_sidebar_collapsed') === '1') {
            document.body.classList.add('sidebar-collapsed');
        }
    }

    // Expandable submenu toggles
    document.querySelectorAll('.nav-toggle').forEach(btn => {
        btn.addEventListener('click', () => {
            const target = document.getElementById(btn.dataset.target);
            if (!target) return;
            const open = target.classList.toggle('open');
            btn.classList.toggle('open', open);
        });
    });
});