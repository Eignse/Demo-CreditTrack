# CrediTrack — Lending & Collection Management System

Phase 1: Foundation, Authentication, Roles, Dashboard Layout, Navigation.

## Local setup (XAMPP on Windows)

1. Start **Apache** and **MySQL** in XAMPP Control Panel.
2. Copy the project into `C:\xampp\htdocs\creditrack`.
3. In phpMyAdmin create a database `creditrack_db` (collation `utf8mb4_unicode_ci`).
4. Copy `.env.example` to `.env` and confirm DB credentials (default XAMPP: user `root`, empty password).
5. Open `http://localhost/creditrack/database/migrate.php` once.
   - This runs migrations, seeds roles/permissions, and prints the initial admin password.
6. **Delete or rename `database/migrate.php`** after success.
7. Sign in at `http://localhost/creditrack/` with the printed credentials.
8. Change the admin password (add a Password Change module in a later phase or via SQL).

## Test checklist (Phase 1)

- [ ] Apache + MySQL start cleanly
- [ ] `http://localhost/creditrack` opens
- [ ] DB connection works (no error on login page)
- [ ] Login with admin works
- [ ] Wrong password is rejected
- [ ] Logout works, session cleared
- [ ] Visiting `/dashboard` while logged out redirects to `/login`
- [ ] Staff role cannot access `/users/list`, `/settings/*` (403)
- [ ] Sidebar toggles open/closed; submenus expand/collapse
- [ ] All nav links open the correct pages
- [ ] Dashboard renders (Chart.js loads, no PHP errors)
- [ ] Direct visit to `http://localhost/creditrack/config/config.php` → 403
- [ ] Direct visit to `http://localhost/creditrack/.env` → 403
- [ ] Restart Apache/MySQL, everything still works

## Phase 2 and beyond

The following are intentionally placeholders in Phase 1: clients, payments,
daily transactions, payment history, all reports, user CRUD, roles/permissions
management UI, business settings, audit viewer, backup/restore.

The schema (`users`, `roles`, `permissions`, `role_permissions`, `audit_logs`,
`system_settings`) is ready for these modules.

## Security notes

- Passwords: `password_hash()` / `password_verify()`
- Sessions: regenerated on login, idle-timeout
- CSRF: token on every POST form
- Login lockout: 5 attempts → 15 min
- Server-side RBAC enforced via `Acl::require()`
- Sensitive folders blocked by `.htaccess`
- All DB calls use PDO prepared statements